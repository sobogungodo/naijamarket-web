"""
trader/kyc.py — Trader KYC registration placeholder
Redirects to PWA registration. wa-v101: auto-joins WA_Waitlist as reporter.
Full KYC flow is handled via the trader PWA (naijamarket-trader.vercel.app).
"""
def handle_kyc(phone, message="", session=None, *args):
    from shared.sender import send_message

    # ── wa-v101: join waitlist as reporter ───────────────────────────────
    waitlist_msg = ""
    try:
        from shared.waitlist import join_waitlist, get_position
        _wl = join_waitlist(phone, email=None, source='reporter')

        if _wl.get('role_conflict'):
            _existing = _wl.get('existing_role', 'consumer')
            _role_label = 'consumer' if _existing == 'whatsapp_bot' else _existing
            send_message(phone,
                f"\u26d4 *Role Conflict*\n\n"
                f"This number is already registered as a *{_role_label}*.\n\n"
                f"Each phone number can only have one role on NaijaMarket Intel. "
                f"If you believe this is an error, contact support.\n\n"
                f"Type *menu* to go back."
            )
            return

        _pos     = _wl.get('position', -1)
        _code    = _wl.get('code', '')
        _already = _wl.get('already_joined', False)

        if _already:
            _pos = get_position(phone)
            waitlist_msg = (
                f"\n\n\u2705 *You're already on the waitlist* (position #{_pos}).\n"
                f"We'll notify you when reporter slots open at launch."
            )
        elif _pos > 0:
            waitlist_msg = (
                f"\n\n\U0001f389 *Waitlist position: #{_pos}*\n"
                f"\U0001f517 Your referral code: *{_code}*\n\n"
                f"Share your code \u2014 each friend who joins earns you "
                f"*1 bonus search* at launch. Slots are first-come, first-served."
            )
    except Exception as _wle:
        import logging
        logging.error(f"[kyc] waitlist join error: {_wle}")
    # ── end wa-v101 ──────────────────────────────────────────────────────

    send_message(phone,
        "\U0001f4cb *Price Reporter Registration*\n\n"
        "NaijaMarket Intel is in pre-launch mode. "
        "Reporter slots are *first-come, first-served*.\n\n"
        "To complete your registration, please visit:\n"
        "\U0001f449 *https://naijamarket-trader.vercel.app*\n\n"
        "You'll need:\n"
        "\u2022 Your full name and date of birth\n"
        "\u2022 NIN (National ID Number)\n"
        "\u2022 Bank account details for payouts\n\n"
        "Already registered? Type *submit* to start submitting prices.\n"
        "Type *menu* to go back."
        + waitlist_msg
    )
