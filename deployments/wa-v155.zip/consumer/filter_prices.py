"""consumer/filter_prices.py — Filter prices by region → state → category"""
import logging
from shared.db import get_connection
from shared.sender import send_message
from shared.session import save_session, clear_session
from shared.lang import get_lang
from shared.i18n import t, footer
from shared.drilldown import REGION_LIST, REGIONS
from consumer.menu import show_main_menu


def handle_filter(phone, message="", session=None, consumer=None, *args):
    session  = session  or {}
    consumer = consumer or {}
    lang = get_lang(session, consumer)
    text = (message or "").strip()
    msg  = text.lower()
    step = session.get("step", 0)

    if msg in ("0","menu"):
        clear_session(phone); show_main_menu(phone); return

    if msg == "back":
        if step <= 1: clear_session(phone); show_main_menu(phone)
        elif step == 2: _pick_region(phone, session, lang)
        elif step == 3:
            states = session.get("states", [])
            region = session.get("region", "")
            lines = "\n".join(f"*{i+1}*. {s}" for i,s in enumerate(states))
            session["step"] = 2; save_session(phone, session)
            send_message(phone, t(lang, "state_title", region=region, lines=lines) + footer(lang))
        return

    if step == 0: _pick_region(phone, session, lang)
    elif step == 1: _pick_state(phone, text, session, lang)
    elif step == 2: _pick_cat(phone, text, session, lang)
    elif step == 3: _show(phone, text, session, lang)
    elif step == 99: _handle_repeat(phone, text, session, lang)
    else: _pick_region(phone, session, lang)


def _pick_region(phone, session, lang):
    lines = "\n".join(f"*{i+1}*. {r}" for i, r in enumerate(REGION_LIST))
    session.update({"_flow": "FILTER", "step": 1})
    save_session(phone, session)
    send_message(phone, t(lang, "region_title", lines=lines) + footer(lang))


def _pick_state(phone, text, session, lang):
    try:
        idx = int(text) - 1; assert 0 <= idx < len(REGION_LIST)
        region = REGION_LIST[idx]
    except:
        send_message(phone, t(lang, "invalid_choice")); return

    all_states = REGIONS.get(region, [])
    try:
        conn = get_connection(); cur = conn.cursor()
        cur.execute("SELECT DISTINCT state FROM dbo.Latest_Prices_Summary WHERE is_nbs_ref=0 AND is_food=1 AND state IS NOT NULL")
        db_states = {r["state"].lower() for r in cur.fetchall()}
        conn.close()
        states = [s for s in all_states if s.lower() in db_states] or all_states
    except:
        states = all_states

    lines = "\n".join(f"*{i+1}*. {s}" for i,s in enumerate(states))
    session.update({"step": 2, "region": region, "states": states})
    save_session(phone, session)
    send_message(phone, t(lang, "state_title", region=region, lines=lines) + footer(lang))


def _pick_cat(phone, text, session, lang):
    states = session.get("states", [])
    try:
        idx = int(text) - 1; assert 0 <= idx < len(states); state = states[idx]
    except:
        send_message(phone, t(lang, "invalid_choice")); return
    try:
        conn = get_connection(); cur = conn.cursor()
        cur.execute("""
            SELECT DISTINCT category_id, category_name
            FROM dbo.Latest_Prices_Summary
            WHERE state=%s AND is_nbs_ref=0 AND is_food=1
            ORDER BY category_name
        """, (state,))
        cats = [{"id": r["category_id"], "name": r["category_name"]} for r in cur.fetchall()]
        conn.close()
        lines = "\n".join(f"*{i+1}*. {c['name']}" for i,c in enumerate(cats))
        session.update({"step": 3, "filter_state": state, "cats": cats})
        save_session(phone, session)
        send_message(phone, f"🔍 *{state}*\n\n{lines}\n\n*back* — States | *0* — Menu" + footer(lang))
    except Exception as e:
        logging.error(f"[filter._pick_cat] {e}")
        send_message(phone, t(lang, "error_generic"))


def _show(phone, text, session, lang):
    cats = session.get("cats", [])
    try:
        idx = int(text) - 1; assert 0 <= idx < len(cats); cat = cats[idx]
    except:
        send_message(phone, t(lang, "invalid_choice")); return
    try:
        conn = get_connection(); cur = conn.cursor()
        cur.execute("""
            SELECT TOP 20 item_name, AVG(price_naira) AS avg_p,
                   unit, COUNT(DISTINCT market_id) AS mkts
            FROM dbo.Latest_Prices_Summary
            WHERE state=%s AND category_id=%s AND is_nbs_ref=0 AND is_food=1 AND price_naira>0
            GROUP BY item_name, unit ORDER BY item_name
        """, (session["filter_state"], cat["id"]))
        rows = cur.fetchall(); conn.close()
        if not rows:
            send_message(phone, t(lang, "error_generic")); return
        lines = "\n".join(
            f"• {r['item_name']} ({r['unit']}): *₦{float(r['avg_p']):,.0f}* ({r['mkts']} mkts)"
            for r in rows
        )
        # ── wa-v153: meter the priced filter result (mirror prices._show_price:204-216).
        # item_name="" → dropped by recent-searches readers; query_type="FILTER" tags it.
        try:
            from shared.query_limit import check_query_limit, log_query
            from shared.db import get_consumer as _gc3
            _cons = _gc3(phone) or {}
            if _cons.get("consumer_id"):
                _allowed, _limit_msg = check_query_limit(phone, _cons)
                if not _allowed:
                    send_message(phone, _limit_msg)
                    clear_session(phone)
                    return
            log_query(phone, _cons, item_name="", market_name=session.get("filter_state",""), query_type="FILTER")
        except Exception as _le:
            import logging; logging.error(f"[filter] query_limit EXCEPTION: {type(_le).__name__}: {_le}", exc_info=True)
        repeat = (
            "\n\n━━━━━━━━━━━━━━━━━━━━━━\n"
            "*1* — Another category\n"
            "*2* — Different region\n"
            "*0* — Menu"
        ) if lang == "en" else (
            "\n\n━━━━━━━━━━━━━━━━━━━━━━\n"
            "*1* — Another category\n"
            "*2* — Different region\n"
            "*0* — Menu"
        )
        session["step"] = 99; save_session(phone, session)
        send_message(phone,
            t(lang, "filter_result",
              state=session["filter_state"], cat=cat["name"], lines=lines) + footer(lang)
            + repeat)
    except Exception as e:
        logging.error(f"[filter._show] {e}")
        send_message(phone, t(lang, "error_generic"))


def _handle_repeat(phone, text, session, lang):
    msg = text.strip().lower()
    if msg in ("0","menu"):
        clear_session(phone); show_main_menu(phone); return
    if msg == "1":
        # Same state — back to category
        cats = session.get("cats", [])
        state = session.get("filter_state", "")
        lines = "\n".join(f"*{i+1}*. {c['name']}" for i,c in enumerate(cats))
        session["step"] = 3; save_session(phone, session)
        send_message(phone, f"🔍 *{state}*\n\n{lines}\n\n*back* — States | *0* — Menu" + footer(lang))
        return
    if msg == "2":
        _pick_region(phone, session, lang); return
    send_message(phone, t(lang, "invalid_choice"))
