import logging,os,requests,uuid
TIER_ORDER=["FREE","SILVER","GOLD","BUSINESS","CORPORATE","ENTERPRISE"]
TIERS={"SILVER":{"price":500,"label":"🥈 SILVER","days":7},"GOLD":{"price":2000,"label":"🥇 GOLD","days":30},"BUSINESS":{"price":15000,"label":"💼 BUSINESS","days":30},"CORPORATE":{"price":500000,"label":"🏢 CORPORATE","days":30},"ENTERPRISE":{"price":1500000,"label":"🏆 ENTERPRISE","days":30},"API_STARTER":{"price":500000,"label":"📡 API STARTER","days":30},"API_BUSINESS":{"price":1000000,"label":"📡 API BUSINESS","days":30},"API_ENTERPRISE":{"price":1500000,"label":"📡 API ENTERPRISE","days":30}}
from shared.sender import send_message
from shared.session import save_session, clear_session
from shared.lang import get_lang
from shared.i18n import t
from consumer.menu import show_main_menu
from shared.db import get_connection

# ── Tier pricing is rank-1 from dbo.Subscription_Tiers (naijaapp has SELECT).
# The hardcoded TIERS map above is now used ONLY for the menu emoji label — never
# for the charge amount, which comes solely from price_ngn. ────────────────────
def _tiers_from_db(tier_ids):
    """{tier_id: {tier_name, price_ngn, billing_cycle}} for the given ids. {} on any error."""
    if not tier_ids: return {}
    try:
        conn = get_connection()
        try:
            cur = conn.cursor(as_dict=True)
            ph = ",".join(["%s"] * len(tier_ids))
            cur.execute(
                "SELECT tier_id, tier_name, price_ngn, billing_cycle "
                "FROM dbo.Subscription_Tiers WHERE tier_id IN (" + ph + ")",
                tuple(tier_ids))
            return {r["tier_id"]: r for r in cur.fetchall()}
        finally:
            conn.close()
    except Exception as e:
        logging.error(f"[tokens] Subscription_Tiers read failed: {e}")
        return {}

def _tier_row(tier):
    """Single-tier dict, or None on error/missing (fail-closed for the charge)."""
    return _tiers_from_db([tier]).get(tier)

# Payments temporarily disabled for the testing phase. Flip to True to
# re-enable Paystack checkout link generation.
PAYMENTS_ENABLED=True

def handle_tokens_flow(phone, message="", session=None, consumer=None, *args):
    session=session or {}; consumer=consumer or {}
    lang=get_lang(session,consumer); text=(message or "").strip(); msg=text.lower()
    step=session.get("step",0)
    if msg in ("0","menu") or (msg=="back" and step==0): clear_session(phone); show_main_menu(phone); return
    if msg=="back" and step==1: session["step"]=0; save_session(phone,session); _menu(phone,session,consumer,lang); return
    if step==0: _menu(phone,session,consumer,lang)
    elif step==1: _pick(phone,text,session,consumer,lang)

def _menu(phone,session,consumer,lang):
    cur_tier=((consumer or {}).get("subscription_tier") or "FREE").upper()
    cur_idx=TIER_ORDER.index(cur_tier) if cur_tier in TIER_ORDER else 0
    available=TIER_ORDER[cur_idx+1:] if cur_idx<len(TIER_ORDER)-1 else []
    if not available: clear_session(phone); send_message(phone,t(lang,"upgrade_top")); return
    db=_tiers_from_db(available)   # one batched query for all available tiers
    def _line(i,t2):
        label=TIERS.get(t2,{}).get('label',t2)
        row=db.get(t2)
        if row and row.get('price_ngn') is not None:
            return f"*{i+1}*. {label} — ₦{int(round(float(row['price_ngn']))):,}"
        return f"*{i+1}*. {label}"   # DB unavailable → label only, never a stale price
    lines="\n".join(_line(i,t2) for i,t2 in enumerate(available))
    session.update({"_flow":"TOKENS","step":1,"cur_tier":cur_tier,"available":available}); save_session(phone,session)
    send_message(phone,t(lang,"upgrade_menu",tier=cur_tier,lines=lines))

def _pick(phone,text,session,consumer,lang):
    available=session.get("available",[])
    try:
        idx=int(text)-1; assert 0<=idx<len(available); tier=available[idx]
    except: send_message(phone,t(lang,"invalid_choice")); return
    if tier in ("CORPORATE","ENTERPRISE"):
        clear_session(phone)
        send_message(phone,"🏢 *CORPORATE & ENTERPRISE PLANS*\n\nFor CORPORATE and ENTERPRISE plans, please visit:\n\n👉 naijamarketintel.com/subscribe\n\nor contact us directly. Our team will set up your account personally.\n\n*menu* — Back to menu")
        return
    if not PAYMENTS_ENABLED:
        clear_session(phone)
        send_message(phone,"Payments are not yet available. You will be notified when subscriptions open. Your current plan is FREE.")
        return
    # Rank-1 price/billing/name from Subscription_Tiers. FAIL CLOSED: a throw,
    # missing row, or NULL price must NOT fall back to the hardcoded TIERS price.
    row=_tier_row(tier)
    if not row or row.get("price_ngn") is None:
        logging.error(f"[tokens] no usable Subscription_Tiers row for {tier} — refusing charge")
        clear_session(phone)
        send_message(phone,"⚠️ We couldn't start your payment right now. Please try again in a moment.\n\n*menu* — Menu")
        return
    label=TIERS.get(tier,{}).get('label',tier)          # emoji label only
    tier_name=row.get("tier_name") or tier              # e.g. "Gold"
    billing_cycle=row.get("billing_cycle") or ""        # e.g. "weekly" (webhook uppercases)
    amount_kobo=int(round(float(row["price_ngn"]) * 100))   # 800.00 -> 80000; no under/overcharge
    price_naira=amount_kobo // 100                       # for display
    secret=os.environ.get("PAYSTACK_SECRET_KEY","")
    if not secret:
        clear_session(phone); send_message(phone,f"💳 {label}\n\nAmount: ₦{price_naira:,}\n\nVisit: naijamarketintel.ng/subscribe\n\n*menu* — Menu"); return
    try:
        cid=(consumer or {}).get("consumer_id","")
        ref=f"NMI-{tier[:3].upper()}-{uuid.uuid4().hex[:8].upper()}"
        email=(consumer or {}).get("email") or f"{phone}@naijamarketintel.ng"
        callback_url=f"https://www.naijamarketintel.com/subscribe/callback?provider=paystack&ref={ref}"
        resp=requests.post("https://api.paystack.co/transaction/initialize",
            headers={"Authorization":f"Bearer {secret}"},
            json={"email":email,"amount":amount_kobo,"reference":ref,"callback_url":callback_url,
                  "metadata":{"phone":phone,"tier":tier,"tier_name":tier_name,
                              "billing_cycle":billing_cycle,"consumer_id":cid}},
            timeout=15)
        data=resp.json()
        if data.get("status") and data.get("data",{}).get("authorization_url"):
            url=data["data"]["authorization_url"]
            send_message(phone,t(lang,"upgrade_link",label=label,price=price_naira,ref=ref,url=url))
        else: raise Exception(data.get("message",""))
    except Exception as e:
        logging.error(f"[tokens] {e}"); clear_session(phone)
        send_message(phone,f"⚠️ Could not generate payment link.\n\nVisit naijamarketintel.ng/subscribe\n\n*menu* — Menu")
