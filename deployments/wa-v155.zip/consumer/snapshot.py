"""consumer/snapshot.py — State market snapshot. SILVER+
Drill-down: Region → State → snapshot results
"""
import logging
TIER_ORDER=["FREE","SILVER","GOLD","BUSINESS","CORPORATE","ENTERPRISE"]
from shared.db import get_connection
from shared.sender import send_message
from shared.session import save_session, clear_session
from shared.lang import get_lang
from shared.i18n import t, footer
from shared.drilldown import REGION_LIST, REGIONS
from consumer.menu import show_main_menu
from shared.nudge import get_nudge


def handle_snapshot(phone, message="", session=None, consumer=None, *args):
    session  = session  or {}
    consumer = consumer or {}
    lang = get_lang(session, consumer)
    text = (message or "").strip()
    msg  = text.lower()
    tier = ((consumer or {}).get("subscription_tier") or "FREE").upper()
    step = session.get("step", 0)

    if msg in ("0", "menu"):
        clear_session(phone); show_main_menu(phone); return

    if msg == "back":
        if step <= 1: clear_session(phone); show_main_menu(phone)
        elif step == 2: _pick_region(phone, session, lang)   # back to region
        return

    if TIER_ORDER.index(tier) < TIER_ORDER.index("SILVER"):
        clear_session(phone)
        send_message(phone, t(lang, "snapshot_locked"))
        return

    if step == 0: _pick_region(phone, session, lang)
    elif step == 1: _pick_state(phone, text, session, lang)
    elif step == 2: _show(phone, text, session, lang)
    elif step == 99: _handle_repeat(phone, text, session, lang)
    else: _pick_region(phone, session, lang)


def _pick_region(phone, session, lang):
    """Step 0→1: Show 6 geopolitical zones."""
    lines = "\n".join(f"*{i+1}*. {r}" for i, r in enumerate(REGION_LIST))
    session.update({"_flow": "SNAPSHOT", "step": 1})
    save_session(phone, session)
    send_message(phone, t(lang, "region_title", lines=lines) + footer(lang))


def _pick_state(phone, text, session, lang):
    """Step 1→2: User picked region, show its states."""
    try:
        idx = int(text) - 1
        assert 0 <= idx < len(REGION_LIST)
        region = REGION_LIST[idx]
    except:
        send_message(phone, t(lang, "invalid_choice")); return

    all_states = REGIONS.get(region, [])
    # Filter to states with actual DB data
    try:
        conn = get_connection(); cur = conn.cursor()
        cur.execute("""
            SELECT DISTINCT state FROM dbo.Latest_Prices_Summary
            WHERE is_nbs_ref=0 AND is_food=1 AND state IS NOT NULL
        """)
        db_states = {r["state"].lower() for r in cur.fetchall()}
        conn.close()
        states = [s for s in all_states if s.lower() in db_states] or all_states
    except Exception as e:
        logging.error(f"[snapshot._pick_state] {e}")
        states = all_states

    lines = "\n".join(f"*{i+1}*. {s}" for i, s in enumerate(states))
    session.update({"step": 2, "region": region, "states": states})
    save_session(phone, session)
    send_message(phone, t(lang, "state_title", region=region, lines=lines) + footer(lang))


def _show(phone, text, session, lang):
    """Step 2: User picked state, show snapshot."""
    states = session.get("states", [])
    try:
        idx = int(text) - 1; assert 0 <= idx < len(states); state = states[idx]
    except:
        send_message(phone, t(lang, "invalid_choice")); return
    try:
        conn = get_connection(); cur = conn.cursor()
        cur.execute("""
            SELECT TOP 15 item_name,
                   AVG(price_naira) AS avg_p,
                   AVG(price_change_pct) AS avg_chg
            FROM dbo.Latest_Prices_Summary
            WHERE state=%s AND is_nbs_ref=0 AND is_food=1 AND price_naira>0
            GROUP BY item_name ORDER BY avg_p DESC
        """, (state,))
        rows = cur.fetchall()
        cur.execute("""
            SELECT COUNT(DISTINCT market_id) AS cnt
            FROM dbo.Latest_Prices_Summary
            WHERE state=%s AND is_nbs_ref=0
        """, (state,))
        mkts = (cur.fetchone() or {}).get("cnt", 0)
        conn.close()
        if not rows:
            send_message(phone, t(lang, "error_generic")); return
        up = sum(1 for r in rows if float(r["avg_chg"] or 0) > 0.5)
        dn = sum(1 for r in rows if float(r["avg_chg"] or 0) < -0.5)
        lines = "\n".join(
            ("📈" if float(r["avg_chg"] or 0) > 0.5 else
             "📉" if float(r["avg_chg"] or 0) < -0.5 else "➡️") +
            f" {r['item_name']}: *₦{float(r['avg_p']):,.0f}*"
            for r in rows
        )
        # ── wa-v153: meter the priced snapshot (mirror prices._show_price:204-216).
        # Reached only via FLOW_MAP continuation, which the router does NOT meter.
        # item_name="" so recent-searches readers (WA history + web/mobile, both
        # gated on item_name<>'') drop it — a snapshot is not a commodity search.
        # query_type="SNAPSHOT" keeps it analytically distinct; counting ignores both.
        try:
            from shared.query_limit import check_query_limit, log_query
            from shared.db import get_consumer as _gc3
            _cons = _gc3(phone) or {}
            if _cons.get("consumer_id"):
                _allowed, _limit_msg = check_query_limit(phone, _cons)
                if not _allowed:
                    send_message(phone, _limit_msg)
                    clear_session(phone)
                    return
            log_query(phone, _cons, item_name="", market_name=state, query_type="SNAPSHOT")
        except Exception as _le:
            import logging; logging.error(f"[snapshot] query_limit EXCEPTION: {type(_le).__name__}: {_le}", exc_info=True)
        # After snapshot offer same region or different
        repeat = (
            "\n\n━━━━━━━━━━━━━━━━━━━━━━\n"
            "*1* — Another state in this region\n"
            "*2* — Different region\n"
            "*0* — Menu"
        ) if lang == "en" else (
            "\n\n━━━━━━━━━━━━━━━━━━━━━━\n"
            "*1* — Another state for same region\n"
            "*2* — Different region\n"
            "*0* — Menu"
        )
        session["step"] = 99
        save_session(phone, session)
        from shared.freshness import freshness_note
        # Use today's date for snapshot freshness check
        from datetime import date as _date
        snap_date = rows[0].get("price_date") if rows else None
        send_message(phone,
            t(lang, "snapshot_result", state=state, mkts=mkts, up=up, dn=dn, lines=lines)
            + freshness_note(snap_date, lang)
            + repeat + get_nudge(lang, "SNAPSHOT"))
    except Exception as e:
        logging.error(f"[snapshot._show] {e}")
        send_message(phone, t(lang, "error_generic"))


# step 99 is handled by handle_snapshot dispatch
# Add it to the main dispatch above:
# elif step == 99: _handle_repeat(phone, text, session, lang)


def _handle_repeat(phone, text, session, lang):
    msg = text.strip().lower()
    if msg in ("0","menu"):
        clear_session(phone); show_main_menu(phone); return
    if msg == "1":
        # Same region — back to state selection
        states = session.get("states", [])
        region = session.get("region", "")
        lines = "\n".join(f"*{i+1}*. {s}" for i,s in enumerate(states))
        session["step"] = 2; save_session(phone, session)
        send_message(phone, t(lang, "state_title", region=region, lines=lines) + footer(lang)); return
    if msg == "2":
        # Different region
        _pick_region(phone, session, lang); return
    send_message(phone, t(lang, "invalid_choice"))
