import logging
from shared.db import get_connection
from shared.sender import send_message
from shared.session import clear_session
from shared.lang import get_lang
from shared.i18n import t
from consumer.menu import show_main_menu
from shared.nudge import get_nudge

def handle_brief(phone, message="", session=None, consumer=None, *args):
    session=session or {}; consumer=consumer or {}
    lang=get_lang(session,consumer); msg=(message or "").strip().lower()
    if msg in ("0","menu","back"): clear_session(phone); show_main_menu(phone); return
    clear_session(phone); _show(phone,lang)

def _show(phone,lang):
    try:
        conn=get_connection(); cur=conn.cursor()
        cur.execute("SELECT TOP 5 item_name,AVG(price_naira) AS avg_p,AVG(price_change_pct) AS avg_chg FROM dbo.Latest_Prices_Summary WHERE is_nbs_ref=0 AND is_food=1 AND price_change_pct>1 GROUP BY item_name ORDER BY avg_chg DESC")
        risers=cur.fetchall()
        cur.execute("SELECT TOP 5 item_name,AVG(price_naira) AS avg_p,AVG(price_change_pct) AS avg_chg FROM dbo.Latest_Prices_Summary WHERE is_nbs_ref=0 AND is_food=1 AND price_change_pct<-1 GROUP BY item_name ORDER BY avg_chg ASC")
        fallers=cur.fetchall()
        cur.execute("SELECT MAX(price_date) AS dt FROM dbo.Latest_Prices_Summary WHERE is_nbs_ref=0")
        dt=str((cur.fetchone() or {}).get("dt",""))[:10]; conn.close()
        up="\n".join(f"\U0001f4c8 {r['item_name']}: *\u20a6{float(r['avg_p']):,.0f}* (+{float(r['avg_chg']):.1f}%)" for r in risers) or ("No movers" if lang=="en" else "Nothing dey move up")
        dn="\n".join(f"\U0001f4c9 {r['item_name']}: *\u20a6{float(r['avg_p']):,.0f}* ({float(r['avg_chg']):.1f}%)" for r in fallers) or ("No movers" if lang=="en" else "Nothing dey move down")
        # ── wa-v153: consume quota for BRIEF. NO internal check — router entry
        # check (__init__.py:815) covers it ONLY while brief stays single-shot with
        # NO _flow (clears session on entry, KEYWORD_MAP-only). Give it a persistent
        # _flow and you must add check_query_limit here. item_name="" → dropped by
        # recent-searches; query_type="BRIEF" tags it.
        try:
            from shared.query_limit import log_query
            from shared.db import get_consumer as _gc3
            _cons = _gc3(phone) or {}
            log_query(phone, _cons, item_name="", market_name="", query_type="BRIEF")
        except Exception as _le:
            import logging; logging.error(f"[brief] log_query EXCEPTION: {type(_le).__name__}: {_le}", exc_info=True)
        send_message(phone,t(lang,"brief_result",date=dt,risers=up,fallers=dn)+get_nudge(lang,"BRIEF"))
    except Exception as e:
        logging.error(f"[brief] {e}"); send_message(phone,t(lang,"error_generic"))

def _handle_repeat_search(phone, text, session, lang):
    """After result: 1=search again, 0=menu."""
    from shared.session import clear_session, save_session
    from consumer.menu import show_main_menu
    from shared.sender import send_message
    from shared.i18n import t
    msg = text.strip().lower()
    if msg == "0" or msg in ("menu", "back"):
        clear_session(phone); show_main_menu(phone); return
    if msg == "1":
        session["step"] = 0; save_session(phone, session)
        handle_brief(phone, "", session, None)
        return
    send_message(phone, t(lang, "invalid_choice"))
