import logging, uuid, pymssql
from shared.db import get_connection
from shared.sender import send_message
from shared.session import save_session, clear_session
from shared.lang import get_lang
from shared.i18n import t, footer
from consumer.menu import show_main_menu

# ============================================================================
# WA FAVORITES — canonical store (dbo.Consumer_Favorites), cross-surface.
# Repointed off the legacy Consumers.preferences JSON blob onto the same table
# web + mobile use. Naked-phone key, resolve name->item_id, one-ID-XOR
# (item_id set / market_id NULL), soft-delete via is_active. Items only this
# pass — markets deferred (add UX stays free-text commodity).
# WA-native idioms: shared.db.get_connection (pymssql, %s params, as_dict),
# explicit conn.commit()/conn.close(), SYSUTCDATETIME() inline.
# ============================================================================


def handle_favorites(phone, message="", session=None, consumer=None, *args):
    session=session or {}; consumer=consumer or {}
    lang=get_lang(session,consumer); text=(message or "").strip(); msg=text.lower()
    step=session.get("step",0)
    if msg in ("0","menu","back") and step==0: clear_session(phone); show_main_menu(phone); return
    if msg=="0": clear_session(phone); show_main_menu(phone); return
    if step==0: _menu(phone,session,lang)
    elif step==1: _action(phone,text,session,consumer,lang)
    elif step==2: _add(phone,text,session,consumer,lang)


def _naked(phone):
    # Identical canonical form to shared/db.py (phone.replace("+","").strip())
    return (phone or "").replace("+","").strip()


def _fav_item_names(cur, phone):
    """Active item favorites for this phone, canonical order (created_at)."""
    cur.execute(
        "SELECT item_name FROM dbo.Consumer_Favorites "
        "WHERE REPLACE(phone_number,'+','') = REPLACE(%s,'+','') "
        "AND favorite_type = 'item' AND is_active = 1 "
        "ORDER BY created_at",
        (_naked(phone),)
    )
    return [r["item_name"] for r in cur.fetchall() if r.get("item_name")]


def _menu(phone,session,lang):
    session.update({"_flow":"FAVORITES","step":1}); save_session(phone,session)
    send_message(phone,t(lang,"fav_menu"))


def _action(phone,text,session,consumer,lang):
    if text=="1":
        try:
            conn=get_connection(); cur=conn.cursor()
            favs=_fav_item_names(cur,phone)
            conn.close()
        except Exception as e:
            logging.error(f"[favorites._action.view] {e}"); send_message(phone,t(lang,"error_generic")); return
        if not favs: send_message(phone,t(lang,"fav_none")); return
        lines="\n".join(f"⭐ {f}" for f in favs)
        send_message(phone,f"⭐ *MY FAVORITES*\n\n{lines}\n\n*0* — Menu" + footer(lang)); return
    if text=="2":
        session.update({"step":2}); save_session(phone,session)
        send_message(phone,t(lang,"fav_add_prompt")); return
    if text=="3":
        _check_prices(phone,consumer,lang); return
    send_message(phone,t(lang,"invalid_choice"))


def _add(phone,text,session,consumer,lang):
    try:
        conn=get_connection(); cur=conn.cursor()
        # Resolve typed text -> canonical item. Same LIKE / is_nbs_ref / is_food
        # filter as the legacy resolver, now returning item_id + category_id
        # (Latest_Prices_Summary already carries both).
        cur.execute(
            "SELECT TOP 1 item_id, item_name, category_id "
            "FROM dbo.Latest_Prices_Summary "
            "WHERE item_name LIKE %s AND is_nbs_ref = 0 AND is_food = 1 "
            "GROUP BY item_id, item_name, category_id",
            (f"%{text}%",)
        )
        row=cur.fetchone()
        if not row:
            conn.close(); send_message(phone,t(lang,"not_found",q=text)); return
        item_id=row["item_id"]; item_name=row["item_name"]; category_id=row.get("category_id")

        naked=_naked(phone)

        # consumer_id for the row (nullable column, best-effort). Consumers has
        # two phone cols (phone + phone_number) — match either, any form.
        cur.execute(
            "SELECT TOP 1 consumer_id FROM dbo.Consumers "
            "WHERE REPLACE(phone,'+','') = %s OR REPLACE(phone_number,'+','') = %s",
            (naked,naked)
        )
        crow=cur.fetchone(); consumer_id=crow["consumer_id"] if crow else None

        favorite_id="FAV_"+uuid.uuid4().hex[:16]

        try:
            # one-ID-XOR: item_id set, market_* NULL.
            cur.execute(
                "INSERT INTO dbo.Consumer_Favorites "
                "(favorite_id, phone_number, consumer_id, favorite_type, "
                " market_id, market_name, state, region_code, "
                " item_id, item_name, category_id, "
                " is_active, created_at, updated_at) "
                "VALUES (%s, %s, %s, 'item', "
                " NULL, NULL, NULL, NULL, "
                " %s, %s, %s, "
                " 1, SYSUTCDATETIME(), SYSUTCDATETIME())",
                (favorite_id, naked, consumer_id, item_id, item_name, category_id)
            )
            conn.commit()
        except pymssql.Error as e:
            # UX_ConsFav_Identity duplicate -> SQL Server 2601 (unique index) or
            # 2627 (unique constraint). pymssql surfaces the number in the error
            # text; resurrect/confirm-active instead of erroring (idempotent).
            s=str(e)
            if "2601" in s or "2627" in s or "UX_ConsFav_Identity" in s:
                # Clear the failed-INSERT transaction state first, so the
                # resurrect UPDATE never hits a "connection busy" state on any
                # pymssql version.
                conn.rollback()
                cur.execute(
                    "UPDATE dbo.Consumer_Favorites "
                    "SET is_active = 1, updated_at = SYSUTCDATETIME() "
                    "WHERE REPLACE(phone_number,'+','') = REPLACE(%s,'+','') "
                    "AND favorite_type = 'item' AND item_id = %s",
                    (naked, item_id)
                )
                conn.commit()
            else:
                conn.close(); raise

        conn.close(); clear_session(phone)
        send_message(phone,t(lang,"fav_added",item=item_name))
    except Exception as e:
        logging.error(f"[favorites._add] {e}"); send_message(phone,t(lang,"error_generic"))


def _check_prices(phone,consumer,lang):
    try:
        conn=get_connection(); cur=conn.cursor()
        favs=_fav_item_names(cur,phone)
        if not favs:
            conn.close(); send_message(phone,t(lang,"fav_none")); return
        lines=[]
        for item in favs[:5]:
            cur.execute("SELECT AVG(price_naira) AS avg_p,AVG(price_change_pct) AS chg FROM dbo.Latest_Prices_Summary WHERE item_name=%s AND is_nbs_ref=0 AND is_food=1 AND price_naira>0",(item,))
            r=cur.fetchone()
            if r and r.get("avg_p"):
                avg=float(r["avg_p"]); chg=float(r.get("chg") or 0)
                arrow="\U0001f4c8" if chg>0.5 else ("\U0001f4c9" if chg<-0.5 else "➡️")
                lines.append(f"{arrow} {item}: *₦{avg:,.0f}*")
        conn.close(); clear_session(phone)
        bar="━"*22
        title="⭐ *FAVORITES PRICES*" if lang=="en" else "⭐ *FAVORITES PRICE*"
        send_message(phone,f"{title}\n{bar}\n\n"+("\n".join(lines) if lines else "No price data")+f"\n\n{bar}\n*menu* — Menu")
    except Exception as e:
        logging.error(f"[favorites._check_prices] {e}"); send_message(phone,t(lang,"error_generic"))
