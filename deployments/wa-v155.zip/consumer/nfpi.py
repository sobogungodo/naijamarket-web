import logging
from shared.db import get_connection
from shared.sender import send_message
from shared.session import clear_session
from shared.lang import get_lang
from shared.i18n import t
from consumer.menu import show_main_menu

def handle_nfpi(phone, message="", session=None, consumer=None, *args):
    session=session or {}; consumer=consumer or {}
    lang=get_lang(session,consumer); msg=(message or "").strip().lower()
    if msg in ("0","menu","back"): clear_session(phone); show_main_menu(phone); return
    clear_session(phone); _show(phone,lang)

def _show(phone,lang):
    try:
        conn=get_connection(); cur=conn.cursor()
        cur.execute("SELECT TOP 10 item_name,AVG(price_naira) AS avg_p,AVG(price_change_pct) AS avg_chg FROM dbo.Latest_Prices_Summary WHERE is_nbs_ref=0 AND is_food=1 AND price_naira>0 GROUP BY item_name ORDER BY avg_p DESC")
        rows=cur.fetchall()
        cur.execute("SELECT TOP 1 index_value,mom_change_pct,last_updated FROM dbo.Inflation_Cache ORDER BY last_updated DESC")
        inf=cur.fetchone(); conn.close()
        basket=sum(float(r["avg_p"] or 0) for r in rows)
        index_val=float((inf or {}).get("index_value") or 0); mom=float((inf or {}).get("mom_change_pct") or 0)
        updated=str((inf or {}).get("last_updated") or "")[:10]
        index_line=f"\U0001f4c8 Index: *{index_val:.1f}* ({mom:+.2f}% MoM)\n" if index_val else ""
        lines="\n".join(("\U0001f4c8" if float(r["avg_chg"] or 0)>0.5 else ("\U0001f4c9" if float(r["avg_chg"] or 0)<-0.5 else "\u27a1\ufe0f"))+f" {r['item_name']}: *\u20a6{float(r['avg_p']):,.0f}*" for r in rows)
        # ── wa-v153: consume quota for NFPI. NO internal check_query_limit —
        # the router (__init__.py:815) gate-checks at entry, and that is
        # SUFFICIENT *only because* handle_nfpi clears session on entry and sets
        # NO _flow, so nfpi is reachable ONLY via KEYWORD_MAP, never via FLOW_MAP
        # continuation. If you ever give nfpi a persistent _flow / multi-step
        # drill-down, this becomes an unmetered leak (like snapshot/filter were) —
        # add check_query_limit HERE at that point. item_name="" keeps it out of
        # recent-searches; query_type="NFPI" tags it; counting ignores both.
        try:
            from shared.query_limit import log_query
            from shared.db import get_consumer as _gc3
            _cons = _gc3(phone) or {}
            log_query(phone, _cons, item_name="", market_name="", query_type="NFPI")
        except Exception as _le:
            import logging; logging.error(f"[nfpi] log_query EXCEPTION: {type(_le).__name__}: {_le}", exc_info=True)
        send_message(phone,t(lang,"nfpi_result",basket=basket,index_line=index_line,date=updated,lines=lines))
    except Exception as e:
        logging.error(f"[nfpi] {e}"); send_message(phone,t(lang,"error_generic"))

def _handle_repeat_search(phone, text, session, lang):
    """After result: 1=search again, 0=menu."""
    from shared.session import clear_session, save_session
    from consumer.menu import show_main_menu
    from shared.sender import send_message
    from shared.i18n import t
    msg = text.strip().lower()
    if msg == "0" or msg in ("menu", "back"):
        clear_session(phone); show_main_menu(phone); return
    if msg == "1":
        session["step"] = 0; save_session(phone, session)
        handle_nfpi(phone, "", session, None)
        return
    send_message(phone, t(lang, "invalid_choice"))
