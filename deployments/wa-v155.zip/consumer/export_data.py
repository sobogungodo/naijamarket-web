import logging
TIER_ORDER=["FREE","SILVER","GOLD","BUSINESS","CORPORATE","ENTERPRISE"]
from shared.db import get_connection
from shared.sender import send_message
from shared.session import clear_session
from shared.lang import get_lang
from shared.i18n import t
from consumer.menu import show_main_menu

def handle_export(phone, message="", session=None, consumer=None, *args):
    session=session or {}; consumer=consumer or {}
    lang=get_lang(session,consumer); tier=((consumer or {}).get("subscription_tier") or "FREE").upper()
    msg=(message or "").strip().lower()
    if msg in ("0","menu","back"): clear_session(phone); show_main_menu(phone); return
    if TIER_ORDER.index(tier)<TIER_ORDER.index("BUSINESS"): clear_session(phone); send_message(phone,t(lang,"export_locked")); return
    clear_session(phone)
    try:
        conn=get_connection(); cur=conn.cursor()
        cur.execute("SELECT TOP 20 item_name,state,AVG(price_naira) AS avg_p,MIN(price_naira) AS min_p,MAX(price_naira) AS max_p,COUNT(DISTINCT market_id) AS mkts FROM dbo.Latest_Prices_Summary WHERE is_nbs_ref=0 AND is_food=1 AND price_naira>0 GROUP BY item_name,state ORDER BY item_name,state")
        rows=cur.fetchall()
        cur.execute("SELECT MAX(price_date) AS dt FROM dbo.Latest_Prices_Summary WHERE is_nbs_ref=0")
        dt=str((cur.fetchone() or {}).get("dt",""))[:10]; conn.close()
        header=f"NAIJAMARKET INTEL EXPORT — {dt}\n{'='*30}\n"
        lines="\n".join(f"{r['item_name']} | {r['state']} | Avg:\u20a6{float(r['avg_p']):,.0f} | Min:\u20a6{float(r['min_p']):,.0f} | Max:\u20a6{float(r['max_p']):,.0f} | {r['mkts']}mkts" for r in rows)
        # ── wa-v153: consume quota for EXPORT (BUSINESS+; the tier lock above
        # returns before here, so locked attempts log nothing). NO internal check —
        # router entry check (__init__.py:815) covers it while export stays
        # single-shot with NO _flow. item_name="" → dropped by recent-searches;
        # query_type="EXPORT" tags it. `consumer` is the handler param (in scope).
        try:
            from shared.query_limit import log_query
            log_query(phone, consumer, item_name="", market_name="", query_type="EXPORT")
        except Exception as _le:
            import logging; logging.error(f"[export] log_query EXCEPTION: {type(_le).__name__}: {_le}", exc_info=True)
        send_message(phone,(header+lines+"\n\n_Showing top 20 items_\n*menu* — Menu")[:4000])
    except Exception as e:
        logging.error(f"[export] {e}"); send_message(phone,t(lang,"error_generic"))
