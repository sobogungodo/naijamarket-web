"""
daily_trader_summary — Azure Function Timer
Fires daily at 19:00 UTC (20:00 WAT)
DEBUG VERSION — skip logic removed for testing
"""

import logging
import os
from datetime import datetime, timezone
import pymssql
import requests

def get_connection():
    return pymssql.connect(
        server   = os.environ['SQL_SERVER'],
        user     = os.environ['SQL_USERNAME'],
        password = os.environ['SQL_PASSWORD'],
        database = os.environ['SQL_DATABASE'],
        timeout  = 0,
        as_dict  = True,
    )

def send_whatsapp(phone: str, message: str) -> bool:
    token    = os.environ.get('META_ACCESS_TOKEN', '')
    phone_id = os.environ.get('META_PHONE_NUMBER_ID', '1040415905832961')

    if not token:
        logging.error('[daily_summary] META_ACCESS_TOKEN not set')
        return False

    digits = phone.replace('+', '').replace(' ', '').lstrip('0')
    if digits.startswith('234') and len(digits) == 13:
        to = digits
    elif digits.startswith('0') and len(digits) == 11:
        to = '234' + digits[1:]
    else:
        to = digits

    logging.info(f'[daily_summary] Sending to: {to}')

    url     = f'https://graph.facebook.com/v21.0/{phone_id}/messages'
    payload = {
        'messaging_product': 'whatsapp',
        'to':                to,
        'type':              'text',
        'text':              {'body': message}
    }
    headers = {
        'Authorization': f'Bearer {token}',
        'Content-Type':  'application/json',
    }

    try:
        res = requests.post(url, json=payload, headers=headers, timeout=15)
        logging.info(f'[daily_summary] Meta response: {res.status_code} — {res.text[:300]}')
        return res.status_code == 200
    except Exception as e:
        logging.error(f'[daily_summary] send error: {e}')
        return False

def get_trader_day_summary(conn, phone: str, trader_id: str) -> dict:
    cur = conn.cursor()

    cur.execute("""
        SELECT
            COUNT(*)                                                             AS total,
            SUM(CASE WHEN validation_status = 'APPROVED'  THEN 1 ELSE 0 END)   AS approved,
            SUM(CASE WHEN validation_status = 'PENDING'   THEN 1 ELSE 0 END)   AS pending,
            SUM(CASE WHEN validation_status = 'REJECTED'  THEN 1 ELSE 0 END)   AS rejected
        FROM dbo.Submissions
        WHERE trader_phone = %s
          AND CAST(TRY_CAST(submitted_at AS DATETIME2) AS DATE) = CAST(GETUTCDATE() AS DATE)
          AND trader_id NOT LIKE 'SYN-%%'
    """, (phone,))
    stats = cur.fetchone() or {}

    cur.execute("""
        SELECT DISTINCT item AS item_name
        FROM   dbo.Submissions
        WHERE  trader_phone = %s
          AND  CAST(TRY_CAST(submitted_at AS DATETIME2) AS DATE) = CAST(GETUTCDATE() AS DATE)
          AND  trader_id NOT LIKE 'SYN-%%'
        ORDER BY item
    """, (phone,))
    products = [r['item_name'] for r in cur.fetchall()]

    cur.execute("""
        SELECT ISNULL(current_balance, 0) AS balance
        FROM   dbo.Traders_register
        WHERE  phone_number = %s
    """, (phone,))
    bal_row = cur.fetchone()
    balance = float(bal_row['balance']) if bal_row else 0.0

    return {
        'total':    int(stats.get('total',    0)),
        'approved': int(stats.get('approved', 0)),
        'pending':  int(stats.get('pending',  0)),
        'rejected': int(stats.get('rejected', 0)),
        'products': products,
        'balance':  balance,
    }

def build_message(first_name: str, summary: dict) -> str:
    today  = datetime.now(timezone.utc).strftime('%A, %d %b %Y')
    earned = summary['approved'] * 20
    total  = summary['total']

    if total == 0:
        return (
            f"Good evening {first_name}! 🌙\n\n"
            f"📊 *Your NaijaMarket Summary — {today}*\n"
            f"━━━━━━━━━━━━━━━━━━━━\n\n"
            f"You did not submit any prices today.\n\n"
            f"Come back tomorrow and earn ₦20 per approved submission! 💰\n\n"
            f"Type *menu* to access the market."
        )

    products = summary['products']
    if len(products) <= 10:
        product_list = '\n'.join(f'  • {p}' for p in products)
    else:
        product_list = '\n'.join(f'  • {p}' for p in products[:10])
        product_list += f'\n  • ...and {len(products) - 10} more'

    balance       = summary['balance']
    balance_note  = ''
    if balance >= 500:
        balance_note = f"\n💳 *Balance ready for payout:* ₦{balance:,.0f}"
    elif balance > 0:
        balance_note = f"\n💰 *Pending balance:* ₦{balance:,.0f}"

    pending_note  = f"⏳ {summary['pending']} still being verified\n"  if summary['pending']  else ''
    rejected_note = f"❌ {summary['rejected']} rejected\n"              if summary['rejected'] else ''

    return (
        f"Good evening {first_name}! 🌙\n\n"
        f"📊 *Your NaijaMarket Summary — {today}*\n"
        f"━━━━━━━━━━━━━━━━━━━━\n\n"
        f"📦 *Submissions today:* {total}\n"
        f"✅ *Approved:* {summary['approved']}\n"
        f"{pending_note}"
        f"{rejected_note}\n"
        f"💵 *Earned today:* ₦{earned:,}\n"
        f"{balance_note}\n\n"
        f"🛒 *Products submitted:*\n{product_list}\n\n"
        f"Keep it up! 🇳🇬\n"
        f"Type *menu* to submit more prices."
    )

def main(mytimer) -> None:
    utc_now = datetime.now(timezone.utc)
    logging.info(f'[daily_summary] START {utc_now.isoformat()}')

    conn        = None
    sent_count  = 0
    skip_count  = 0
    error_count = 0

    try:
        conn = get_connection()
        cur  = conn.cursor()

        cur.execute("""
            SELECT phone_number, trader_id,
                   ISNULL(first_name, ISNULL(full_name, 'Trader')) AS first_name
            FROM   dbo.Traders_register
            WHERE  registration_status = 'APPROVED'
              AND  phone_number IS NOT NULL
              AND  phone_number != ''
              AND  phone_number NOT LIKE 'SYN%%'
            ORDER BY phone_number
        """)
        traders = cur.fetchall()
        logging.info(f'[daily_summary] Found {len(traders)} approved traders')

        for trader in traders:
            phone      = trader['phone_number']
            trader_id  = trader['trader_id']
            first_name = (trader['first_name'] or 'Trader').split()[0]

            try:
                summary = get_trader_day_summary(conn, phone, trader_id)
                logging.info(f'[daily_summary] {phone}: total={summary["total"]} balance={summary["balance"]}')

                # Send to ALL traders — no skip during testing
                message = build_message(first_name, summary)
                success = send_whatsapp(phone, message)

                if success:
                    sent_count += 1
                    logging.info(f'[daily_summary] ✓ Sent to {phone}')
                else:
                    error_count += 1
                    logging.warning(f'[daily_summary] ✗ Failed {phone}')

            except Exception as e:
                error_count += 1
                logging.error(f'[daily_summary] Error for {phone}: {e}')

    except Exception as e:
        logging.error(f'[daily_summary] FATAL: {e}')
        raise
    finally:
        if conn:
            conn.close()

    logging.info(f'[daily_summary] DONE sent={sent_count} skipped={skip_count} errors={error_count}')
