import azure.functions as func
import logging, os
import pymssql, requests

def get_connection():
    return pymssql.connect(server=os.environ["SQL_SERVER"], user=os.environ["SQL_USER"], password=os.environ["SQL_PASSWORD"], database=os.environ["SQL_DATABASE"], timeout=0, login_timeout=30)

def send_whatsapp(phone, message):
    token = os.environ.get("META_ACCESS_TOKEN", "")
    phone_id = os.environ.get("META_PHONE_NUMBER_ID", "1040415905832961")
    if not token: return False
    if not phone.startswith('+'): phone = '+' + phone
    try:
        r = requests.post(f"https://graph.facebook.com/v18.0/{phone_id}/messages", json={"messaging_product":"whatsapp","to":phone.replace('+',''),"type":"text","text":{"body":message}}, headers={"Authorization":f"Bearer {token}","Content-Type":"application/json"}, timeout=10)
        return r.status_code == 200
    except Exception as e:
        logging.error(f"[price_alert_checker] WA error: {e}"); return False

def fmt_msg(alert, price):
    item, market, target = alert['item_name'], alert['market_name'], float(alert['target_price'])
    t = alert['alert_type']
    if t == 'PRICE_DROP':
        return f"\U0001f514 *Price Alert \u2014 {item}*\n\nPrice dropped to your target!\n\n\U0001f4cd Market: {market}\n\U0001f4b0 Current: \u20a6{price:,.0f}\n\U0001f3af Target: \u20a6{target:,.0f}\n\nReply *1* to check prices."
    elif t == 'PRICE_RISE':
        return f"\u26a0\ufe0f *Price Alert \u2014 {item}*\n\nPrice has risen above your alert!\n\n\U0001f4cd Market: {market}\n\U0001f4b0 Current: \u20a6{price:,.0f}\n\U0001f3af Alert level: \u20a6{target:,.0f}\n\nReply *1* to check prices."
    return f"\U0001f514 *Price Alert \u2014 {item}*\n\n\U0001f4cd {market}\n\U0001f4b0 \u20a6{price:,.0f} (target \u20a6{target:,.0f})\n\nReply *1* to check prices."

def main(myTimer: func.TimerRequest) -> None:
    logging.info("[price_alert_checker] Starting")
    try:
        conn = get_connection()
        cur = conn.cursor(as_dict=True)
        cur.execute("SELECT alert_id, consumer_id, phone_number, market_id, market_name, item_id, item_name, target_price, alert_type FROM dbo.Price_Alerts WHERE status = 'ACTIVE'")
        alerts = cur.fetchall()
        if not alerts:
            logging.info("[price_alert_checker] No active alerts"); conn.close(); return
        logging.info(f"[price_alert_checker] Checking {len(alerts)} alerts")
        triggered = failed = 0
        for alert in alerts:
            try:
                cur.execute("SELECT TOP 1 price_naira FROM dbo.Latest_Prices_Summary WHERE item_id=%s AND market_id=%s AND is_nbs_ref=0 AND is_food=1 ORDER BY last_updated DESC", (alert['item_id'], alert['market_id']))
                row = cur.fetchone()
                if not row:
                    cur.execute("SELECT TOP 1 price_naira FROM dbo.Latest_Prices_Summary WHERE item_id=%s AND is_nbs_ref=0 AND is_food=1 ORDER BY last_updated DESC", (alert['item_id'],))
                    row = cur.fetchone()
                if not row: continue
                current = float(row['price_naira'])
                target = float(alert['target_price'])
                t = alert['alert_type']
                if not ((t == 'PRICE_DROP' and current <= target) or (t == 'PRICE_RISE' and current >= target) or t == 'ANY_CHANGE'):
                    continue
                success = send_whatsapp(alert['phone_number'], fmt_msg(alert, current))
                cur.execute("INSERT INTO dbo.Alert_Notifications (alert_id,phone_number,item_name,market_name,target_price,triggered_price,alert_type,channel,recipient,status,sent_at,created_at) VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,GETUTCDATE(),GETUTCDATE())", (alert['alert_id'], alert['phone_number'], alert['item_name'], alert['market_name'], target, current, t, 'WHATSAPP', alert['phone_number'], 'SENT' if success else 'FAILED'))
                cur.execute("UPDATE dbo.Price_Alerts SET status='TRIGGERED', triggered_at=GETUTCDATE(), updated_at=GETUTCDATE() WHERE alert_id=%s", (alert['alert_id'],))
                conn.commit()
                if success: triggered += 1
                else: failed += 1
            except Exception as e:
                logging.error(f"[price_alert_checker] Alert error: {e}"); failed += 1
        logging.info(f"[price_alert_checker] Done. Triggered:{triggered} Failed:{failed}")
        conn.close()
    except Exception as e:
        logging.error(f"[price_alert_checker] Fatal: {e}"); raise
