"""
validation_timeout_handler
==========================
Fires every 30 minutes.
Scans Validation_Queue for slots where the validator has not responded
within their deadline. Replaces timed-out validators with fresh eligible
ones and notifies them via WhatsApp.

Eligibility rules for replacement validator:
  - status = 'ACTIVE'
  - registration_status = 'APPROVED'
  - NOT already assigned to this submission (v1/v2/v3 phone)
  - NOT suspended
  - weekly_assignments < weekly_assignment_limit (or limit is 0/NULL = unlimited)
  - market_id matches the submission's market_id (preferred; falls back to any market)
"""
import logging
import os
import pymssql
from datetime import datetime, timezone

import azure.functions as func


def _get_conn():
    return pymssql.connect(
        server=os.environ["SQL_SERVER"],
        user=os.environ.get("SQL_USERNAME") or os.environ.get("SQL_USER"),
        password=os.environ["SQL_PASSWORD"],
        database=os.environ.get("SQL_DATABASE", "naijafoodmarket-live"),
        timeout=30,
        as_dict=True,
    )


def _send_wa(phone, message):
    """Send WhatsApp message via Meta Cloud API."""
    import requests
    token    = os.environ.get("META_ACCESS_TOKEN", "")
    phone_id = os.environ.get("META_PHONE_NUMBER_ID", "")
    if not token or not phone_id:
        logging.warning("[timeout_handler] META env vars missing — WA notify skipped")
        return
    clean = phone.lstrip("+")
    url   = f"https://graph.facebook.com/v19.0/{phone_id}/messages"
    payload = {
        "messaging_product": "whatsapp",
        "to": clean,
        "type": "text",
        "text": {"body": message}
    }
    try:
        r = requests.post(url, json=payload,
                          headers={"Authorization": f"Bearer {token}"},
                          timeout=10)
        if r.status_code != 200:
            logging.warning(f"[timeout_handler] WA send failed {r.status_code}: {r.text[:100]}")
    except Exception as e:
        logging.error(f"[timeout_handler] WA send error: {e}")


def _find_replacement(conn, market_id, exclude_phones):
    """
    Find next eligible validator for a given market.
    Tries market match first, then any market.
    Returns dict or None.
    """
    cur = conn.cursor()
    exclude = tuple(exclude_phones) if exclude_phones else ("__none__",)

    for market_filter in [market_id, None]:
        query = """
            SELECT TOP 1
                validator_id, phone_number, full_name,
                market_id, weekly_assignments, weekly_assignment_limit
            FROM dbo.Validators
            WHERE status = 'ACTIVE'
              AND registration_status = 'APPROVED'
              AND (is_suspended = 0 OR is_suspended IS NULL)
              AND phone_number NOT IN %s
              AND (
                  weekly_assignment_limit IS NULL
                  OR weekly_assignment_limit = 0
                  OR weekly_assignments < weekly_assignment_limit
              )
        """
        params = [exclude]
        if market_filter:
            query += " AND market_id = %s"
            params.append(market_filter)
        query += " ORDER BY weekly_assignments ASC, last_assignment_at ASC"

        cur.execute(query, params)
        row = cur.fetchone()
        if row:
            return row
    return None


def _notify_new_validator(phone, full_name, submission_info):
    market  = submission_info.get("market", "your assigned market")
    item    = submission_info.get("item", "an item")
    price   = submission_info.get("price", "")
    unit    = submission_info.get("unit", "")
    first   = (full_name or "Validator").split()[0]
    price_str = f"₦{price}/{unit}" if price and unit else f"₦{price}" if price else ""

    msg = (
        f"👋 *Hello {first}!*\n\n"
        f"🏪 You have a new validation assignment:\n\n"
        f"📍 Market: *{market}*\n"
        f"🛒 Item: *{item}*"
        + (f"\n💰 Reported price: *{price_str}*" if price_str else "") +
        f"\n\n⏰ Please respond within *30 minutes*.\n\n"
        f"Type *pending* to view and vote on your assignment.\n"
        f"You earn *₦50* for each verified vote."
    )
    _send_wa(phone, msg)


def _notify_timed_out_validator(phone, full_name, submission_info):
    first  = (full_name or "Validator").split()[0]
    market = submission_info.get("market", "your market")
    msg = (
        f"⚠️ *{first}, your assignment has timed out.*\n\n"
        f"You did not respond to the validation request for "
        f"*{market}* within 30 minutes.\n\n"
        f"The assignment has been reassigned. Your response rate "
        f"has been updated.\n\n"
        f"Type *pending* to check your current assignments."
    )
    _send_wa(phone, msg)


def main(mytimer: func.TimerRequest) -> None:
    utc_now = datetime.now(timezone.utc)
    logging.info(f"[timeout_handler] Starting at {utc_now.isoformat()}")

    conn = _get_conn()
    cur  = conn.cursor()

    # ── Find all PENDING queue entries past their deadline ─────────────────
    cur.execute("""
        SELECT
            queue_id, submission_id, market_id, market, item, price, unit,
            trader_phone,
            validator1_phone, validator1_id, validator1_name, validator1_status,
            validator2_phone, validator2_id, validator2_name, validator2_status,
            validator3_phone, validator3_id, validator3_name, validator3_status,
            total_replacements
        FROM dbo.Validation_Queue
        WHERE status = 'PENDING'
          AND deadline IS NOT NULL
          AND CAST(deadline AS DATETIME2) < GETUTCDATE()
          AND (
              validator1_status = 'PENDING'
           OR validator2_status = 'PENDING'
           OR validator3_status = 'PENDING'
          )
    """)
    rows = cur.fetchall()
    conn.close()

    if not rows:
        logging.info("[timeout_handler] No timed-out slots found.")
        return

    logging.info(f"[timeout_handler] Found {len(rows)} queue entries with timed-out slots.")

    total_replaced = 0
    total_skipped  = 0

    for row in rows:
        queue_id      = row["queue_id"]
        submission_id = row["submission_id"]
        market_id     = row["market_id"]
        sub_info      = {
            "market": row.get("market", ""),
            "item":   row.get("item", ""),
            "price":  row.get("price", ""),
            "unit":   row.get("unit", ""),
        }

        # Current assigned phones — exclude from replacement pool
        assigned_phones = [
            p for p in [
                row["validator1_phone"],
                row["validator2_phone"],
                row["validator3_phone"],
            ] if p
        ]

        for slot_n in [1, 2, 3]:
            v_status = row.get(f"validator{slot_n}_status", "")
            v_phone  = row.get(f"validator{slot_n}_phone", "")
            v_name   = row.get(f"validator{slot_n}_name", "")

            if v_status != "PENDING" or not v_phone:
                continue

            logging.info(
                f"[timeout_handler] Queue {queue_id} slot {slot_n} "
                f"({v_phone}) timed out — finding replacement."
            )

            # Find replacement (exclude ALL currently assigned phones)
            conn2       = _get_conn()
            replacement = _find_replacement(conn2, market_id, assigned_phones)
            conn2.close()

            if not replacement:
                logging.warning(
                    f"[timeout_handler] No replacement available for "
                    f"queue {queue_id} slot {slot_n}. Skipping."
                )
                total_skipped += 1
                continue

            new_phone = replacement["phone_number"]
            new_id    = replacement["validator_id"]
            new_name  = replacement["full_name"]
            new_clean = new_phone.lstrip("+")

            # ── Update Validation_Queue slot ──────────────────────────────
            conn3 = _get_conn()
            cur3  = conn3.cursor()

            set_clause = f"""
                validator{slot_n}_phone              = %s,
                validator{slot_n}_id                 = %s,
                validator{slot_n}_name               = %s,
                validator{slot_n}_status             = 'PENDING',
                validator{slot_n}_vote               = NULL,
                validator{slot_n}_replaced_by        = %s,
                validator{slot_n}_replacement_reason = 'TIMEOUT',
                validator{slot_n}_replacement_count  = CAST(
                    ISNULL(CAST(validator{slot_n}_replacement_count AS INT), 0) + 1
                AS NVARCHAR(10)),
                total_replacements = CAST(
                    ISNULL(CAST(total_replacements AS NVARCHAR(10)), '0') + 0 + 1
                AS NVARCHAR(10)),
                updated_at = CONVERT(NVARCHAR(30), GETUTCDATE(), 126)
            """

            cur3.execute(
                f"UPDATE dbo.Validation_Queue SET {set_clause} WHERE queue_id = %s",
                (new_phone, new_id, new_name, v_phone, queue_id)
            )

            # ── Update Submissions validator slot ─────────────────────────
            sub_col = f"validator_{slot_n}"
            cur3.execute(
                f"UPDATE dbo.Submissions SET {sub_col} = %s WHERE submission_id = %s",
                (new_phone, submission_id)
            )

            # ── Increment replacement counter on Submissions ──────────────
            cur3.execute("""
                UPDATE dbo.Submissions
                SET validator_replacement_count =
                    ISNULL(validator_replacement_count, 0) + 1
                WHERE submission_id = %s
            """, (submission_id,))

            # ── Update timed-out validator stats ──────────────────────────
            cur3.execute("""
                UPDATE dbo.Validators
                SET consecutive_timeouts = ISNULL(consecutive_timeouts, 0) + 1,
                    total_timeouts       = ISNULL(total_timeouts, 0) + 1,
                    updated_at           = GETUTCDATE()
                WHERE phone_number = %s OR phone_number = %s
            """, (v_phone, "+" + v_phone))

            # Auto-suspend if consecutive_timeouts >= 3
            cur3.execute("""
                UPDATE dbo.Validators
                SET status             = 'SUSPENDED',
                    suspension_reason  = 'AUTO_TIMEOUT_3_CONSECUTIVE',
                    suspended_at       = GETUTCDATE(),
                    suspension_count   = ISNULL(suspension_count, 0) + 1,
                    updated_at         = GETUTCDATE()
                WHERE (phone_number = %s OR phone_number = %s)
                  AND ISNULL(consecutive_timeouts, 0) >= 3
            """, (v_phone, "+" + v_phone))

            # ── Update new validator weekly_assignments ───────────────────
            cur3.execute("""
                UPDATE dbo.Validators
                SET weekly_assignments  = ISNULL(weekly_assignments, 0) + 1,
                    last_assignment_at  = GETUTCDATE(),
                    consecutive_timeouts = 0,
                    updated_at          = GETUTCDATE()
                WHERE phone_number = %s OR phone_number = %s
            """, (new_phone, "+" + new_phone))

            conn3.commit()
            conn3.close()

            # Update assigned_phones list for next slot iteration
            assigned_phones = [p for p in assigned_phones if p != v_phone]
            assigned_phones.append(new_phone)

            # ── Notify both validators ────────────────────────────────────
            _notify_timed_out_validator(v_phone, v_name, sub_info)
            _notify_new_validator(new_phone, new_name, sub_info)

            logging.info(
                f"[timeout_handler] Slot {slot_n} replaced: "
                f"{v_phone} → {new_phone} for submission {submission_id}"
            )
            total_replaced += 1

    logging.info(
        f"[timeout_handler] Done. Replaced: {total_replaced}, "
        f"Skipped (no replacement): {total_skipped}"
    )
