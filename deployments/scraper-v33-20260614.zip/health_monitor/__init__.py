"""
health_monitor — Azure Function Timer
Fires every 30 minutes
Checks that core function app endpoints are responsive
and logs results to Application Insights
"""

import logging
import os
import requests
from datetime import datetime, timezone

WATCHDOG_URL = "https://func-naijamarket-scraper.azurewebsites.net/api/generation_watchdog"
WATCHDOG_KEY = os.environ.get('WATCHDOG_KEY', 'sTlFUPmPgQ1qYzJbao9wEQEeom5CIQeBL1Y7labNkuqmAzFuKhiMuw==')

def check_endpoint(name: str, url: str, key: str = None, timeout: int = 10) -> dict:
    headers = {}
    if key:
        headers['x-functions-key'] = key
    try:
        res = requests.get(url, headers=headers, timeout=timeout)
        return {
            'name':    name,
            'status':  res.status_code,
            'ok':      res.status_code < 500,
            'latency': res.elapsed.total_seconds() * 1000,
        }
    except requests.Timeout:
        return { 'name': name, 'status': 0, 'ok': False, 'latency': timeout * 1000, 'error': 'timeout' }
    except Exception as e:
        return { 'name': name, 'status': 0, 'ok': False, 'latency': 0, 'error': str(e) }

def main(mytimer) -> None:
    utc_now = datetime.now(timezone.utc)
    logging.info(f'[health_monitor] Starting at {utc_now.isoformat()}')

    checks = [
        check_endpoint('consumer_web',  'https://naijamarket-web.vercel.app/api/health'),
        check_endpoint('generation_watchdog', WATCHDOG_URL, WATCHDOG_KEY),
        check_endpoint('wa_function',   'https://func-naijamarket-wa.azurewebsites.net/api/health'),
        check_endpoint('api_function',  'https://func-naijamarket-api.azurewebsites.net/api/health'),
    ]

    all_ok = all(c['ok'] for c in checks)

    for c in checks:
        status = '✓' if c['ok'] else '✗'
        latency = f"{c['latency']:.0f}ms"
        error = f" — {c['error']}" if c.get('error') else ''
        logging.info(f'[health_monitor] {status} {c["name"]}: HTTP {c["status"]} ({latency}){error}')

    if all_ok:
        logging.info('[health_monitor] All systems operational')
    else:
        failed = [c['name'] for c in checks if not c['ok']]
        logging.warning(f'[health_monitor] Degraded — failed: {", ".join(failed)}')

    logging.info(f'[health_monitor] Done — {sum(c["ok"] for c in checks)}/{len(checks)} healthy')
