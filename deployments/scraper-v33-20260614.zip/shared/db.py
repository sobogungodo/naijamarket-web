"""
shared/db.py — NaijaMarket Intel scraper DB connection
CRITICAL: timeout=0 — sp_Generate_Daily_Prices runs 3-7 min.
Confirmed env vars: SQL_SERVER, SQL_USER, SQL_PASSWORD, SQL_DATABASE
"""
import os
import pymssql

def get_connection():
    return pymssql.connect(
        server=os.environ["SQL_SERVER"],
        user=os.environ["SQL_USER"],
        password=os.environ["SQL_PASSWORD"],
        database=os.environ["SQL_DATABASE"],
        timeout=0,
        login_timeout=30
    )
