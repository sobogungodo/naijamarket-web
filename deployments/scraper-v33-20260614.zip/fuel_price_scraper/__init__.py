import azure.functions as func, logging
def main(myTimer: func.TimerRequest) -> None:
    logging.info("[fuel_price_scraper] tick")
