import logging
import os
import requests
import pymssql
import azure.functions as func
from datetime import datetime, timezone, timedelta


BREVO_API_KEY = os.environ.get("BREVO_API_KEY", "")
ADMIN_EMAIL   = os.environ.get("ADMIN_EMAIL", "admin@naijamarketintel.ng")
SENDER_EMAIL  = os.environ.get("SENDER_EMAIL", "noreply@naijamarketintel.ng")


def get_connection():
    return pymssql.connect(
        server=os.environ["SQL_SERVER"],
        user=os.environ.get("SQL_USERNAME") or os.environ.get("SQL_USER", ""),
        password=os.environ["SQL_PASSWORD"],
        database=os.environ.get("SQL_DATABASE", "naijafoodmarket-live"),
        timeout=30, login_timeout=30, as_dict=True,
    )


def get_stats():
    conn = get_connection()
    cur = conn.cursor()
    today = datetime.now(timezone.utc).strftime("%Y-%m-%d")

    cur.execute("SELECT time_slot, COUNT(*) as rows FROM dbo.Daily_Prices WHERE price_date = %s AND nbs_adjusted = 0 GROUP BY time_slot ORDER BY time_slot", (today,))
    price_slots = cur.fetchall()

    cur.execute("SELECT COUNT(*) as total, SUM(CASE WHEN validation_status='APPROVED' THEN 1 ELSE 0 END) as approved, SUM(CASE WHEN validation_status='REJECTED' THEN 1 ELSE 0 END) as rejected, SUM(CASE WHEN validation_status='PENDING' THEN 1 ELSE 0 END) as pending FROM dbo.Submissions WHERE CAST(submitted_at AS DATE) = %s", (today,))
    subs = cur.fetchone()

    cur.execute("SELECT (SELECT COUNT(*) FROM dbo.Traders_register WHERE registration_status='APPROVED') as traders, (SELECT COUNT(*) FROM dbo.Validators WHERE status='ACTIVE') as validators")
    users = cur.fetchone()

    cur.execute("SELECT status, COUNT(*) as cnt, SUM(amount) as total FROM dbo.Rewards_Ledger GROUP BY status")
    rewards = cur.fetchall()

    cur.execute("SELECT subscription_tier, COUNT(*) as cnt FROM dbo.Consumers WHERE account_status='ACTIVE' GROUP BY subscription_tier ORDER BY cnt DESC")
    tiers = cur.fetchall()

    conn.close()
    return {"date": today, "price_slots": price_slots, "submissions": subs, "users": users, "rewards": rewards, "tiers": tiers}


def build_html(stats):
    wat = datetime.now(timezone(timedelta(hours=1))).strftime("%Y-%m-%d %H:%M WAT")
    slot_map = {s["time_slot"]: s["rows"] for s in stats["price_slots"]}
    slot_rows = ""
    for slot in ["08:30","11:30","14:30"]:
        rows = slot_map.get(slot, 0)
        icon = "OK" if rows > 0 else "MISS"
        slot_rows += f"<tr><td>{slot} WAT</td><td style='color:{"#00C853" if rows>0 else "#f44336"}'>{icon}</td><td>{rows:,}</td></tr>"

    s = stats["submissions"] or {}
    total = int(s.get("total") or 0)
    approved = int(s.get("approved") or 0)
    rejected = int(s.get("rejected") or 0)
    pending = int(s.get("pending") or 0)
    rate = f"{(approved/total*100):.1f}%" if total > 0 else "N/A"

    u = stats["users"] or {}
    traders = int(u.get("traders") or 0)
    validators = int(u.get("validators") or 0)

    reward_rows = "".join(f"<tr><td>{r['status']}</td><td>{int(r['cnt'])}</td><td>N{float(r['total'] or 0):,.2f}</td></tr>" for r in stats["rewards"]) or "<tr><td colspan=3>None</td></tr>"
    tier_rows = "".join(f"<tr><td>{t['subscription_tier']}</td><td>{int(t['cnt'])}</td></tr>" for t in stats["tiers"]) or "<tr><td colspan=2>None</td></tr>"

    return f"""<html><body style="font-family:Arial,sans-serif;background:#0a0a0a;color:#e0e0e0;padding:20px">
<div style="max-width:600px;margin:0 auto;background:#111;border-radius:8px;padding:24px;border:1px solid #333">
<h2 style="color:#00C853;margin:0 0 4px">NaijaMarket Intel</h2>
<p style="color:#888;margin:0 0 20px;font-size:13px">Admin Report &bull; {wat}</p>
<h3 style="color:#FFB300;font-size:15px">Price Generation ({stats["date"]})</h3>
<table width="100%" style="border-collapse:collapse;margin-bottom:20px;font-size:13px">
<tr style="background:#1a1a1a;color:#888"><th align="left" style="padding:6px">Slot</th><th align="left" style="padding:6px">Status</th><th align="left" style="padding:6px">Rows</th></tr>
{slot_rows}</table>
<h3 style="color:#FFB300;font-size:15px">Submissions Today</h3>
<table width="100%" style="border-collapse:collapse;margin-bottom:20px;font-size:13px">
<tr style="background:#1a1a1a;color:#888"><th align="left" style="padding:6px">Metric</th><th align="left" style="padding:6px">Value</th></tr>
<tr><td style="padding:6px">Total</td><td style="padding:6px">{total}</td></tr>
<tr><td style="padding:6px">Approved</td><td style="padding:6px;color:#00C853">{approved}</td></tr>
<tr><td style="padding:6px">Rejected</td><td style="padding:6px;color:#f44336">{rejected}</td></tr>
<tr><td style="padding:6px">Pending</td><td style="padding:6px;color:#FFB300">{pending}</td></tr>
<tr><td style="padding:6px">Approval Rate</td><td style="padding:6px">{rate}</td></tr>
</table>
<h3 style="color:#FFB300;font-size:15px">Active Users</h3>
<table width="100%" style="border-collapse:collapse;margin-bottom:20px;font-size:13px">
<tr style="background:#1a1a1a;color:#888"><th align="left" style="padding:6px">Role</th><th align="left" style="padding:6px">Count</th></tr>
<tr><td style="padding:6px">Traders</td><td style="padding:6px">{traders}</td></tr>
<tr><td style="padding:6px">Validators</td><td style="padding:6px">{validators}</td></tr>
</table>
<h3 style="color:#FFB300;font-size:15px">Rewards Ledger</h3>
<table width="100%" style="border-collapse:collapse;margin-bottom:20px;font-size:13px">
<tr style="background:#1a1a1a;color:#888"><th align="left" style="padding:6px">Status</th><th align="left" style="padding:6px">Count</th><th align="left" style="padding:6px">Total</th></tr>
{reward_rows}</table>
<h3 style="color:#FFB300;font-size:15px">Subscriptions by Tier</h3>
<table width="100%" style="border-collapse:collapse;margin-bottom:20px;font-size:13px">
<tr style="background:#1a1a1a;color:#888"><th align="left" style="padding:6px">Tier</th><th align="left" style="padding:6px">Count</th></tr>
{tier_rows}</table>
<p style="color:#444;font-size:11px;margin-top:16px;border-top:1px solid #222;padding-top:12px">NaijaMarket Intel &bull; Giggababytes Oy &bull; Auto-generated</p>
</div></body></html>"""


def send_email(subject, html_body):
    if not BREVO_API_KEY:
        logging.warning("[admin_daily_report] BREVO_API_KEY not set")
        return False
    try:
        r = requests.post(
            "https://api.brevo.com/v3/smtp/email",
            headers={"api-key": BREVO_API_KEY, "Content-Type": "application/json"},
            json={
                "sender": {"name": "NaijaMarket Intel", "email": SENDER_EMAIL},
                "to": [{"email": ADMIN_EMAIL, "name": "Admin"}],
                "subject": subject,
                "htmlContent": html_body,
            },
            timeout=15
        )
        logging.info(f"[admin_daily_report] Brevo HTTP {r.status_code}: {r.text[:100]}")
        return r.status_code in (200, 201)
    except Exception as e:
        logging.error(f"[admin_daily_report] Email error: {e}")
        return False


def main(myTimer: func.TimerRequest) -> None:
    utc_now = datetime.now(timezone.utc)
    logging.info(f"[admin_daily_report] START {utc_now.isoformat()}")
    try:
        stats = get_stats()
        slot_count = len(stats["price_slots"])
        subject = f"NaijaMarket Intel Admin Report | {stats['date']} | {slot_count}/3 price slots"
        html = build_html(stats)
        sent = send_email(subject, html)
        logging.info(f"[admin_daily_report] Done. Email sent={sent}")
    except Exception as e:
        logging.error(f"[admin_daily_report] ERROR: {e}", exc_info=True)
