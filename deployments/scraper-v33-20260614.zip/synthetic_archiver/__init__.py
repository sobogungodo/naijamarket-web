import azure.functions as func, logging
def main(myTimer: func.TimerRequest) -> None:
    logging.info("[synthetic_archiver] tick")
