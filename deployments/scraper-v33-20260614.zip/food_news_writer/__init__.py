import azure.functions as func
import logging, os, re
import pymssql
from datetime import datetime, timedelta

def get_connection():
    return pymssql.connect(server=os.environ["SQL_SERVER"], user=os.environ["SQL_USER"], password=os.environ["SQL_PASSWORD"], database=os.environ["SQL_DATABASE"], timeout=0, login_timeout=30)

def slugify(text):
    text = re.sub(r'[^\w\s-]', '', text.lower())
    return re.sub(r'[-\s]+', '-', text)[:80].strip('-')

def main(myTimer: func.TimerRequest) -> None:
    logging.info("[food_news_writer] Starting")
    now = datetime.utcnow()
    week_start = (now - timedelta(days=now.weekday() + 1)).date()
    try:
        conn = get_connection()
        cur = conn.cursor(as_dict=True)
        cur.execute("SELECT event_id, headline, source_name, event_cluster, direction, volatility_score, affected_commodities, affected_markets, consumer_summary FROM dbo.News_Events WHERE scraped_at >= %s AND is_active = 1 ORDER BY volatility_score DESC", (week_start,))
        events = cur.fetchall()
        if not events:
            logging.info("[food_news_writer] No events this week")
            conn.close(); return
        cur.execute("SELECT TOP 5 item_name, price_naira, month_change_pct, state FROM dbo.Latest_Prices_Summary WHERE is_nbs_ref=0 AND is_food=1 AND month_change_pct IS NOT NULL ORDER BY ABS(ISNULL(month_change_pct,0)) DESC")
        movers = cur.fetchall()
        mover_lines = [f"{m['item_name']} ({m['state']}) {'up' if (m['month_change_pct'] or 0)>0 else 'down'} {abs(m['month_change_pct'] or 0):.1f}% at \u20a6{m['price_naira']:,.0f}" for m in movers]
        clusters = {}
        for e in events:
            c = e['event_cluster'] or 'general'
            clusters.setdefault(c, []).append(e)
        all_commodities = set()
        all_markets = set()
        for e in events:
            if e['affected_commodities']:
                [all_commodities.add(x.strip()) for x in e['affected_commodities'].split(',')]
            if e['affected_markets']:
                [all_markets.add(x.strip()) for x in e['affected_markets'].split(',')]
        title = f"Nigeria Food Market Weekly Brief \u2014 {now.strftime('%B %d, %Y')}"
        summary_parts = []
        if mover_lines: summary_parts.append("Top movers: " + "; ".join(mover_lines[:3]))
        cluster_heads = [f"{k.replace('_',' ').title()}: {v[0]['headline']}" for k,v in list(clusters.items())[:3]]
        if cluster_heads: summary_parts.append(" | ".join(cluster_heads))
        summary = " ".join(summary_parts)[:2000] or f"{len(events)} market events tracked this week."
        cur.execute("SELECT article_id FROM dbo.News_Articles WHERE week_start=%s AND category='weekly_roundup'", (week_start,))
        if not cur.fetchone():
            cur.execute("INSERT INTO dbo.News_Articles (slug,title,summary,source_name,source_url,category,affected_commodities,affected_states,published_date,week_start,is_published,tier_access,created_at) VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,1,%s,GETUTCDATE())", (slugify(title), title, summary, 'NaijaMarket Intel', 'https://naijamarketintel.ng/food-news', 'weekly_roundup', ','.join(list(all_commodities)[:20]), ','.join(list(all_markets)[:10]), now.date(), week_start, 'FREE'))
            conn.commit()
            logging.info(f"[food_news_writer] Published: {title}")
        written = 0
        for cluster, evts in clusters.items():
            if len(evts) < 2: continue
            ctitle = f"{cluster.replace('_',' ').title()} Market Update \u2014 {now.strftime('%B %Y')}"
            cur.execute("SELECT article_id FROM dbo.News_Articles WHERE week_start=%s AND category=%s", (week_start, cluster))
            if cur.fetchone(): continue
            csummary = f"{len(evts)} developments. " + " | ".join([e['headline'] for e in evts[:3]])
            ccoms = set()
            for e in evts:
                if e['affected_commodities']: [ccoms.add(x.strip()) for x in e['affected_commodities'].split(',')]
            cur.execute("INSERT INTO dbo.News_Articles (slug,title,summary,source_name,source_url,category,affected_commodities,affected_states,published_date,week_start,is_published,tier_access,created_at) VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,1,%s,GETUTCDATE())", (slugify(ctitle), ctitle, csummary[:2000], 'NaijaMarket Intel', 'https://naijamarketintel.ng/food-news', cluster, ','.join(list(ccoms)[:20]), ','.join(list(all_markets)[:10]), now.date(), week_start, 'FREE'))
            written += 1
        conn.commit()
        logging.info(f"[food_news_writer] Done. {written} cluster articles.")
        conn.close()
    except Exception as e:
        logging.error(f"[food_news_writer] Error: {e}"); raise
