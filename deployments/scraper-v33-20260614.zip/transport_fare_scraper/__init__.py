import azure.functions as func, logging
def main(myTimer: func.TimerRequest) -> None:
    logging.info("[transport_fare_scraper] tick")
