
import logging
import os
import threading
import json
import sys
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))
import pymssql
import azure.functions as func
from datetime import datetime, timezone

def _run_generation():
    conn = None
    try:
        conn = pymssql.connect(
            server=os.environ['SQL_SERVER'],
            user=os.environ.get('SQL_USERNAME') or os.environ.get('SQL_USER', ''),
            password=os.environ['SQL_PASSWORD'],
            database=os.environ.get('SQL_DATABASE', 'naijafoodmarket-live'),
            timeout=0,
            login_timeout=30,
            as_dict=True,
        )
        cur = conn.cursor()
        logging.info('[trigger_generation] Calling sp_Generate_Daily_Prices...')
        cur.execute('EXEC dbo.sp_Generate_Daily_Prices')
        conn.commit()
        row = cur.fetchone()
        if row:
            logging.info('[trigger_generation] DONE — slot=%s total=%s',
                row.get('time_slot'), row.get('total_rows_inserted'))
        cur.close()
        cur2 = conn.cursor()
        cur2.execute('EXEC dbo.usp_Refresh_LatestPrices')
        conn.commit()
        cur2.close()
        logging.info('[trigger_generation] LPS refresh complete.')
    except Exception as e:
        logging.error('[trigger_generation] ERROR: %s', str(e), exc_info=True)
    finally:
        if conn:
            try: conn.close()
            except: pass

def main(req: func.HttpRequest) -> func.HttpResponse:
    logging.info('[trigger_generation] HTTP trigger received.')
    t = threading.Thread(target=_run_generation, daemon=True)
    t.start()
    return func.HttpResponse(
        json.dumps({'status': 'accepted', 'message': 'Generation started', 'started_at': datetime.now(timezone.utc).isoformat()}),
        status_code=202,
        headers={'Content-Type': 'application/json'}
    )
