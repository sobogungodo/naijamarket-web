"""generate_midday_prices — timer trigger fires at 11:30 UTC (WAT+1)
Calls sp_Generate_Daily_Prices with no args — SP self-determines date+slot.
Uses timeout=0 (unlimited) — SP runs 3-7 min on consumption plan.
"""
import logging
import os
import sys
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))
import pymssql
import azure.functions as func
from datetime import datetime, timezone


def _get_gen_connection():
    """Dedicated connection with unlimited timeout for long-running generation SP."""
    return pymssql.connect(
        server=os.environ["SQL_SERVER"],
        user=os.environ.get("SQL_USERNAME") or os.environ.get("SQL_USER", ""),
        password=os.environ["SQL_PASSWORD"],
        database=os.environ.get("SQL_DATABASE", "naijafoodmarket-live"),
        timeout=0,        # unlimited — SP runs 3-7 minutes
        login_timeout=30,
        as_dict=True,
    )


def main(myTimer: func.TimerRequest) -> None:
    start = datetime.now(timezone.utc)
    logging.info("[generate_midday_prices] START %s", start.isoformat())

    if myTimer.past_due:
        logging.warning("[generate_midday_prices] Timer is past due — running anyway.")

    conn = None
    try:
        conn = _get_gen_connection()
        cur = conn.cursor()

        # SP self-determines @TargetDate and @TimeSlot from GETUTCDATE()
        # Do NOT pass args — avoids pymssql callproc parameter mapping issues
        logging.info("[generate_midday_prices] Calling sp_Generate_Daily_Prices ...")
        cur.execute("EXEC dbo.sp_Generate_Daily_Prices")
        conn.commit()

        # Fetch result row for logging
        row = cur.fetchone()
        if row:
            logging.info(
                "[generate_midday_prices] DONE — date=%s slot=%s "
                "pathA=%s pathB=%s total=%s elapsed_ms=%s",
                row.get("price_date"), row.get("time_slot"),
                row.get("path_a_sim_tracked"), row.get("path_b_sim_baseline"),
                row.get("total_rows_inserted"), row.get("elapsed_ms"),
            )
        else:
            logging.info("[generate_midday_prices] SP completed (guard path or no result row).")

        cur.close()

        # Refresh Latest_Prices_Summary
        logging.info("[generate_midday_prices] Refreshing Latest_Prices_Summary ...")
        cur2 = conn.cursor()
        cur2.execute("EXEC dbo.usp_Refresh_LatestPrices")
        conn.commit()
        cur2.close()
        logging.info("[generate_midday_prices] Refresh complete.")

    except Exception as e:
        logging.error("[generate_midday_prices] ERROR: %s", str(e), exc_info=True)
        raise
    finally:
        if conn:
            try:
                conn.close()
            except Exception:
                pass

    elapsed = (datetime.now(timezone.utc) - start).total_seconds()
    logging.info("[generate_midday_prices] FINISHED in %.1f seconds.", elapsed)
