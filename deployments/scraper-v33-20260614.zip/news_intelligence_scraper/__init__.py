import azure.functions as func, logging
def main(myTimer: func.TimerRequest) -> None:
    logging.info("[news_intelligence_scraper] tick")
