"""
price_guidance — canonical price-guidance range for a given item + market.

SINGLE SOURCE OF TRUTH consumed by BOTH the WhatsApp trader flow
(func-naijamarket-wa / whatsapp_main) and the trader mobile app.
Neither surface computes its own range — they both call this endpoint,
guaranteeing the guidance shown is always identical across channels.

GET  /api/price_guidance?item_id=ITM00002&market_id=MKT0001
POST /api/price_guidance   { "item_id": "...", "market_id": "..." }

Response (200):
{
  "ok": true,
  "item_id": "ITM00002",
  "market_id": "MKT0001",
  "baseline": 54000.0,            # canonical anchor (same value variance check uses)
  "baseline_source": "LATEST_PRICES_SUMMARY" | "VERIFIED_EXTERNAL" | null,
  "expected_low": 48600.0,        # baseline * (1 - variance_pct)
  "expected_high": 59400.0,       # baseline * (1 + variance_pct)
  "variance_pct": 0.10,
  "peer": {                       # present only when >=2 approved peer submissions today
    "count": 4,
    "low": 50000.0,
    "high": 60000.0
  },
  "hint_text": "Other traders at this market today: \u20a650,000 \u2013 \u20a660,000"
}
"""

import os
import json
import logging

import azure.functions as func
import pymssql

# Must match the variance band enforced in the trader submission flow.
# Single place to change it; both surfaces inherit via this endpoint.
PRICE_VARIANCE_PCT = 0.10


def get_connection():
    return pymssql.connect(
        server   = os.environ["SQL_SERVER"],
        user     = os.environ["SQL_USERNAME"],
        password = os.environ["SQL_PASSWORD"],
        database = os.environ["SQL_DATABASE"],
        timeout  = 0,
        login_timeout = 30,
        as_dict  = True,
    )


def _get_baseline(cur, item_id: str, market_id: str):
    """Baseline primary: Latest_Prices_Summary, then Verified_External_Prices."""
    cur.execute("""
        SELECT TOP 1 price_naira AS p
        FROM   dbo.Latest_Prices_Summary
        WHERE  item_id = %s AND market_id = %s AND price_naira > 0
        ORDER BY price_date DESC
    """, (item_id, market_id))
    row = cur.fetchone()
    if row and row.get("p"):
        return float(row["p"]), "LATEST_PRICES_SUMMARY"

    cur.execute("""
        SELECT TOP 1 price_naira AS p
        FROM   dbo.Verified_External_Prices
        WHERE  item_id = %s AND market_id = %s AND price_naira > 0
    """, (item_id, market_id))
    row = cur.fetchone()
    if row and row.get("p"):
        return float(row["p"]), "VERIFIED_EXTERNAL"

    return None, None


def _get_peer_range(cur, item_id: str, market_id: str):
    """
    Peer range from TODAY's approved submissions at this market for this item.
    Only returned when >=2 real (non-synthetic) approved submissions exist.
    submitted_at is nvarchar ISO-8601 ('2026-06-06T14:41:41.336Z') -> TRY_CAST.
    """
    cur.execute("""
        SELECT COUNT(*) AS cnt, MIN(price) AS lo, MAX(price) AS hi
        FROM   dbo.Submissions
        WHERE  item_id = %s AND market_id = %s
          AND  validation_status = 'APPROVED'
          AND  price > 0
          AND  trader_id NOT LIKE 'SYN-%%'
          AND  CAST(TRY_CAST(submitted_at AS DATETIME2) AS DATE) = CAST(GETUTCDATE() AS DATE)
    """, (item_id, market_id))
    row = cur.fetchone() or {}
    cnt = int(row.get("cnt") or 0)
    if cnt >= 2 and row.get("lo") and row.get("hi"):
        return {"count": cnt, "low": float(row["lo"]), "high": float(row["hi"])}
    return None


def _naira(v: float) -> str:
    return f"\u20a6{v:,.0f}"


def _build_hint(baseline, lo, hi, peer):
    """Single canonical hint string so WA and mobile render identical text."""
    if peer:
        return f"Other traders at this market today: {_naira(peer['low'])} \u2013 {_naira(peer['high'])}"
    if baseline is not None:
        return f"Expected range for this item: {_naira(lo)} \u2013 {_naira(hi)}"
    return "No price guidance available yet for this item at this market."


def main(req: func.HttpRequest) -> func.HttpResponse:
    item_id = req.params.get("item_id")
    market_id = req.params.get("market_id")
    if not item_id or not market_id:
        try:
            body = req.get_json()
            item_id = item_id or body.get("item_id")
            market_id = market_id or body.get("market_id")
        except Exception:
            pass

    if not item_id or not market_id:
        return func.HttpResponse(
            json.dumps({"ok": False, "error": "item_id and market_id are required"}),
            status_code=400, mimetype="application/json",
        )

    conn = None
    try:
        conn = get_connection()
        cur = conn.cursor()

        baseline, source = _get_baseline(cur, item_id, market_id)
        peer = _get_peer_range(cur, item_id, market_id)

        if baseline is not None:
            lo = round(baseline * (1 - PRICE_VARIANCE_PCT), 2)
            hi = round(baseline * (1 + PRICE_VARIANCE_PCT), 2)
        else:
            lo = hi = None

        payload = {
            "ok": True,
            "item_id": item_id,
            "market_id": market_id,
            "baseline": baseline,
            "baseline_source": source,
            "expected_low": lo,
            "expected_high": hi,
            "variance_pct": PRICE_VARIANCE_PCT,
            "peer": peer,
            "hint_text": _build_hint(baseline, lo, hi, peer),
        }
        return func.HttpResponse(
            json.dumps(payload), status_code=200, mimetype="application/json"
        )

    except Exception as e:
        logging.error(f"[price_guidance] error: {e}")
        # Fail soft: never block submission because guidance failed.
        return func.HttpResponse(
            json.dumps({"ok": False, "error": "guidance_unavailable",
                        "hint_text": ""}),
            status_code=200, mimetype="application/json",
        )
    finally:
        if conn:
            conn.close()