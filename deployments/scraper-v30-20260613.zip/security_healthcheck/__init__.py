"""
security_healthcheck — Azure Function Timer
Fires daily at 02:00 UTC
Runs 10 security regression tests against all live surfaces.
Sends WhatsApp alert to admin if any check fails.
"""
import logging
import os
import json
import time
import hashlib
import hmac
import requests
from datetime import datetime, timezone

ADMIN_PHONE   = "2349131095009"
API_BASE      = "https://func-naijamarket-api.azurewebsites.net/api"
WA_BASE       = "https://func-naijamarket-wa.azurewebsites.net/api"
WEB_BASE      = "https://www.naijamarketintel.com"

FUNC_KEY      = os.environ.get("NAIJAMARKET_API_KEY", "")
WA_TOKEN      = os.environ.get("META_ACCESS_TOKEN", "")
WA_PHONE_ID   = os.environ.get("META_PHONE_NUMBER_ID", "1040415905832961")
PAYSTACK_KEY  = os.environ.get("PAYSTACK_SECRET_KEY", "")
META_SECRET   = os.environ.get("META_APP_SECRET", "")


# ── WhatsApp sender ───────────────────────────────────────────────────────────

def _send_wa(message: str) -> bool:
    if not WA_TOKEN:
        logging.error("[security_healthcheck] WA_TOKEN not set — cannot send alert")
        return False
    url = f"https://graph.facebook.com/v18.0/{WA_PHONE_ID}/messages"
    payload = {
        "messaging_product": "whatsapp",
        "to": ADMIN_PHONE,
        "type": "text",
        "text": {"body": message}
    }
    try:
        r = requests.post(url, json=payload,
                          headers={"Authorization": f"Bearer {WA_TOKEN}"},
                          timeout=10)
        return r.status_code == 200
    except Exception as e:
        logging.error(f"[security_healthcheck] WA send failed: {e}")
        return False


# ── Individual checks ─────────────────────────────────────────────────────────

def check_api_requires_auth() -> dict:
    """price_guidance must return 401 without a valid function key."""
    try:
        r = requests.get(f"{API_BASE}/price_guidance?item_id=ITM00001&market_id=MKT0001",
                         timeout=10)
        passed = r.status_code == 401
        return {"name": "API auth required", "passed": passed,
                "detail": f"HTTP {r.status_code} (expected 401)"}
    except Exception as e:
        return {"name": "API auth required", "passed": False, "detail": str(e)}


def check_account_data_requires_bearer() -> dict:
    """account_data must return 401 without Bearer token."""
    try:
        r = requests.get(f"{API_BASE}/account_data?type=digest&code={FUNC_KEY}",
                         timeout=10)
        passed = r.status_code == 401
        return {"name": "account_data Bearer required", "passed": passed,
                "detail": f"HTTP {r.status_code} (expected 401)"}
    except Exception as e:
        return {"name": "account_data Bearer required", "passed": False, "detail": str(e)}


def check_otp_rate_limit() -> dict:
    """otp_send must reject a second request within 60s cooldown."""
    try:
        test_phone = "2340000000000"  # non-existent test number
        url = f"{API_BASE}/otp_send?code={FUNC_KEY}"
        payload = {"phone": test_phone}
        # First call
        requests.post(url, json=payload, timeout=10)
        time.sleep(1)
        # Second call — should be rate limited
        r = requests.post(url, json=payload, timeout=10)
        body = r.json() if r.headers.get("content-type", "").startswith("application/json") else {}
        # Expect either 429 or error message indicating cooldown
        # 401 means auth blocked before rate limit — still means endpoint is protected
        passed = r.status_code in (429, 401) or "cooldown" in json.dumps(body).lower() or "wait" in json.dumps(body).lower()
        return {"name": "OTP rate limit", "passed": passed,
                "detail": f"HTTP {r.status_code} body={json.dumps(body)[:80]}"}
    except Exception as e:
        return {"name": "OTP rate limit", "passed": False, "detail": str(e)}


def check_csp_header() -> dict:
    """Web app must serve Content-Security-Policy header."""
    try:
        r = requests.head(WEB_BASE, timeout=10)
        passed = "content-security-policy" in {k.lower() for k in r.headers}
        return {"name": "CSP header present", "passed": passed,
                "detail": f"Headers: {list(r.headers.keys())[:5]}"}
    except Exception as e:
        return {"name": "CSP header present", "passed": False, "detail": str(e)}


def check_hsts_header() -> dict:
    """Web app must serve Strict-Transport-Security header."""
    try:
        r = requests.head(WEB_BASE, timeout=10)
        passed = "strict-transport-security" in {k.lower() for k in r.headers}
        return {"name": "HSTS header present", "passed": passed,
                "detail": f"HTTP {r.status_code}"}
    except Exception as e:
        return {"name": "HSTS header present", "passed": False, "detail": str(e)}


def check_wa_webhook_rejects_invalid_signature() -> dict:
    """WA webhook must reject requests with invalid Meta signature."""
    try:
        fake_payload = json.dumps({"object": "whatsapp_business_account"}).encode()
        fake_sig = "sha256=0000000000000000000000000000000000000000000000000000000000000000"
        r = requests.post(
            f"{WA_BASE}/whatsapp_main",
            data=fake_payload,
            headers={
                "Content-Type": "application/json",
                "X-Hub-Signature-256": fake_sig
            },
            timeout=10
        )
        passed = r.status_code in (401, 403, 400)
        return {"name": "WA webhook sig check", "passed": passed,
                "detail": f"HTTP {r.status_code} (expected 401 or 403)"}
    except Exception as e:
        return {"name": "WA webhook sig check", "passed": False, "detail": str(e)}


def check_paystack_webhook_rejects_invalid_hmac() -> dict:
    """Paystack webhook must reject requests with wrong HMAC."""
    try:
        fake_payload = json.dumps({"event": "charge.success"}).encode()
        r = requests.post(
            f"{WEB_BASE}/api/webhooks/paystack",
            data=fake_payload,
            headers={
                "Content-Type": "application/json",
                "x-paystack-signature": "invalidsignature"
            },
            timeout=10
        )
        passed = r.status_code in (401, 403, 400)
        return {"name": "Paystack webhook HMAC check", "passed": passed,
                "detail": f"HTTP {r.status_code} (expected 400/401/403)"}
    except Exception as e:
        return {"name": "Paystack webhook HMAC check", "passed": False, "detail": str(e)}


def check_process_rewards_requires_master_key() -> dict:
    """process_rewards admin trigger must reject non-master keys."""
    try:
        r = requests.post(
            "https://func-naijamarket-api.azurewebsites.net/admin/functions/process_rewards",
            json={"input": ""},
            headers={
                "Content-Type": "application/json",
                "x-functions-key": "invalid-key-test"
            },
            timeout=10
        )
        passed = r.status_code in (401, 403, 400)
        return {"name": "process_rewards master key only", "passed": passed,
                "detail": f"HTTP {r.status_code} (expected 401 or 403)"}
    except Exception as e:
        return {"name": "process_rewards master key only", "passed": False, "detail": str(e)}


def check_no_debug_endpoints() -> dict:
    """Debug endpoints deleted in api-v8 must remain gone."""
    found = []
    debug_paths = ["/api/test-db", "/api/debug", "/api/2fa/debug"]
    try:
        for path in debug_paths:
            r = requests.get(f"{WEB_BASE}{path}", timeout=10)
            if r.status_code == 200:
                found.append(path)
        passed = len(found) == 0
        return {"name": "Debug endpoints removed", "passed": passed,
                "detail": f"Found live: {found}" if found else "All debug paths return non-200"}
    except Exception as e:
        return {"name": "Debug endpoints removed", "passed": False, "detail": str(e)}


def check_sql_injection_rejected() -> dict:
    """price_guidance must not expose SQL errors on injection attempt."""
    try:
        malicious = "' OR 1=1 --"
        r = requests.get(
            f"{API_BASE}/price_guidance",
            params={"item_id": malicious, "market_id": "MKT0001", "code": FUNC_KEY},
            timeout=10
        )
        body = r.text.lower()
        # Fail if SQL error keywords appear in response
        sql_leak = any(kw in body for kw in ["sql", "syntax", "unclosed", "nvarchar", "conversion failed"])
        passed = not sql_leak
        return {"name": "SQL injection safe", "passed": passed,
                "detail": f"HTTP {r.status_code} sql_leak={sql_leak}"}
    except Exception as e:
        return {"name": "SQL injection safe", "passed": False, "detail": str(e)}


# ── Main ──────────────────────────────────────────────────────────────────────

def main(mytimer) -> None:
    utc_now = datetime.now(timezone.utc)
    logging.info(f"[security_healthcheck] Starting at {utc_now.isoformat()}")

    checks = [
        check_api_requires_auth,
        check_account_data_requires_bearer,
        check_otp_rate_limit,
        check_csp_header,
        check_hsts_header,
        check_wa_webhook_rejects_invalid_signature,
        check_paystack_webhook_rejects_invalid_hmac,
        check_process_rewards_requires_master_key,
        check_no_debug_endpoints,
        check_sql_injection_rejected,
    ]

    results = []
    for check_fn in checks:
        try:
            result = check_fn()
        except Exception as e:
            result = {"name": check_fn.__name__, "passed": False, "detail": str(e)}
        results.append(result)
        status = "✅" if result["passed"] else "❌"
        logging.info(f"[security_healthcheck] {status} {result['name']}: {result.get('detail','')}")

    passed  = sum(1 for r in results if r["passed"])
    failed  = [r for r in results if not r["passed"]]
    total   = len(results)

    if failed:
        lines = [f"⚠️ *NaijaMarket Security Alert*", f"📅 {utc_now.strftime('%Y-%m-%d %H:%M')} UTC",
                 f"", f"*{passed}/{total} checks passed*", f"", f"*Failed checks:*"]
        for r in failed:
            lines.append(f"❌ {r['name']}")
            lines.append(f"   {r.get('detail','')[:80]}")
        lines += ["", "Check Azure logs for details.", "🔒 NaijaMarket Intel Security Monitor"]
        message = "\n".join(lines)
        sent = _send_wa(message)
        logging.warning(f"[security_healthcheck] {len(failed)} failures — WA alert sent={sent}")
    else:
        message = (f"✅ *NaijaMarket Security Check*\n"
                   f"📅 {utc_now.strftime('%Y-%m-%d %H:%M')} UTC\n\n"
                   f"*{passed}/{total} checks passed*\n"
                   f"All security controls operational 🔒")
        _send_wa(message)
        logging.info(f"[security_healthcheck] All {total} checks passed")
