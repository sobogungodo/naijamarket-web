import os, pymssql

def get_connection():
    return pymssql.connect(
        server=os.environ["SQL_SERVER"],
        user=os.environ.get("SQL_USERNAME", os.environ.get("SQL_USER","")),
        password=os.environ["SQL_PASSWORD"],
        database=os.environ["SQL_DATABASE"],
        as_dict=True, timeout=30
    )

def get_consumer(phone):
    conn = get_connection()
    try:
        cur = conn.cursor(as_dict=True)
        clean = phone.replace("+","").strip()
        cur.execute("""
            SELECT consumer_id, phone, phone_number, subscription_tier,
                   subscription_end_date, account_status, preferred_language,
                   pending_downgrade_tier, downgrade_effective_date
            FROM dbo.Consumers
            WHERE phone = %s OR phone_number = %s OR phone = %s OR phone_number = %s
        """, (clean, clean, f"+{clean}", f"+{clean}"))
        return cur.fetchone() or {}
    finally:
        conn.close()
