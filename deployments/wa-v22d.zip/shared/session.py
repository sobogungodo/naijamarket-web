import json, logging
from shared.db import get_connection

def get_session(phone: str) -> dict:
    try:
        conn = get_connection(); cur = conn.cursor(as_dict=True)
        clean = phone.replace("+","").strip()
        cur.execute("""
            SELECT session_data FROM dbo.Consumer_Query_Sessions
            WHERE phone_number = %s AND session_status = 'ACTIVE'
        """, (clean,))
        row = cur.fetchone(); conn.close()
        if row and row.get("session_data"):
            return json.loads(row["session_data"])
    except Exception as e:
        logging.error(f"[session.get] {e}")
    return {}

def save_session(phone: str, data: dict):
    try:
        conn = get_connection(); cur = conn.cursor()
        clean = phone.replace("+","").strip()
        js = json.dumps(data)
        cur.execute("""
            MERGE dbo.Consumer_Query_Sessions AS t
            USING (SELECT %s AS phone_number) AS s ON t.phone_number = s.phone_number
            WHEN MATCHED THEN UPDATE SET session_data=%s, session_status='ACTIVE', last_updated=GETUTCDATE()
            WHEN NOT MATCHED THEN INSERT (phone_number, session_data, session_status, last_updated)
                              VALUES (%s, %s, 'ACTIVE', GETUTCDATE());
        """, (clean, js, clean, js))
        conn.commit(); conn.close()
    except Exception as e:
        logging.error(f"[session.save] {e}")

def clear_session(phone: str):
    try:
        conn = get_connection(); cur = conn.cursor()
        clean = phone.replace("+","").strip()
        cur.execute("UPDATE dbo.Consumer_Query_Sessions SET session_status='EXPIRED', session_data='{}' WHERE phone_number=%s", (clean,))
        conn.commit(); conn.close()
    except Exception as e:
        logging.error(f"[session.clear] {e}")
