"""
trader/submit.py — WhatsApp Trader Price Submission Flow
=========================================================
Multi-step flow:
  Step 1: Category selection
  Step 2: Item selection (with price guidance hint)
  Step 3: Price entry (with guidance range shown)
  Step 4: Confirmation
  Step 5: Submit to DB

Rules enforced (mirrors PWA):
  - 2-trader cap per item per market per slot
  - 1-per-approved (no resubmit of approved item same slot)
  - SYN-% excluded from cap count
  - ±10% guidance shown before price entry
"""

import logging
import os
from datetime import datetime, timezone

REWARD_PER_SUBMISSION = 20  # ₦20 per approved submission

# Time slot from UTC hour (mirrors PWA slot-status logic)
def _current_slot():
    h = datetime.now(timezone.utc).hour
    if h < 8:  return 'MORNING'
    if h < 13: return 'MIDDAY'
    return 'AFTERNOON'

def _get_conn():
    import pymssql
    return pymssql.connect(
        server   = os.environ['SQL_SERVER'],
        user     = os.environ.get('SQL_USERNAME') or os.environ.get('SQL_USER'),
        password = os.environ['SQL_PASSWORD'],
        database = os.environ.get('SQL_DATABASE', 'naijafoodmarket-live'),
        timeout  = 30,
        as_dict  = True,
    )

def _fmt(n):
    """Format number as ₦X,XXX"""
    try:
        return f"₦{int(float(n)):,}"
    except:
        return str(n)

def _get_trader(phone):
    """Load trader record from Traders_register."""
    try:
        conn = _get_conn()
        cur  = conn.cursor()
        cur.execute("""
            SELECT trader_id, full_name, first_name,
                   assigned_market_id, assigned_market_name, assigned_state,
                   reputation, registration_status, is_suspended
            FROM   dbo.Traders_register
            WHERE  phone_number = %s
        """, (phone,))
        row = cur.fetchone()
        conn.close()
        return row
    except Exception as e:
        logging.error(f'[trader.submit] get_trader error: {e}')
        return None

def _get_categories(market_id):
    """Load food categories that have items."""
    try:
        conn = _get_conn()
        cur  = conn.cursor()
        cur.execute("""
            SELECT DISTINCT i.category_id,
                   CASE i.category_id
                     WHEN 'CAT001' THEN 'Grains & Cereals'
                     WHEN 'CAT002' THEN 'Meat & Poultry'
                     WHEN 'CAT003' THEN 'Fish & Seafood'
                     WHEN 'CAT004' THEN 'Vegetables'
                     WHEN 'CAT005' THEN 'Tomatoes & Peppers'
                     WHEN 'CAT006' THEN 'Legumes & Nuts'
                     WHEN 'CAT007' THEN 'Spices & Condiments'
                     WHEN 'CAT008' THEN 'Oils & Fats'
                     WHEN 'CAT009' THEN 'Bread & Bakery'
                     WHEN 'CAT010' THEN 'Bread & Bakery'
                     WHEN 'CAT013' THEN 'Dairy & Eggs'
                     WHEN 'CAT014' THEN 'Tubers & Roots'
                     WHEN 'CAT015' THEN 'Fruits'
                     WHEN 'CAT070' THEN 'Household Essentials'
                     ELSE i.category_id
                   END AS category_name
            FROM   dbo.Items_Catalog i
            WHERE  (i.status = 'ACTIVE' OR i.status IS NULL)
              AND  i.category_id IN ('CAT001','CAT002','CAT003','CAT004','CAT005',
                                     'CAT006','CAT007','CAT008','CAT009','CAT010',
                                     'CAT013','CAT014','CAT015','CAT070')
              AND  i.item_id NOT LIKE 'NBS[_]%'
            ORDER BY i.category_id
        """)
        rows = cur.fetchall()
        conn.close()
        # Deduplicate CAT009/CAT010
        seen = set(); result = []
        for r in rows:
            cid = 'CAT010' if r['category_id'] == 'CAT009' else r['category_id']
            if cid not in seen:
                seen.add(cid)
                result.append({'category_id': cid, 'category_name': r['category_name']})
        return result
    except Exception as e:
        logging.error(f'[trader.submit] get_categories error: {e}')
        return []

def _get_items(category_id, market_id):
    """Load items for category with guidance from Latest_Prices_Summary."""
    try:
        conn = _get_conn()
        cur  = conn.cursor()
        # Include CAT009 items when CAT010 selected
        cat_filter = "('CAT009','CAT010')" if category_id == 'CAT010' else f"('{category_id}')"
        cur.execute(f"""
            SELECT i.item_id, i.item_name, i.Unit,
                   lps.price_naira AS baseline
            FROM   dbo.Items_Catalog i
            LEFT JOIN (
                SELECT item_id, price_naira
                FROM   dbo.Latest_Prices_Summary
                WHERE  market_id   = %s
                  AND  is_nbs_ref  = 0
                  AND  is_food     = 1
            ) lps ON lps.item_id = i.item_id
            WHERE  i.category_id IN {cat_filter}
              AND  (i.status = 'ACTIVE' OR i.status IS NULL)
              AND  i.item_id NOT LIKE 'NBS[_]%%'
            ORDER BY i.item_name
        """, (market_id,))
        rows = cur.fetchall()
        conn.close()
        return rows
    except Exception as e:
        logging.error(f'[trader.submit] get_items error: {e}')
        return []

def _check_slot_rules(phone, trader_id, item_id, market_id):
    """
    Returns (can_submit, block_reason, avg_price)
    Mirrors PWA slot-status logic exactly.
    """
    slot = _current_slot()
    try:
        conn = _get_conn()
        cur  = conn.cursor()

        # Rule 1: trader already approved for this item this slot
        cur.execute("""
            SELECT COUNT(*) AS cnt FROM dbo.Submissions
            WHERE  trader_phone = %s AND item_id = %s AND market_id = %s
              AND  validation_status = 'APPROVED'
              AND  CAST(TRY_CAST(submitted_at AS DATETIME2) AS DATE) = CAST(GETUTCDATE() AS DATE)
              AND  %s = CASE
                WHEN DATEPART(HOUR, TRY_CAST(submitted_at AS DATETIME2)) < 8  THEN 'MORNING'
                WHEN DATEPART(HOUR, TRY_CAST(submitted_at AS DATETIME2)) < 13 THEN 'MIDDAY'
                ELSE 'AFTERNOON' END
        """, (phone, item_id, market_id, slot))
        if int(cur.fetchone()['cnt']) > 0:
            conn.close()
            return False, 'approved', None

        # Rule 2: 2-trader cap
        cur.execute("""
            SELECT COUNT(*) AS cnt, AVG(CAST(price AS FLOAT)) AS avg_price
            FROM   dbo.Submissions
            WHERE  item_id = %s AND market_id = %s
              AND  trader_phone <> %s
              AND  trader_id NOT LIKE 'SYN-%%'
              AND  validation_status IN ('PENDING','APPROVED')
              AND  CAST(TRY_CAST(submitted_at AS DATETIME2) AS DATE) = CAST(GETUTCDATE() AS DATE)
              AND  %s = CASE
                WHEN DATEPART(HOUR, TRY_CAST(submitted_at AS DATETIME2)) < 8  THEN 'MORNING'
                WHEN DATEPART(HOUR, TRY_CAST(submitted_at AS DATETIME2)) < 13 THEN 'MIDDAY'
                ELSE 'AFTERNOON' END
        """, (item_id, market_id, phone, slot))
        row = cur.fetchone()
        conn.close()
        count = int(row['cnt']) if row else 0
        avg   = float(row['avg_price']) if row and row['avg_price'] else None
        if count >= 2:
            return False, 'full', avg
        return True, '', None
    except Exception as e:
        logging.error(f'[trader.submit] slot_rules error: {e}')
        return True, '', None  # fail open so traders aren't blocked by DB errors

def _insert_submission(phone, trader_id, trader_name, market_id, market_name,
                       state, item_id, item_name, unit, price):
    """Insert into dbo.Submissions."""
    import uuid
    sub_id = f"SUB-WA-{trader_id}-{int(datetime.now(timezone.utc).timestamp())}"
    now    = datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M:%S')
    try:
        conn = _get_conn()
        cur  = conn.cursor()
        cur.execute("""
            INSERT INTO dbo.Submissions (
                submission_id, trader_phone, trader_id, trader_name,
                market_id, market, state,
                item_id, item, category_id, unit,
                price, validation_status, status,
                fraud_flag, gps_verified,
                submitted_at, created_at
            ) VALUES (
                %s, %s, %s, %s,
                %s, %s, %s,
                %s, %s, 'WA', %s,
                %s, 'PENDING', 'PENDING',
                0, 0,
                %s, %s
            )
        """, (sub_id, phone, trader_id, trader_name,
              market_id, market_name, state,
              item_id, item_name, unit,
              price, now, now))

        # Auto-upsert favourites after 3+ submissions
        cur.execute("""
            SELECT COUNT(*) AS cnt FROM dbo.Submissions
            WHERE trader_phone = %s AND item_id = %s
        """, (phone, item_id))
        sub_count = int(cur.fetchone()['cnt']) or 0

        if sub_count >= 3:
            cur.execute("""
                MERGE dbo.Trader_Favourites AS target
                USING (SELECT %s AS trader_phone, %s AS item_id) AS source
                  ON  target.trader_phone = source.trader_phone
                  AND target.item_id      = source.item_id
                WHEN MATCHED THEN
                  UPDATE SET use_count = use_count + 1, last_used_at = GETUTCDATE()
                WHEN NOT MATCHED THEN
                  INSERT (trader_phone, trader_id, item_id, item_name, unit)
                  VALUES (%s, %s, %s, %s, %s)
            """, (phone, item_id, phone, trader_id, item_id, item_name, unit or ''))

        conn.commit()
        conn.close()
        return sub_id, sub_count
    except Exception as e:
        logging.error(f'[trader.submit] insert error: {e}')
        raise

# ─── Main handler ───────────────────────────────────────────────────────────

def handle_submit(phone, message="", session=None, *args):
    from shared.sender  import send_message
    from shared.session import save_session

    if session is None:
        session = {}

    msg   = message.strip()
    step  = session.get('_step', 'START')

    # Load trader record
    trader = _get_trader(phone)
    if not trader:
        send_message(phone,
            "❌ *Not registered as a trader.*\n\n"
            "Type *register* to become a NaijaMarket trader and earn ₦20 per submission."
        )
        return

    if trader.get('registration_status') != 'APPROVED':
        send_message(phone,
            "⏳ *Your trader registration is pending approval.*\n\n"
            "You'll receive a WhatsApp message once approved.\n"
            "Type *menu* to go back."
        )
        return

    if trader.get('is_suspended'):
        send_message(phone,
            "🚫 *Your account has been suspended.*\n\n"
            "Contact support for assistance.\n"
            "Type *menu* to go back."
        )
        return

    market_id   = trader['assigned_market_id']
    market_name = trader['assigned_market_name']
    state       = trader['assigned_state'] or ''
    trader_id   = trader['trader_id']
    first_name  = (trader.get('first_name') or trader.get('full_name') or 'Trader').split()[0]

    # ── STEP: CATEGORY SELECTION ─────────────────────────────────────────
    if step == 'START' or step == 'CATEGORY':
        categories = _get_categories(market_id)
        if not categories:
            send_message(phone, "❌ No categories available. Type *menu* to go back.")
            return

        lines = [f"📦 *Submit Price — {market_name}*\n\nSelect a category:\n"]
        for i, cat in enumerate(categories, 1):
            lines.append(f"{i}. {cat['category_name']}")
        lines.append("\n0 — Back to menu")
        lines.append("_Reply with a number_")

        session['_flow']       = 'TRADER_SUBMIT'
        session['_step']       = 'ITEM'
        session['_categories'] = [c['category_id'] for c in categories]
        session['_cat_names']  = [c['category_name'] for c in categories]
        save_session(phone, session)
        send_message(phone, '\n'.join(lines))
        return

    # ── STEP: ITEM SELECTION ─────────────────────────────────────────────
    if step == 'ITEM':
        if msg == '0':
            session['_step'] = 'CATEGORY'
            save_session(phone, session)
            handle_submit(phone, '', session)
            return

        categories = session.get('_categories', [])
        try:
            idx = int(msg) - 1
            assert 0 <= idx < len(categories)
        except:
            send_message(phone, f"❌ Please enter a number between 1 and {len(categories)}.")
            return

        cat_id   = categories[idx]
        cat_name = session.get('_cat_names', [])[idx] if session.get('_cat_names') else cat_id
        items    = _get_items(cat_id, market_id)

        if not items:
            send_message(phone, f"No items found in {cat_name}. Try another category.")
            return

        lines = [f"🛒 *{cat_name}*\n\nSelect an item:\n"]
        for i, item in enumerate(items, 1):
            baseline = item.get('baseline')
            hint     = f" (Ref: {_fmt(baseline)})" if baseline else ''
            lines.append(f"{i}. {item['item_name']}{hint}")
        lines.append(f"\n0 — Back\n_Reply with a number_")

        session['_step']     = 'PRICE'
        session['_cat_id']   = cat_id
        session['_items']    = [(r['item_id'], r['item_name'], r.get('Unit',''), r.get('baseline')) for r in items]
        save_session(phone, session)
        send_message(phone, '\n'.join(lines))
        return

    # ── STEP: PRICE ENTRY ────────────────────────────────────────────────
    if step == 'PRICE':
        if msg == '0':
            session['_step'] = 'ITEM'
            save_session(phone, session)
            handle_submit(phone, '', session)
            return

        items = session.get('_items', [])
        try:
            idx = int(msg) - 1
            assert 0 <= idx < len(items)
        except:
            send_message(phone, f"❌ Please enter a number between 1 and {len(items)}.")
            return

        item_id, item_name, unit, baseline = items[idx]

        # Check slot rules before asking for price
        can_submit, reason, avg_price = _check_slot_rules(phone, trader_id, item_id, market_id)

        if not can_submit:
            if reason == 'approved':
                send_message(phone,
                    f"✅ *{item_name}*\n\n"
                    f"We already have your approved price for this item this period.\n\n"
                    f"Please submit price for another product.\n"
                    f"Type *0* to go back."
                )
            else:
                avg_str = f"\n\n📊 *Current market price:* {_fmt(avg_price)}" if avg_price else ''
                send_message(phone,
                    f"✓ *We already have the price for {item_name}. Please submit price for another product.*"
                    f"{avg_str}\n\n"
                    f"Type *0* to go back."
                )
            return

        # Build guidance hint
        if baseline and float(baseline) > 0:
            low  = int(float(baseline) * 0.90)
            high = int(float(baseline) * 1.10)
            guidance = f"\n\n📊 *Market range:* {_fmt(low)} – {_fmt(high)}"
        else:
            guidance = ''

        unit_str = f"per {unit}" if unit else ''
        session['_step']       = 'CONFIRM'
        session['_item_id']    = item_id
        session['_item_name']  = item_name
        session['_item_unit']  = unit
        save_session(phone, session)

        send_message(phone,
            f"💵 *{item_name}* {unit_str}"
            f"{guidance}\n\n"
            f"Enter the price in Naira (numbers only):\n"
            f"Example: *55000*\n\n"
            f"0 — Back"
        )
        return

    # ── STEP: CONFIRMATION ───────────────────────────────────────────────
    if step == 'CONFIRM':
        if msg == '0':
            session['_step'] = 'PRICE'
            save_session(phone, session)
            handle_submit(phone, '', session)
            return

        # Parse price
        price_str = msg.replace(',', '').replace('₦', '').strip()
        try:
            price = float(price_str)
            assert price >= 10
            assert price <= 100_000_000
        except:
            send_message(phone,
                "❌ Invalid price. Enter numbers only (e.g. *55000*).\n"
                "Minimum ₦10, maximum ₦100,000,000.\n\n"
                "0 — Back"
            )
            return

        item_id   = session.get('_item_id', '')
        item_name = session.get('_item_name', '')
        unit      = session.get('_item_unit', '')
        unit_str  = f"per {unit}" if unit else ''

        session['_step']  = 'SUBMIT'
        session['_price'] = price
        save_session(phone, session)

        send_message(phone,
            f"✅ *Confirm Submission*\n\n"
            f"📍 Market: {market_name}\n"
            f"📦 Item: {item_name} {unit_str}\n"
            f"💵 Price: {_fmt(price)}\n\n"
            f"Reply *yes* to submit or *0* to cancel."
        )
        return

    # ── STEP: FINAL SUBMIT ───────────────────────────────────────────────
    if step == 'SUBMIT':
        if msg == '0' or msg in ('no', 'cancel'):
            session['_step'] = 'CATEGORY'
            save_session(phone, session)
            handle_submit(phone, '', session)
            return

        if msg not in ('yes', 'y', '1'):
            send_message(phone, "Reply *yes* to confirm or *0* to cancel.")
            return

        item_id    = session.get('_item_id', '')
        item_name  = session.get('_item_name', '')
        unit       = session.get('_item_unit', '')
        price      = float(session.get('_price', 0))
        trader_name = trader.get('full_name') or first_name

        # Final server-side slot check
        can_submit, reason, avg_price = _check_slot_rules(phone, trader_id, item_id, market_id)
        if not can_submit:
            send_message(phone,
                f"✓ We already have the price for {item_name}. Please submit price for another product.\n\n"
                f"Type *0* to go back or *menu* to return to main menu."
            )
            session['_step'] = 'CATEGORY'
            save_session(phone, session)
            return

        try:
            sub_id, sub_count = _insert_submission(
                phone, trader_id, trader_name,
                market_id, market_name, state,
                item_id, item_name, unit, price
            )

            fav_note = '\n⭐ Added to your favourites!' if sub_count >= 3 else ''

            # Clear submit session but stay in trader context
            session.clear()
            session['_flow'] = 'TRADER_SUBMIT'
            session['_step'] = 'CATEGORY'
            save_session(phone, session)

            send_message(phone,
                f"✅ *Price Submitted!*\n\n"
                f"📦 {item_name}\n"
                f"💵 {_fmt(price)}\n"
                f"📍 {market_name}\n\n"
                f"💰 You'll earn ₦{REWARD_PER_SUBMISSION} when approved.\n"
                f"{fav_note}\n\n"
                f"Submit another price? Select a category:\n"
                f"_(or type *menu* to go back)_"
            )
            # Show category menu again for next submission
            handle_submit(phone, '', session)

        except Exception as e:
            logging.error(f'[trader.submit] final submit error: {e}')
            send_message(phone,
                "❌ Submission failed. Please try again.\n\n"
                "Type *submit* to try again or *menu* to go back."
            )
        return

    # Fallback — restart flow
    session['_step'] = 'START'
    save_session(phone, session)
    handle_submit(phone, '', session)
