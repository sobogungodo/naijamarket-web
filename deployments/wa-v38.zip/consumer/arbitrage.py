import logging
from shared.db import get_connection
from shared.query_limit import log_query
from shared.sender import send_message
from shared.session import save_session, clear_session
from shared.lang import get_lang
from shared.i18n import t
from consumer.menu import show_main_menu
from shared.nudge import get_nudge


def handle_arbitrage(phone, message="", session=None, consumer=None, *args):
    session=session or {}; consumer=consumer or {}
    lang=get_lang(session,consumer); text=(message or "").strip(); msg=text.lower()
    step=session.get("step",0)
    if msg in ("0","menu","back"): clear_session(phone); show_main_menu(phone); return
    if step==0:
        session.update({"_flow":"ARBITRAGE","step":1}); save_session(phone,session)
        send_message(phone, t(lang,"arbi_title"))
    elif step==1: _show(phone,text,session,lang)
    elif step==99: _handle_repeat_search(phone,text,session,lang)


def _show(phone,query,session,lang):
    try:
        conn=get_connection(); cur=conn.cursor()
        cur.execute("SELECT TOP 1 item_name FROM dbo.Latest_Prices_Summary WHERE item_name LIKE %s AND is_nbs_ref=0 AND is_food=1 GROUP BY item_name ORDER BY item_name",(f"%{query}%",))
        row=cur.fetchone()
        if not row: conn.close(); send_message(phone,t(lang,"arbi_not_found",q=query)); return
        item_name=row["item_name"]
        cur.execute("SELECT TOP 10 market_id,market_name,state,price_naira,unit FROM dbo.Latest_Prices_Summary WHERE item_name=%s AND is_nbs_ref=0 AND is_food=1 AND price_naira>0 ORDER BY price_naira ASC",(item_name,))
        rows=cur.fetchall(); conn.close()
        if not rows or len(rows)<2: send_message(phone,t(lang,"error_generic")); return
        low=rows[0]; high=rows[-1]; unit=low["unit"] or "unit"
        spread=float(high["price_naira"])-float(low["price_naira"])
        pct=(spread/float(low["price_naira"])*100) if float(low["price_naira"])>0 else 0
        ladder="\n".join(f"{i+1}. {r['market_name']} ({r['state']}): *\u20a6{float(r['price_naira']):,.0f}*" for i,r in enumerate(rows))
        session.update({"step":99}); save_session(phone,session)
        repeat = (
            "\n\n━━━━━━━━━━━━━━━━━━━━━━\n"
            "*1* — Search again\n*0* — Menu"
        ) if lang=="en" else (
            "\n\n━━━━━━━━━━━━━━━━━━━━━━\n"
            "*1* — Search again\n*0* — Menu"
        )
        log_query(phone,{},""+item_name,"")
        # Transport cost lookup
        transport=""
        try:
            buy_mid=low.get("market_id",""); sell_mid=high.get("market_id","")
            if buy_mid and sell_mid:
                cur.execute("SELECT TOP 1 total_cost_per_bag FROM dbo.vw_Market_Transport WHERE (market_a_id=%s AND market_b_id=%s) OR (market_a_id=%s AND market_b_id=%s)",(buy_mid,sell_mid,sell_mid,buy_mid))
                tr=cur.fetchone()
                if tr:
                    tc=float(tr["total_cost_per_bag"] or 0)
                    net=spread-tc
                    if lang=="pcm":
                        transport=f"\n🚚 Transport: *₦{tc:,.0f}/bag* | Net gain: *₦{net:,.0f}*" if net>0 else f"\n🚚 Transport: *₦{tc:,.0f}/bag* | ⚠️ Transport cost exceeds spread"
                    else:
                        transport=f"\n🚚 Transport: *₦{tc:,.0f}/bag* | Net profit: *₦{net:,.0f}*" if net>0 else f"\n🚚 Transport: *₦{tc:,.0f}/bag* | ⚠️ Transport exceeds spread"
        except Exception as _te:
            import logging as _tl; _tl.warning(f"[arbi] transport lookup: {_te}")
        send_message(phone, t(lang,"arbi_result",
            item=item_name,
            buy_mkt=low["market_name"], buy_st=low["state"], buy_p=float(low["price_naira"]),
            sell_mkt=high["market_name"], sell_st=high["state"], sell_p=float(high["price_naira"]),
            spread=spread, pct=pct, unit=unit, ladder=ladder, transport=transport) + repeat + get_nudge(lang, "ARBITRAGE"))
    except Exception as e:
        logging.error(f"[arbitrage] {e}"); send_message(phone,t(lang,"error_generic"))


def _handle_repeat_search(phone, text, session, lang):
    msg=text.strip().lower()
    if msg in ("0","menu","back"): clear_session(phone); show_main_menu(phone); return
    if msg=="1":
        session["step"]=0; save_session(phone,session)
        handle_arbitrage(phone,"",session,None); return
    send_message(phone,t(lang,"invalid_choice"))
