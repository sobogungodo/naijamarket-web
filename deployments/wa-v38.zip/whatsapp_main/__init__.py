"""
NaijaMarket Intel — WhatsApp Router v2.1
=========================================
Builds on v2.0 (June 4 2026 — Pidgin + downgrade).

New in v2.1 (G1-WA [1f]-[1o]):
  [1f] 24h template/freetext branching — shared/messaging.py
  [1g] Opt-in captured in welcome flow and optin module
  [1h] First-touch welcome flow for new users
  [1i] 'help' keyword — preserves session, shows help card
  [1j] 'report' keyword — report wrong price flow
  [1k] Free-text search fallback for commodity names
  [1l] Freshness notes injected into price replies (prices/snapshot/compare)
  [1m] Session-expiry detection + user-facing message; empty/error states in i18n
  [1n] 'share' keyword — shareable price card from last-viewed price
  [1o] Per-message rate limiting (30 msgs/60 min, stored in session)
"""
import logging
import importlib
import azure.functions as func
from datetime import datetime, timezone
from urllib.parse import unquote_plus

# Rate limit config [1o]
_RATE_LIMIT_MAX    = 30   # max messages per window
_RATE_LIMIT_WINDOW = 3600  # 60 minutes in seconds

# Session timeout for expiry message [1m]
_SESSION_TIMEOUT_MIN = 30


def _check_rate_limit(session: dict, phone: str) -> tuple[bool, dict]:
    """
    Returns (is_limited, updated_session).
    Stores _rate_count and _rate_reset (epoch int) in session data.
    Note: wiped on clear_session (fresh keywords) — acceptable for soft launch.
    """
    now = int(datetime.now(timezone.utc).timestamp())
    count = session.get("_rate_count", 0)
    reset = session.get("_rate_reset", 0)

    if now >= reset:
        # Window expired or first message — start fresh
        session["_rate_count"] = 1
        session["_rate_reset"] = now + _RATE_LIMIT_WINDOW
        return False, session

    count += 1
    session["_rate_count"] = count
    if count > _RATE_LIMIT_MAX:
        logging.warning(f"[v2.1] rate limit hit for {phone}: {count} msgs")
        return True, session

    return False, session


def _session_expired(session: dict) -> bool:
    """True if session has data but last_updated is older than TIMEOUT."""
    # We detect expiry from _flow being set but _rate_reset being very old.
    # Primary check: session has a flow but no recent activity.
    # Lightweight: compare _rate_reset (set each message) to now.
    reset = session.get("_rate_reset", 0)
    if not reset or not session.get("_flow"):
        return False
    now = int(datetime.now(timezone.utc).timestamp())
    # If rate_reset was set > (TIMEOUT + WINDOW) ago, session is very stale
    age_min = (now - (reset - _RATE_LIMIT_WINDOW)) / 60
    return age_min > _SESSION_TIMEOUT_MIN


def main(req: func.HttpRequest) -> func.HttpResponse:
    try:
        # ── Parse incoming webhook ──────────────────────────────────────
        try:
            body_json = req.get_json()
            entry  = body_json["entry"][0]
            change = entry["changes"][0]["value"]

            # Webhook verification or status callbacks — no messages key
            if "messages" not in change:
                return func.HttpResponse("OK", status_code=200)

            msg_obj = change["messages"][0]
            phone   = msg_obj["from"]
            message = (msg_obj.get("text") or {}).get("body", "").strip()
        except Exception:
            # Fallback: form-encoded (Twilio legacy / verification)
            body = req.get_body().decode("utf-8", errors="replace")
            params = {}
            for part in body.split("&"):
                if "=" in part:
                    k, v = part.split("=", 1)
                    params[unquote_plus(k)] = unquote_plus(v)
            from_raw = params.get("From", "")
            message  = params.get("Body", "").strip()
            from shared.phone import normalize
            phone = normalize(from_raw)

        if not phone or not message:
            return func.HttpResponse("OK", status_code=200)

        logging.info(f"[v2.1] {phone} | {message[:80]}")

        def mod(name):
            return importlib.import_module(name)

        from shared.session import get_session, clear_session, save_session
        from shared.sender  import send_message
        from shared.lang    import get_lang
        from shared.i18n    import t

        msg = message.strip().lower()

        # ── [1i] Help intercept — before FRESH_KEYWORDS to preserve session ─
        if msg in ("help", "?"):
            session = get_session(phone) or {}
            consumer = _get_consumer(phone, mod)
            mod("consumer.help").show_help(phone, session, consumer)
            return func.HttpResponse("OK", status_code=200)

        # ── [1o] Rate limiting ───────────────────────────────────────────
        # Read session before FRESH_KEYWORDS potentially clears it
        _pre_session = get_session(phone) or {}
        limited, _pre_session = _check_rate_limit(_pre_session, phone)
        if limited:
            lang = get_lang(_pre_session, {})
            send_message(phone, t(lang, "rate_limit"))
            # Still save updated count so limit persists
            save_session(phone, _pre_session)
            return func.HttpResponse("OK", status_code=200)

        # ── [1n] Share keyword ──────────────────────────────────────────
        if msg == "share":
            session = _pre_session
            consumer = _get_consumer(phone, mod)
            mod("consumer.share").handle_share(phone, session, consumer)
            save_session(phone, session)
            return func.HttpResponse("OK", status_code=200)

        # ── [1j] Report keyword ─────────────────────────────────────────
        if msg == "report":
            session = _pre_session
            consumer = _get_consumer(phone, mod)
            mod("consumer.report").start_report(phone, session, consumer)
            return func.HttpResponse("OK", status_code=200)

        # ── STOP / opt-out handling ─────────────────────────────────────
        if msg in ("stop", "optout", "unsubscribe", "opt-out"):
            from shared.optin import record_optout
            record_optout(phone)
            clear_session(phone)
            lang = get_lang(_pre_session, {})
            send_message(phone,
                "You have been unsubscribed from NaijaMarket Intel notifications.\n"
                "Reply *start* or *menu* to re-subscribe." if lang == "en" else
                "You don unsubscribe from NaijaMarket Intel notifications.\n"
                "Reply *start* or *menu* to re-subscribe."
            )
            return func.HttpResponse("OK", status_code=200)

        # ── Global keyword overrides (clear session) ────────────────────
        # ── TRADER keywords ──────────────────────────────────────────────
        if msg in ("submit", "price", "submitprice"):
            trader_rec = _get_trader_record(phone)
            if trader_rec and trader_rec.get("registration_status") == "APPROVED":
                clear_session(phone)
                save_session(phone, {"_flow": "TRADER_SUBMIT", "_step": "START"})
                new_session = {"_flow": "TRADER_SUBMIT", "_step": "START"}
                mod("trader.submit").handle_submit(phone, message, new_session)
            else:
                send_message(phone,
                    "📋 *Become a NaijaMarket Trader*\n\n"
                    "Earn \N{NAIRA SIGN}20 for every approved price submission!\n\n"
                    "Register at: https://naijamarket-trader.vercel.app\n\n"
                    "Already registered? Your account may be pending approval.\n"
                    "Type *menu* to go back."
                )
            return func.HttpResponse("OK", status_code=200)

        if msg in ("register", "trader", "join"):
            clear_session(phone)
            new_session = {"_flow": "TRADER_KYC", "_step": "START"}
            mod("trader.kyc").handle_kyc(phone, message, new_session)
            return func.HttpResponse("OK", status_code=200)


        # ── Smart back navigation ───────────────────────────────────────────────
        # back@step99 = re-show search prompt; back@other = main menu
        if msg == "back":
            _bk_flow = _pre_session.get("_flow", "").upper()
            _bk_step = _pre_session.get("step", 0)
            _bk_consumer = _get_consumer(phone, mod)
            if _bk_flow and _bk_step == 99:
                _pre_session["step"] = 0
                save_session(phone, _pre_session)
                _BACK_FLOWS = {
                    "TREND":     ("consumer.trend",    "handle_trend"),
                    "COMPARE":   ("consumer.compare",  "handle_compare"),
                    "BULK":      ("consumer.bulk",     "handle_bulk"),
                    "FORECAST":  ("consumer.forecast", "handle_forecast"),
                    "ARBITRAGE": ("consumer.arbitrage","handle_arbitrage"),
                }
                if _bk_flow in _BACK_FLOWS:
                    _bk_m, _bk_f = _BACK_FLOWS[_bk_flow]
                    getattr(mod(_bk_m), _bk_f)(phone, "", _pre_session, _bk_consumer)
                else:
                    if _bk_consumer: mod("consumer.menu").show_main_menu(phone)
            else:
                _bk_rc = _pre_session.get("_rate_count", 1)
                _bk_rr = _pre_session.get("_rate_reset", 0)
                clear_session(phone)
                save_session(phone, {"_rate_count": _bk_rc, "_rate_reset": _bk_rr})
                if _bk_consumer: mod("consumer.menu").show_main_menu(phone)
                else: mod("consumer.welcome").start_welcome(phone)
            return func.HttpResponse("OK", status_code=200)
        FRESH_KEYWORDS = {
            "menu", "0", "hi", "hello", "start",
            "home", "restart", "reset"
        }

        if msg in FRESH_KEYWORDS:
            # Carry rate limit data across the clear so it can't be reset
            rate_count = _pre_session.get("_rate_count", 1)
            rate_reset = _pre_session.get("_rate_reset", 0)
            clear_session(phone)
            session = {"_rate_count": rate_count, "_rate_reset": rate_reset}
            # Re-fetch consumer after clearing — registered users go straight to menu
            _fresh_consumer = _get_consumer(phone, mod)
            if _fresh_consumer:
                mod("consumer.menu").show_main_menu(phone)
                return func.HttpResponse("OK", status_code=200)
        else:
            session = _pre_session

        # ── [1m] Session expiry detection ───────────────────────────────
        if _session_expired(session) and session.get("_flow"):
            lang = get_lang(session, {})
            send_message(phone, t(lang, "session_expired"))
            rate_count = session.get("_rate_count", 1)
            rate_reset = session.get("_rate_reset", 0)
            clear_session(phone)
            session = {"_rate_count": rate_count, "_rate_reset": rate_reset}
            save_session(phone, session)
            return func.HttpResponse("OK", status_code=200)


        # ── Universal: feedback command (works for all roles) ────────────
        if msg in ("feedback",) or msg.lower().startswith("feedback ") or                 (session or {}).get("_flow") == "FEEDBACK":
            _role = mod("shared.db").get_role(phone) or "UNKNOWN"
            mod("shared.feedback").handle_feedback(phone, message, session, _role)
            return func.HttpResponse("OK", status_code=200)

        # ── Role detection (User_Roles is authoritative) ───────────────
        role = mod("shared.db").get_role(phone) or ""

        # ── TRADER role — route to trader menu ──────────────────────────
        if role == "TRADER":
            from trader.menu import handle_trader_menu
            handle_trader_menu(phone, message, session)
            return func.HttpResponse("OK", status_code=200)
        if role == "VALIDATOR":
            current_flow = session.get("_flow", "").upper()
            if current_flow == "VALIDATOR_MENU":
                mod("validator.menu").handle_validator(phone, message, session)
                return func.HttpResponse("OK", status_code=200)
            clear_session(phone)
            mod("validator.menu").handle_validator(phone, message, {})
            return func.HttpResponse("OK", status_code=200)

        # ── CONSUMER role (default) ──────────────────────────────────────
        consumer = _get_consumer(phone, mod)

        # ── [1h] First-touch welcome — new user with no consumer record ──
        if not consumer:
            FREE_QUERY_KEYWORDS = {
                "prices", "price", "1", "p", "qp", "quick",
                "arbitrage", "arbi", "2",
                "compare", "4",
                "trend", "5",
                "snapshot", "6",
                "brief", "10",
            }
            session_data = session  # already loaded above
            current_flow = session_data.get("_flow", "")
            free_used = session_data.get("_free_query_used", False)

            if current_flow:
                # Mid-flow — let session continuation handle it below
                pass
            elif msg in FREE_QUERY_KEYWORDS and not free_used:
                # First touch with a price keyword
                if consumer:
                    # Already registered — skip free query message, go straight to flow
                    pass
                else:
                    # Unregistered — grant one free query with notice
                    session_data["_free_query_used"] = True
                    session_data["_flow"] = ""
                    save_session(phone, session_data)
                    lang = get_lang(session_data, {})
                    send_message(phone,
                        "Welcome to NaijaMarket Intel!\n\n"
                        "You have *1 free price check* before registration.\n\n"
                        "Type *menu* after to register and get full access." if lang == "en" else
                        "Welcome to NaijaMarket Intel!\n\n"
                        "You get *1 free price check* before you register.\n\n"
                        "Type *menu* after to register and get full access."
                    )
                # Fall through to normal keyword routing below
            else:
                # No active flow, no free query — gate with registration
                # But first re-check consumer in case they just registered
                consumer = _get_consumer(phone, mod)
                if consumer:
                    mod("consumer.menu").show_main_menu(phone)
                else:
                    mod("consumer.welcome").start_welcome(phone)
                return func.HttpResponse("OK", status_code=200)

        # ── Role for consumer session ────────────────────────────────────
        role = "CONSUMER"

        # ── Expiry warning check ────────────────────────────────────────
        if consumer and msg not in ("renew","upgrade","subscribe","0","menu","back"):
            _exp_lang = get_lang(session, consumer)
            _exp_warn = _check_expiry_warning(consumer, _exp_lang, t)
            if _exp_warn:
                send_message(phone, _exp_warn)

        # ── DOWNGRADE keywords ──────────────────────────────────────────
        if msg in ("downgrade", "cancel-downgrade"):
            clear_session(phone)
            new_session = {"_flow": "DOWNGRADE", "_step": ""}
            mod("consumer.downgrade").handle_downgrade(phone, message, new_session)
            return func.HttpResponse("OK", status_code=200)

        # ── LANG keyword ────────────────────────────────────────────────
        if msg in ("lang", "english", "pidgin", "en", "pcm", "pg"):
            from consumer.lang_flow import handle_lang
            lang_session = session.copy() if session else {}
            lang_session["_lang_prev_flow"] = session.get("_flow", "")
            handle_lang(phone, message, lang_session, consumer)
            return func.HttpResponse("OK", status_code=200)

        # ── UPGRADE keyword ─────────────────────────────────────────────
        if msg in ("upgrade", "subscribe"):
            clear_session(phone)
            mod("consumer.tokens").handle_tokens_flow(phone, message, {}, consumer)
            return func.HttpResponse("OK", status_code=200)

        # ── TRADER keywords ──────────────────────────────────────────────
        if msg in ("submit", "price", "submitprice"):
            trader_rec = _get_trader_record(phone)
            if trader_rec and trader_rec.get("registration_status") == "APPROVED":
                clear_session(phone)
                new_session = {"_flow": "TRADER_SUBMIT", "_step": "START"}
                mod("trader.submit").handle_submit(phone, message, new_session)
            else:
                send_message(phone,
                    "📋 *Become a NaijaMarket Trader*\n\n"
                    "Earn \N{NAIRA SIGN}20 for every approved price submission!\n\n"
                    "Register at: https://naijamarket-trader.vercel.app\n\n"
                    "Already registered? Your account may be pending approval.\n"
                    "Type *menu* to go back."
                )

        if msg in ("register", "trader", "join"):
            clear_session(phone)
            new_session = {"_flow": "TRADER_KYC", "_step": "START"}
            mod("trader.kyc").handle_kyc(phone, message, new_session)
            return func.HttpResponse("OK", status_code=200)

        # ── Session-based flow continuation ─────────────────────────────

        # ── Nudge keyword interceptor ───────────────────────────────────────
        # Typed a menu keyword at result state — clear session, fall to KEYWORD_MAP
        _nk_step = session.get("step", 0)
        _nk_flow = session.get("_flow","").upper()
        _NUDGE_INTERCEPT = {
            "alerts","myalerts","compare","trend","arbitrage","forecast",
            "snapshot","brief","bulk","nfpi","prices","filter","export","calc",
            "1","2","3","4","5","6","7","8","9","10"
        }
        if _nk_flow and _nk_step >= 6 and msg in _NUDGE_INTERCEPT:
            _rc=session.get("_rate_count",1); _rr=session.get("_rate_reset",0)
            clear_session(phone)
            session={"_rate_count":_rc,"_rate_reset":_rr}

        current_flow = session.get("_flow", "").upper()

        if current_flow:
            # Query limit check before dispatching price flows
            PRICE_FLOWS = {"PRICES","ARBITRAGE","COMPARE","TREND","SNAPSHOT",
                           "NFPI","BULK","FORECAST","BRIEF","FILTER","EXPORT"}
            if current_flow in PRICE_FLOWS and consumer:
                try:
                    allowed, limit_msg = check_query_limit(phone, consumer)
                    if not allowed:
                        lang = get_lang(session, consumer)
                        send_message(phone, limit_msg)
                        return func.HttpResponse("OK", status_code=200)
                except Exception as _qle:
                    import logging as _log
                    _log.error(f"[router] FLOW check_query_limit CRASH: {_qle}", exc_info=True)
            FLOW_MAP = {
                "PRICES":    ("consumer.prices",       "handle_prices",       phone, message, session, consumer),
                "ARBITRAGE": ("consumer.arbitrage",    "handle_arbitrage",    phone, message, session, consumer),
                "ALERTS":    ("consumer.alerts",       "handle_alerts",       phone, message, session, consumer),
                "COMPARE":   ("consumer.compare",      "handle_compare",      phone, message, session, consumer),
                "TREND":     ("consumer.trend",        "handle_trend",        phone, message, session, consumer),
                "SNAPSHOT":  ("consumer.snapshot",     "handle_snapshot",     phone, message, session, consumer),
                "FAVORITES": ("consumer.favorites",    "handle_favorites",    phone, message, session, consumer),
                "FILTER":    ("consumer.filter_prices","handle_filter",       phone, message, session, consumer),
                "EXPORT":    ("consumer.export_data",  "handle_export",       phone, message, session, consumer),
                "CALC":      ("consumer.calc",         "handle_calc",         phone, message, session, consumer),
                "NFPI":      ("consumer.nfpi",         "handle_nfpi",         phone, message, session, consumer),
                "BULK":      ("consumer.bulk",         "handle_bulk",         phone, message, session, consumer),
                "FORECAST":  ("consumer.forecast",     "handle_forecast",     phone, message, session, consumer),
                "BRIEF":     ("consumer.brief",        "handle_brief",        phone, message, session, consumer),
                "TOKENS":    ("consumer.tokens",       "handle_tokens_flow",  phone, message, session, consumer),
                "DOWNGRADE": ("consumer.downgrade",    "handle_downgrade",    phone, message, session),
                "LANG":      ("consumer.lang_flow",    "handle_lang",         phone, message, session, consumer),
                "WELCOME":   ("consumer.welcome",      "handle_welcome",      phone, message, session, consumer),
                "REPORT":    ("consumer.report",       "handle_report",       phone, message, session, consumer),
                # Trader flows
                "TRADER_KYC":    ("trader.kyc",        "handle_kyc",          phone, message, session),
                "TRADER_SUBMIT": ("trader.submit",     "handle_submit",       phone, message, session),
                # Validator flows
                "VALIDATOR_MENU":("validator.menu",    "handle_validator",    phone, message, session),
            }
            entry_cfg = FLOW_MAP.get(current_flow)
            if entry_cfg:
                module_name = entry_cfg[0]
                func_name   = entry_cfg[1]
                args        = entry_cfg[2:]
                result = getattr(mod(module_name), func_name)(*args)
                if result:
                    send_message(phone, result)
                # Save session with updated rate data
                session["_rate_count"] = _pre_session.get("_rate_count", 1)
                session["_rate_reset"]  = _pre_session.get("_rate_reset", 0)
                return func.HttpResponse("OK", status_code=200)

        # ── Fresh keyword routing ───────────────────────────────────────
        # ── Digest opt-in intercept ──────────────────────────────────────────
        if msg in ("digest on","digest off","digest"):
            mod("consumer.digest").handle_digest(phone, message, session, consumer)
            return func.HttpResponse("OK", status_code=200)

        KEYWORD_MAP = {
            "1": "consumer.prices",      "prices": "consumer.prices",
            "2": "consumer.arbitrage",   "arbitrage": "consumer.arbitrage",
            "3": "consumer.alerts",      "alerts": "consumer.alerts",      "myalerts": "consumer.alerts",
            "4": "consumer.compare",     "compare": "consumer.compare",
            "5": "consumer.trend",       "trend": "consumer.trend",
            "6": "consumer.snapshot",    "snapshot": "consumer.snapshot",
            "7": "consumer.nfpi",        "nfpi": "consumer.nfpi",
            "8": "consumer.bulk",        "bulk": "consumer.bulk",
            "9": "consumer.forecast",    "forecast": "consumer.forecast",
            "10": "consumer.brief",      "brief": "consumer.brief",
            "favorites": "consumer.favorites",    "fav": "consumer.favorites",
            "filter": "consumer.filter_prices",
            "export": "consumer.export_data",
            "calc": "consumer.calc",
            "tokens": "consumer.tokens",          "wallet": "consumer.tokens",
            "status": "consumer.status",          "mystatus": "consumer.status",
            # [1k] nav shortcuts
            "qp": "consumer.prices",              "quick": "consumer.prices",
            "p": "consumer.prices",
        }

        ENTRY_FUNCS = {
            "consumer.prices":        "handle_prices",
            "consumer.arbitrage":     "handle_arbitrage",
            "consumer.alerts":        "handle_alerts",
            "consumer.compare":       "handle_compare",
            "consumer.trend":         "handle_trend",
            "consumer.snapshot":      "handle_snapshot",
            "consumer.nfpi":          "handle_nfpi",
            "consumer.bulk":          "handle_bulk",
            "consumer.forecast":      "handle_forecast",
            "consumer.brief":         "handle_brief",
            "consumer.favorites":     "handle_favorites",
            "consumer.filter_prices": "handle_filter",
            "consumer.export_data":   "handle_export",
            "consumer.calc":          "handle_calc",
            "consumer.tokens":        "handle_tokens_flow",
            "consumer.status":        "handle_status",
        }

        target_module = KEYWORD_MAP.get(msg)
        if target_module:
            # Query limit check for fresh keyword price queries
            PRICE_MODULES = {"consumer.prices","consumer.arbitrage","consumer.compare",
                             "consumer.trend","consumer.snapshot","consumer.nfpi",
                             "consumer.bulk","consumer.forecast","consumer.brief",
                             "consumer.filter_prices","consumer.export_data"}
            if target_module in PRICE_MODULES and consumer:
                try:
                    allowed, limit_msg = check_query_limit(phone, consumer)
                    if not allowed:
                        send_message(phone, limit_msg)
                        return func.HttpResponse("OK", status_code=200)
                except Exception as _qle:
                    import logging as _log
                    _log.error(f"[router] check_query_limit CRASH: {_qle}", exc_info=True)
                    # Fail open — continue to flow
            fn = ENTRY_FUNCS.get(target_module, "handle_flow")
            result = getattr(mod(target_module), fn)(phone, message, {}, consumer)
            if result:
                send_message(phone, result)
            return func.HttpResponse("OK", status_code=200)

        # ── [1k] Free-text commodity search fallback ────────────────────
        if len(msg) >= 3 and not msg.isdigit() and msg not in ('submit','price','submitprice','register','trader','join'):
            from shared.search import search_commodity
            hit = search_commodity(message)
            if hit:
                lang = get_lang(session, consumer)
                send_message(phone, t(lang, "search_found", item=hit["item_name"]))
                # Start prices flow — user still needs market drill-down
                result = mod("consumer.prices").handle_prices(
                    phone, hit["item_name"], {}, consumer
                )
                if result:
                    send_message(phone, result)
                return func.HttpResponse("OK", status_code=200)
            # No match — fall through to menu with hint
            lang = get_lang(session, consumer)
            send_message(phone, t(lang, "search_not_found", q=message[:40]))
            return func.HttpResponse("OK", status_code=200)

        # ── Default: show main menu ─────────────────────────────────────
        mod("consumer.menu").show_main_menu(phone)
        return func.HttpResponse("OK", status_code=200)

    except Exception as e:
        logging.error(f"[v2.1] FATAL: {e}", exc_info=True)
        return func.HttpResponse("OK", status_code=200)


def _check_expiry_warning(consumer: dict, lang: str, t_fn) -> str:
    """Return a warning string if subscription expires within 3 days, else empty string."""
    try:
        from datetime import datetime, timezone
        end_raw = (consumer or {}).get("subscription_end_date")
        tier = (consumer or {}).get("subscription_tier","FREE").upper()
        if not end_raw or tier == "FREE": return ""
        end_dt = end_raw if hasattr(end_raw,"date") else datetime.fromisoformat(str(end_raw))
        now = datetime.now(timezone.utc)
        if end_dt.tzinfo is None:
            end_dt = end_dt.replace(tzinfo=timezone.utc)
        days = (end_dt - now).days
        if days < 0:  return t_fn(lang, "expiry_today", tier=tier)
        if days == 0: return t_fn(lang, "expiry_today", tier=tier)
        if days == 1: return t_fn(lang, "expiry_warning_1d", tier=tier)
        if days <= 3: return t_fn(lang, "expiry_warning_3d", tier=tier, days=days)
    except Exception as _e:
        import logging as _l; _l.error(f"[expiry_check] {_e}")
    return ""

def _get_consumer(phone: str, mod) -> dict:
    """Load consumer record, return {} on any failure."""
    try:
        return mod("shared.db").get_consumer(phone) or {}
    except Exception:
        return {}

def _get_trader_record(phone: str) -> dict:
    """Load trader record from Traders_register."""
    try:
        import os, pymssql
        conn = pymssql.connect(
            server   = os.environ["SQL_SERVER"],
            user     = os.environ.get("SQL_USERNAME") or os.environ.get("SQL_USER"),
            password = os.environ["SQL_PASSWORD"],
            database = os.environ.get("SQL_DATABASE", "naijafoodmarket-live"),
            timeout  = 10, as_dict = True,
        )
        cur = conn.cursor()
        cur.execute(
            "SELECT trader_id, registration_status, is_suspended "
            "FROM dbo.Traders_register WHERE phone_number = %s", (phone,)
        )
        row = cur.fetchone()
        conn.close()
        return row or {}
    except Exception:
        return {}
