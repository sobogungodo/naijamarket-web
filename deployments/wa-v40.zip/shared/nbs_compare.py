import logging
from shared.db import get_connection

def get_nbs_comparison(item_name: str, market_price: float, lang: str="en") -> str:
    """
    Returns a one-line NBS vs market comparison string, or empty string if no NBS data.
    Matches by stripping common suffixes from item_name to find NBS base name.
    """
    try:
        if not item_name or not market_price: return ""
        # Strip unit suffixes to get base commodity name
        base = item_name
        for suffix in [" (per kg)"," (100kg)"," (50kg)"," (per bag)"," (per litre)",
                       " - Fresh"," - Dried"," (carton)"," (basket)"," (bunch)"]:
            base = base.replace(suffix,"")
        base = base.strip()
        if len(base) < 3: return ""
        conn=get_connection(); cur=conn.cursor()
        cur.execute(
            "SELECT AVG(price_naira) AS nbs_avg FROM dbo.Latest_Prices_Summary "
            "WHERE item_name LIKE %s AND is_nbs_ref=1",
            (f"{base} (NBS%",))
        row=cur.fetchone(); conn.close()
        if not row or not row.get("nbs_avg"): return ""
        nbs_avg=float(row["nbs_avg"])
        if nbs_avg<=0: return ""
        premium=((market_price-nbs_avg)/nbs_avg)*100
        if abs(premium)<1: return ""  # within 1% — not noteworthy
        if lang=="pcm":
            if premium>0:
                return f"\n\U0001f4ca _NBS reference: \u20a6{nbs_avg:,.0f}/kg. Market dey *{abs(premium):.0f}% above* official price._"
            return f"\n\U0001f4ca _NBS reference: \u20a6{nbs_avg:,.0f}/kg. Market dey *{abs(premium):.0f}% below* official price._"
        if premium>0:
            return f"\n\U0001f4ca _NBS ref: \u20a6{nbs_avg:,.0f}/kg | Market is *{abs(premium):.0f}% above* official benchmark._"
        return f"\n\U0001f4ca _NBS ref: \u20a6{nbs_avg:,.0f}/kg | Market is *{abs(premium):.0f}% below* official benchmark._"
    except Exception as e:
        logging.warning(f"[nbs_compare] {e}")
        return ""
