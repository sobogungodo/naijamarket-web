import logging
from shared.db import get_connection
from shared.sender import send_message
from shared.session import save_session, clear_session
from shared.lang import get_lang
from shared.i18n import t
from consumer.menu import show_main_menu
from shared.nudge import get_nudge

def handle_compare(phone, message="", session=None, consumer=None, *args):
    session=session or {}; consumer=consumer or {}
    lang=get_lang(session,consumer); text=(message or "").strip(); msg=text.lower()
    step=session.get("step",0)
    if msg in ("0","menu","back"): clear_session(phone); show_main_menu(phone); return
    if step==0:
        session.update({"_flow":"COMPARE","step":1}); save_session(phone,session)
        send_message(phone,t(lang,"compare_title"))
    elif step==1: _show(phone,text,lang,session)
    elif step==99: _handle_repeat_search(phone,text,session,lang,consumer)

def _show(phone,query,lang,session):
    try:
        conn=get_connection(); cur=conn.cursor()
        cur.execute("SELECT TOP 1 item_name FROM dbo.Latest_Prices_Summary WHERE item_name LIKE %s AND is_nbs_ref=0 AND is_food=1 GROUP BY item_name ORDER BY item_name",(f"%{query}%",))
        row=cur.fetchone()
        if not row: conn.close(); send_message(phone,t(lang,"not_found",q=query)); return
        item_name=row["item_name"]
        cur.execute("SELECT state,AVG(price_naira) AS avg_p,COUNT(DISTINCT market_id) AS mkts FROM dbo.Latest_Prices_Summary WHERE item_name=%s AND is_nbs_ref=0 AND is_food=1 AND price_naira>0 GROUP BY state ORDER BY avg_p ASC",(item_name,))
        rows=cur.fetchall(); conn.close()
        if not rows: send_message(phone,t(lang,"error_generic")); return
        nat=sum(float(r["avg_p"]) for r in rows)/len(rows)
        lines="\n".join(("\U0001f534" if float(r["avg_p"])>nat*1.05 else ("\U0001f7e2" if float(r["avg_p"])<nat*0.95 else "\U0001f7e1"))+f" {r['state']}: *\u20a6{float(r['avg_p']):,.0f}* ({r['mkts']} mkts)" for r in rows[:10])
        session.update({"step":99,"_last_query":query}); save_session(phone,session)
        from shared.freshness import freshness_note
        freshness_note_str=freshness_note(None,lang)
        _repeat="\n\n━━━━━━━━━━━━━━━━━━━━━━\n*1* — Search again\n*0* — Menu"
        send_message(phone,t(lang,"compare_result",item=item_name,avg=nat,lines=lines)+freshness_note_str+_repeat+get_nudge(lang,"COMPARE"))
    except Exception as e:
        logging.error(f"[compare] {e}")
        session["step"] = 1; save_session(phone, session)
        send_message(phone, t(lang, "error_retry_search"))

def _handle_repeat_search(phone,text,session,lang,consumer):
    msg=text.strip().lower()
    if msg in ("0","menu","back"): clear_session(phone); show_main_menu(phone); return
    if msg=="1" or msg=="compare":
        session["step"]=0; save_session(phone,session)
        handle_compare(phone,"",session,consumer); return
    _show(phone,text,lang,session)
