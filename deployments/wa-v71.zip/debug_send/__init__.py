import azure.functions as func
import os, requests, json

def main(req: func.HttpRequest) -> func.HttpResponse:
    token    = os.environ.get("META_ACCESS_TOKEN","MISSING")
    phone_id = os.environ.get("META_PHONE_NUMBER_ID","MISSING")
    to       = req.params.get("to","358417203868")
    r = requests.post(
        f"https://graph.facebook.com/v25.0/{phone_id}/messages",
        headers={"Authorization":f"Bearer {token}","Content-Type":"application/json"},
        json={"messaging_product":"whatsapp","to":to,"type":"text","text":{"body":"debug test"}},
        timeout=10
    )
    return func.HttpResponse(json.dumps({
        "phone_id": phone_id,
        "token_prefix": token[:20],
        "status": r.status_code,
        "response": r.text[:500]
    }), mimetype="application/json")
