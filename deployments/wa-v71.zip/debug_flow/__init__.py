import azure.functions as func
import os, json

def main(req: func.HttpRequest) -> func.HttpResponse:
    results = {}
    phone = req.params.get("to", "358417203868")
    
    try:
        from shared.session import get_session
        session = get_session(phone)
        results["session"] = f"OK: {str(session)[:50]}"
    except Exception as e:
        results["session"] = f"FAIL: {str(e)}"

    try:
        from shared.db import get_consumer
        consumer = get_consumer(phone)
        results["consumer"] = f"OK: {str(consumer)[:50]}"
    except Exception as e:
        results["consumer"] = f"FAIL: {str(e)}"

    try:
        from shared.sender import send_message
        send_message(phone, f"Full flow test OK — session={results['session'][:20]}")
        results["send"] = "OK"
    except Exception as e:
        results["send"] = f"FAIL: {str(e)}"

    return func.HttpResponse(json.dumps(results, indent=2), mimetype="application/json")
