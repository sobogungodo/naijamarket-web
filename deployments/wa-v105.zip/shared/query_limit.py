"""
shared/query_limit.py — Query limit enforcement for all consumer tiers
Called before dispatching any price query in the WA engine.

Limits (from Subscription_Tiers):
  FREE       5/week
  SILVER    10/day
  GOLD      25/day
  BUSINESS 100/day
  CORPORATE  unlimited
  ENTERPRISE unlimited
"""
import logging
from datetime import datetime, timezone
from shared.db import get_connection

UNLIMITED = -1

def check_query_limit(phone: str, consumer: dict) -> tuple[bool, str]:
    """
    Returns (allowed, message).
    allowed=True  → query can proceed
    allowed=False → message explains the limit and how to upgrade
    """
    tier = (consumer.get("subscription_tier") or "FREE").upper()

    try:
        conn = get_connection()
        cur  = conn.cursor(as_dict=True)

        # Get limit from Subscription_Tiers
        cur.execute(
            "SELECT query_limit, query_period FROM dbo.Subscription_Tiers WHERE tier_id = %s",
            (tier,)
        )
        row = cur.fetchone()
        if not row:
            conn.close()
            return True, ""

        limit  = row["query_limit"]
        period = (row["query_period"] or "DAY").upper()

        # Unlimited tiers
        if limit == UNLIMITED:
            conn.close()
            return True, ""

        # Count queries in current period
        today = datetime.now(timezone.utc).date()
        clean = phone.replace("+", "").strip()

        if period == "WEEK":
            # Count from Monday of current week
            monday = today.toordinal() - today.weekday()
            from datetime import date
            week_start = date.fromordinal(monday).isoformat()
            cur.execute("""
                SELECT COUNT(*) as cnt FROM dbo.Query_Log
                WHERE consumer_phone = %s
                  AND query_date >= %s
                  AND counted_against_limit = 'Y'
            """, (clean, week_start))
        else:
            # DAY — count today
            cur.execute("""
                SELECT COUNT(*) as cnt FROM dbo.Query_Log
                WHERE consumer_phone = %s
                  AND query_date = %s
                  AND counted_against_limit = 'Y'
            """, (clean, today.isoformat()))

        row2  = cur.fetchone()
        count = row2.get("cnt", 0) if isinstance(row2, dict) else row2[0]
        conn.close()

        remaining = limit - count

        if remaining <= 0:
            if period == "WEEK":
                msg = (
                    f"You've used your {limit} free price checks this week.\n\n"
                    f"SILVER — ₦500/week unlocks:\n"
                    f"✅ 10 price checks/day\n"
                    f"✅ Price alerts on any item\n"
                    f"✅ Weekly price forecast\n"
                    f"✅ Best market finder\n\n"
                    f"Most users save more than ₦500/week by buying at the right market.\n\n"
                    f"Type *upgrade* to subscribe now."
                )
            else:
                msg = (
                    f"You have reached your *{limit} query limit* for today ({tier} plan).\n\n"
                    f"Upgrade for more queries.\n\n"
                    f"Type *upgrade* to see plans or *menu* to go back."
                )
            return False, msg

        # Warn when 1 remaining
        if remaining == 1:
            logging.info(f"[query_limit] {phone} tier={tier} 1 query remaining")

        return True, ""

    except Exception as e:
        logging.error(f"[query_limit] check FAILED — failing open: {type(e).__name__}: {e}", exc_info=True)
        return True, ""  # Fail open — never block on DB error


def log_query(phone: str, consumer: dict, item_name: str = "", market_name: str = ""):
    """Write a row to Query_Log after a successful price result."""
    try:
        clean = phone.replace("+", "").strip()
        tier  = (consumer.get("subscription_tier") or "FREE").upper()
        today = datetime.now(timezone.utc).date().isoformat()
        import uuid
        conn = get_connection()
        cur  = conn.cursor()
        cur.execute("""
            INSERT INTO dbo.Query_Log (
                query_id, consumer_phone, subscription_tier,
                item_name, market_name,
                query_source, query_type,
                query_timestamp, query_date,
                counted_against_limit, created_at
            ) VALUES (
                %s, %s, %s,
                %s, %s,
                'WHATSAPP', 'PRICE',
                GETUTCDATE(), %s,
                'Y', GETUTCDATE()
            )
        """, (
            str(uuid.uuid4()), clean, tier,
            item_name[:100] if item_name else "",
            market_name[:100] if market_name else "",
            today
        ))
        # Increment total_queries and set last_query_date on Consumers
        try:
            cur.execute("""
                UPDATE dbo.Consumers
                SET total_queries = ISNULL(total_queries,0) + 1,
                    last_query_date = CAST(GETUTCDATE() AS date)
                WHERE phone = %s OR phone_number = %s OR phone = %s OR phone_number = %s
            """, (clean, clean, f"+{clean}", f"+{clean}"))
        except Exception as _ue:
            logging.warning(f"[query_limit] total_queries update failed: {_ue}")
        conn.commit()
        conn.close()
    except Exception as e:
        logging.warning(f"[query_limit] log_query silently failed: {e}")


def remaining_queries(phone: str, consumer: dict) -> str:
    """Returns a human-readable string of remaining queries. Used for status display."""
    tier = (consumer.get("subscription_tier") or "FREE").upper()
    try:
        conn = get_connection()
        cur  = conn.cursor()
        cur.execute(
            "SELECT query_limit, query_period FROM dbo.Subscription_Tiers WHERE tier_id = %s",
            (tier,)
        )
        row = cur.fetchone()
        if not row:
            conn.close()
            return ""
        limit  = row["query_limit"]
        period = (row["query_period"] or "DAY").upper()
        if limit == UNLIMITED:
            conn.close()
            return "Unlimited queries"
        today = datetime.now(timezone.utc).date()
        clean = phone.replace("+", "").strip()
        if period == "WEEK":
            from datetime import date
            monday = today.toordinal() - today.weekday()
            week_start = date.fromordinal(monday).isoformat()
            cur.execute("""
                SELECT COUNT(*) as cnt FROM dbo.Query_Log
                WHERE consumer_phone = %s AND query_date >= %s
                  AND counted_against_limit = 'Y'
            """, (clean, week_start))
        else:
            cur.execute("""
                SELECT COUNT(*) as cnt FROM dbo.Query_Log
                WHERE consumer_phone = %s AND query_date = %s
                  AND counted_against_limit = 'Y'
            """, (clean, today.isoformat()))
        row2  = cur.fetchone()
        count = row2.get("cnt", 0) if isinstance(row2, dict) else row2[0]
        conn.close()
        remaining = max(0, limit - count)
        period_label = "this week" if period == "WEEK" else "today"
        return f"{remaining}/{limit} queries left {period_label}"
    except Exception as e:
        logging.error(f"[query_limit] remaining_queries failed: {e}")
        return ""


def get_value_nudge(phone: str, consumer: dict, lang: str) -> str:
    """Return a milestone value message every 5 queries, else empty string."""
    try:
        total = int(consumer.get("total_queries") or 0)
        if total > 0 and total % 10 == 0:
            if lang=="pcm":
                return f"\n\n\U0001f4ca _You don make *{total}* price check! Share NaijaMarket Intel with your people — type *invite* to get your referral code._"
            return f"\n\n\U0001f4ca _You've made *{total}* price checks! Know a trader who'd benefit? Type *invite* to share your referral code._"
        if total > 0 and total % 5 == 0:
            tier = (consumer.get("subscription_tier") or "FREE").upper()
            if lang == "pcm":
                return f"\n\n📊 _You don make *{total}* price check so far on NaijaMarket Intel. {tier} plan dey work for you!_"
            return f"\n\n📊 _You've made *{total}* price checks on NaijaMarket Intel. Keep saving smarter!_"
    except Exception as _e:
        logging.warning(f"[query_limit] get_value_nudge: {_e}")
    return ""
