import logging
from shared.db import get_connection
from shared.sender import send_template_message


def run_trader_notifications() -> dict:
    """Called by a scraper timer to send pending onboarding nudges."""
    results = {"welcome": 0, "first_sub": 0, "reengage": 0}
    try:
        results["welcome"]   = _send_welcome()
        results["first_sub"] = _send_first_sub()
        results["reengage"]  = _send_reengage()
    except Exception as e:
        logging.error(f"[notifications.run] {e}")
    return results


def _send_welcome() -> int:
    sent = 0
    try:
        conn = get_connection()
        cur  = conn.cursor()
        cur.execute("""
            SELECT trader_id, phone, first_name
            FROM dbo.Traders_register
            WHERE welcome_sent = 0 AND status = 'APPROVED'
        """)
        rows = cur.fetchall()
        conn.close()
        for t in rows:
            first = (t["first_name"] or "Trader").split()[0]
            ok, _ = send_template_message(
                t["phone"],
                "naijamarket_trader_welcome",
                body_params=[first, "your market"]
            )
            if ok:
                sent += 1
                _flag(t["trader_id"], "welcome")
    except Exception as e:
        logging.error(f"[notifications._welcome] {e}")
        try: conn.close()
        except: pass
    return sent


def _send_first_sub() -> int:
    sent = 0
    try:
        conn = get_connection()
        cur  = conn.cursor()
        cur.execute("""
            SELECT t.trader_id, t.phone, t.first_name
            FROM dbo.Traders_register t
            WHERE t.first_sub_nudge_sent = 0
              AND t.status = 'APPROVED'
              AND t.welcome_sent = 1
              AND NOT EXISTS (
                  SELECT 1 FROM dbo.Submissions s
                  WHERE s.trader_phone = t.phone
              )
        """)
        rows = cur.fetchall()
        conn.close()
        for t in rows:
            first = (t["first_name"] or "Trader").split()[0]
            ok, _ = send_template_message(
                t["phone"],
                "naijamarket_trader_first_sub",
                body_params=[first]
            )
            if ok:
                sent += 1
                _flag(t["trader_id"], "first_sub")
    except Exception as e:
        logging.error(f"[notifications._first_sub] {e}")
        try: conn.close()
        except: pass
    return sent


def _send_reengage() -> int:
    sent = 0
    try:
        conn = get_connection()
        cur  = conn.cursor()
        cur.execute("""
            SELECT t.trader_id, t.phone, t.first_name, t.market_name,
                   COUNT(s.submission_id) as sub_count
            FROM dbo.Traders_register t
            LEFT JOIN dbo.Submissions s ON s.trader_phone = t.phone
            WHERE t.status = 'APPROVED'
              AND (t.reengage_sent_at IS NULL
                   OR t.reengage_sent_at < DATEADD(DAY, -30, GETUTCDATE()))
              AND t.last_active < DATEADD(DAY, -7, GETUTCDATE())
            GROUP BY t.trader_id, t.phone, t.first_name, t.market_name, t.reengage_sent_at, t.last_active
        """)
        rows = cur.fetchall()
        conn.close()
        for t in rows:
            first     = (t["first_name"] or "Trader").split()[0]
            market    = t["market_name"] or "your market"
            sub_count = str(t["sub_count"] or 0)
            ok, _ = send_template_message(
                t["phone"],
                "_naijamarket_trader_reengage",
                body_params=[first, market, sub_count]
            )
            if ok:
                sent += 1
                _flag(t["trader_id"], "reengage")
    except Exception as e:
        logging.error(f"[notifications._reengage] {e}")
        try: conn.close()
        except: pass
    return sent


def _flag(trader_id: str, nudge: str) -> None:
    try:
        conn = get_connection()
        cur  = conn.cursor()
        if nudge == "welcome":
            cur.execute(
                "UPDATE dbo.Traders_register SET welcome_sent=1 WHERE trader_id=%s",
                (trader_id,)
            )
        elif nudge == "first_sub":
            cur.execute(
                "UPDATE dbo.Traders_register SET first_sub_nudge_sent=1 WHERE trader_id=%s",
                (trader_id,)
            )
        else:
            cur.execute(
                "UPDATE dbo.Traders_register SET reengage_sent_at=GETUTCDATE() WHERE trader_id=%s",
                (trader_id,)
            )
        conn.commit()
        conn.close()
    except Exception as e:
        logging.error(f"[notifications._flag] {e}")
