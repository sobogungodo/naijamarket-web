"""
news_intelligence_scraper — NaijaMarket Intel
Timer: every 4 hours. Scrapes RSS feeds → News_Events table.
Schema confirmed 2026-06-05.
"""
import azure.functions as func
import logging, os, sys, json, requests
import xml.etree.ElementTree as ET
from datetime import datetime, timezone, timedelta

sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))
from shared.db import get_connection

RSS_SOURCES = [
    {"name": "Punch",        "url": "https://punchng.com/feed/"},
    {"name": "BusinessDay",  "url": "https://businessday.ng/feed/"},
    {"name": "PremiumTimes", "url": "https://www.premiumtimesng.com/feed"},
    {"name": "Nairametrics", "url": "https://nairametrics.com/feed/"},
    {"name": "Vanguard",     "url": "https://www.vanguardngr.com/feed/"},
    {"name": "Guardian",     "url": "https://guardian.ng/feed/"},
]
FOOD_KEYWORDS = ["rice","tomato","yam","cassava","maize","corn","beans","pepper",
    "palm oil","vegetable oil","onion","fish","chicken","beef","wheat","flour",
    "bread","sugar","salt","garri","sorghum","millet","groundnut","soybean",
    "food","commodity","market","price","inflation","harvest","drought","flood",
    "import","export","tariff","agriculture","farmer","crop","supply","shortage",
    "smuggling","ban","waiver","subsidy","fertiliser","livestock","poultry"]
CLUSTER_RULES = [
    ("WEATHER_FLOOD",     ["flood","rain","rainfall","storm","waterlog"]),
    ("WEATHER_DROUGHT",   ["drought","dry season","water stress","heat"]),
    ("SUPPLY_DISRUPTION", ["shortage","scarcity","unavailable","stockout","disruption"]),
    ("TRANSPORT_COST",    ["transport","logistics","fuel","diesel","truck","road"]),
    ("GOVT_POLICY",       ["ban","waiver","tariff","subsidy","policy","government",
                           "minister","customs","nafdac","fmard","regulation"]),
    ("HARVEST_SEASON",    ["harvest","planting","season","crop yield","bumper"]),
    ("PRICE_SURGE",       ["surge","spike","soar","jump","rise","increase","hike"]),
    ("PRICE_DROP",        ["drop","fall","decline","cheap","decrease","plunge"]),
    ("FOREX_IMPACT",      ["naira","dollar","exchange rate","forex","devaluation"]),
    ("SECURITY",          ["bandits","kidnap","attack","insecurity","boko haram"]),
]
DIRECTION_MAP  = {"WEATHER_FLOOD":"UP","WEATHER_DROUGHT":"UP","SUPPLY_DISRUPTION":"UP",
    "TRANSPORT_COST":"UP","GOVT_POLICY":"NEUTRAL","HARVEST_SEASON":"DOWN",
    "PRICE_SURGE":"UP","PRICE_DROP":"DOWN","FOREX_IMPACT":"UP","SECURITY":"UP"}
VOLATILITY_MAP = {"WEATHER_FLOOD":8,"WEATHER_DROUGHT":7,"SUPPLY_DISRUPTION":9,
    "TRANSPORT_COST":5,"GOVT_POLICY":7,"HARVEST_SEASON":6,"PRICE_SURGE":8,
    "PRICE_DROP":6,"FOREX_IMPACT":7,"SECURITY":8}

def is_food_relevant(text):
    t = text.lower()
    return any(k in t for k in FOOD_KEYWORDS)

def classify_cluster(text):
    t = text.lower()
    for cluster, keywords in CLUSTER_RULES:
        if any(k in t for k in keywords):
            return cluster
    return "GENERAL_FOOD_NEWS"

def fetch_rss(source):
    try:
        resp = requests.get(source["url"], timeout=10,
                            headers={"User-Agent": "NaijaMarketIntel/1.0"})
        if resp.status_code != 200:
            return []
        root = ET.fromstring(resp.content)
        items = []
        for item in root.findall(".//item"):
            t = item.find("title"); l = item.find("link")
            if t is not None and l is not None:
                h = (t.text or "").strip(); u = (l.text or "").strip()
                if h and u:
                    items.append({"url": u, "headline": h})
        return items
    except Exception as e:
        logging.warning("[news_scraper] %s failed: %s", source["name"], e)
        return []

def url_exists(conn, url):
    cur = conn.cursor()
    cur.execute("SELECT COUNT(*) FROM dbo.News_Events WHERE article_url=%s", (url,))
    c = cur.fetchone()[0]; cur.close(); return c > 0

def insert_event(conn, article, source_name):
    h = article["headline"]; u = article["url"]
    if not is_food_relevant(h) or url_exists(conn, u):
        return False
    cluster = classify_cluster(h)
    cur = conn.cursor()
    cur.execute("""
        INSERT INTO dbo.News_Events
        (article_url,headline,source_name,scraped_at,event_cluster,direction,
         volatility_score,affected_commodities,affected_markets,is_emergency,
         expires_at,consumer_summary,is_active)
        VALUES(%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)
    """, (u[:500],h[:500],source_name[:100],datetime.now(timezone.utc),
          cluster,DIRECTION_MAP.get(cluster,"NEUTRAL"),VOLATILITY_MAP.get(cluster,3),
          None,None,0,datetime.now(timezone.utc)+timedelta(days=30),
          f"{h[:200]} — {source_name}."[:500],1))
    conn.commit(); cur.close(); return True

def main(myTimer: func.TimerRequest) -> None:
    logging.info("[news_intelligence_scraper] START")
    if myTimer.past_due:
        logging.warning("[news_intelligence_scraper] past due")
    conn = None
    stats = {"fetched": 0, "inserted": 0, "errors": 0}
    try:
        conn = get_connection()
        for source in RSS_SOURCES:
            articles = fetch_rss(source)
            stats["fetched"] += len(articles)
            for a in articles:
                try:
                    if insert_event(conn, a, source["name"]):
                        stats["inserted"] += 1
                except Exception as e:
                    stats["errors"] += 1
                    logging.error("[news_scraper] insert error: %s", e)
    except Exception as e:
        logging.error("[news_intelligence_scraper] FATAL: %s", e); raise
    finally:
        if conn:
            try: conn.close()
            except: pass
    logging.info("[news_intelligence_scraper] DONE fetched=%d inserted=%d errors=%d",
                 stats["fetched"],stats["inserted"],stats["errors"])
