"""generate_morning_prices — timer trigger 07:30 UTC (08:30 WAT)
Calls sp_Generate_Daily_Prices then usp_Refresh_LatestPrices.
"""
import azure.functions as func, logging, os, sys
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))
from shared.db import get_connection

def main(myTimer: func.TimerRequest) -> None:
    if myTimer.past_due:
        logging.warning("[generate_morning_prices] past due")
    logging.info("[generate_morning_prices] START slot=08")
    conn = None
    try:
        conn = get_connection()
        cur = conn.cursor()
        cur.callproc('sp_Generate_Daily_Prices', ('08', None))
        conn.commit(); cur.close()
        logging.info("[generate_morning_prices] generation done")
        cur2 = conn.cursor()
        cur2.callproc('usp_Refresh_LatestPrices')
        conn.commit(); cur2.close()
        logging.info("[generate_morning_prices] refresh done")
    except Exception as e:
        logging.error("[generate_morning_prices] ERROR: %s", str(e)); raise
    finally:
        if conn:
            try: conn.close()
            except: pass
