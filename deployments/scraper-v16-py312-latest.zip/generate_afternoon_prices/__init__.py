"""generate_afternoon_prices — timer trigger 13:30 UTC (14:30 WAT)
Calls sp_Generate_Daily_Prices then usp_Refresh_LatestPrices.
"""
import azure.functions as func, logging, os, sys
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))
from shared.db import get_connection

def main(myTimer: func.TimerRequest) -> None:
    if myTimer.past_due:
        logging.warning("[generate_afternoon_prices] past due")
    logging.info("[generate_afternoon_prices] START slot=14")
    conn = None
    try:
        conn = get_connection()
        cur = conn.cursor()
        cur.callproc('sp_Generate_Daily_Prices', ('14', None))
        conn.commit(); cur.close()
        logging.info("[generate_afternoon_prices] generation done")
        cur2 = conn.cursor()
        cur2.callproc('usp_Refresh_LatestPrices')
        conn.commit(); cur2.close()
        logging.info("[generate_afternoon_prices] refresh done")
    except Exception as e:
        logging.error("[generate_afternoon_prices] ERROR: %s", str(e)); raise
    finally:
        if conn:
            try: conn.close()
            except: pass
