"""
vtpass_rewards — NaijaMarket Intel
Timer: every 30 minutes.
Pays ₦200 airtime to traders per approved submission.
Pays ₦100 airtime to validators per consensus vote.
VTPASS_ENABLED=false → logs PENDING without disbursing.
Synthetic traders/validators (SYN-*) are always excluded.
Schema confirmed 2026-06-05.
"""
import azure.functions as func
import logging, os, sys, uuid, requests
from datetime import datetime, timezone
from decimal import Decimal

sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))
from shared.db import get_connection

TRADER_REWARD    = Decimal('200.00')
VALIDATOR_REWARD = Decimal('100.00')
VTPASS_ENABLED   = os.environ.get('VTPASS_ENABLED','false').lower() == 'true'
VTPASS_API_KEY   = os.environ.get('VTPASS_API_KEY','')
VTPASS_SECRET    = os.environ.get('VTPASS_SECRET_KEY','')
VTPASS_PK        = os.environ.get('VTPASS_PUBLIC_KEY','')
VTPASS_BASE_URL  = 'https://vtpass.com/api'
BATCH_SIZE       = 30

def make_txn_id():
    return f"TXN{datetime.now(timezone.utc).strftime('%Y%m%d%H%M%S')}{uuid.uuid4().hex[:6].upper()}"

def strip_phone(phone):
    phone = str(phone).strip().replace(' ','').replace('+','')
    if phone.startswith('234') and len(phone)==13:
        phone = '0' + phone[3:]
    if not phone.startswith('0'):
        phone = '0' + phone
    return phone[:11]

NETWORK_MAP = {
    '0803':'mtn','0806':'mtn','0813':'mtn','0816':'mtn','0810':'mtn',
    '0814':'mtn','0903':'mtn','0906':'mtn','0805':'glo','0807':'glo',
    '0815':'glo','0811':'glo','0905':'glo','0802':'airtel','0808':'airtel',
    '0812':'airtel','0701':'airtel','0708':'airtel','0902':'airtel',
    '0809':'9mobile','0818':'9mobile','0817':'9mobile','0909':'9mobile',
}
SVC_MAP = {'mtn':'mtn','airtel':'airtel','glo':'glo','9mobile':'etisalat'}

def call_vtpass(phone, amount):
    if not VTPASS_ENABLED:
        return {'success':False,'vtpass_ref':None,'error':'VTPASS_ENABLED=false'}
    if not VTPASS_API_KEY:
        return {'success':False,'vtpass_ref':None,'error':'No credentials'}
    network = NETWORK_MAP.get(phone[:4],'mtn')
    req_id = make_txn_id()
    try:
        resp = requests.post(f'{VTPASS_BASE_URL}/pay',
            json={'request_id':req_id,'serviceID':SVC_MAP.get(network,'mtn'),
                  'amount':int(amount),'phone':phone},
            headers={'api-key':VTPASS_API_KEY,'secret-key':VTPASS_SECRET,
                     'public-key':VTPASS_PK,'Content-Type':'application/json'},
            timeout=30)
        data = resp.json()
        if str(data.get('code','')) == '000':
            return {'success':True,'vtpass_ref':data.get('content',{}).get(
                'transactions',{}).get('transactionId',req_id),'error':None}
        return {'success':False,'vtpass_ref':req_id,
                'error':data.get('response_description',str(data))}
    except Exception as e:
        return {'success':False,'vtpass_ref':None,'error':str(e)}

def already_rewarded(conn, ref_id, txn_type, user_id=None):
    cur = conn.cursor()
    if user_id:
        cur.execute("""SELECT COUNT(*) FROM dbo.Rewards_Ledger
            WHERE reference_id=%s AND transaction_type=%s AND user_id=%s
            AND status IN ('COMPLETED','PENDING')""", (ref_id,txn_type,user_id))
    else:
        cur.execute("""SELECT COUNT(*) FROM dbo.Rewards_Ledger
            WHERE reference_id=%s AND transaction_type=%s
            AND status IN ('COMPLETED','PENDING')""", (ref_id,txn_type))
    c = cur.fetchone()[0]; cur.close(); return c > 0

def log_reward(conn, phone, user_id, user_type, txn_type, amount,
               ref_id, desc, result, balance_after):
    status = 'COMPLETED' if result['success'] else ('PENDING' if not VTPASS_ENABLED else 'FAILED')
    cur = conn.cursor()
    cur.execute("""
        INSERT INTO dbo.Rewards_Ledger
        (transaction_id,timestamp,phone_number,transaction_type,amount,fee,
         net_amount,status,payout_batch_id,description,user_type,user_id,
         reference_id,balance_after)
        VALUES(%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)
    """, (make_txn_id(),datetime.now(timezone.utc),phone,txn_type,
          float(amount),0.0,float(amount),status,None,
          f"{desc} | ref={result.get('vtpass_ref','')}"[:500],
          user_type,user_id,ref_id,float(balance_after)))
    conn.commit(); cur.close()

def process_traders(conn):
    stats = {'found':0,'paid':0,'pending':0,'failed':0,'skipped':0}
    cur = conn.cursor(as_dict=True)
    cur.execute("""
        SELECT TOP %d s.submission_id,s.trader_phone,s.trader_id,s.item,s.market
        FROM dbo.Submissions s
        WHERE s.validation_status='APPROVED' AND s.fraud_flag=0
          AND s.trader_id NOT LIKE 'SYN-%%'
          AND s.trader_phone NOT LIKE '+23480090%%'
          AND NOT EXISTS (
              SELECT 1 FROM dbo.Rewards_Ledger r
              WHERE r.reference_id=s.submission_id
              AND r.transaction_type='SUBMISSION_REWARD'
              AND r.status IN ('COMPLETED','PENDING'))
        ORDER BY s.approved_at DESC
    """ % BATCH_SIZE)
    rows = cur.fetchall(); cur.close()
    stats['found'] = len(rows)
    for sub in rows:
        try:
            phone_raw = str(sub['trader_phone'] or '').strip()
            if not phone_raw or phone_raw=='None':
                stats['skipped']+=1; continue
            phone = strip_phone(phone_raw)
            if len(phone) < 11:
                stats['skipped']+=1; continue
            result = call_vtpass(phone, TRADER_REWARD)
            log_reward(conn,phone,sub['trader_id'] or phone,'TRADER',
                      'SUBMISSION_REWARD',TRADER_REWARD,sub['submission_id'],
                      f"Submission: {sub['item']} at {sub['market']}",result,Decimal('0'))
            if result['success']: stats['paid']+=1
            elif not VTPASS_ENABLED: stats['pending']+=1
            else: stats['failed']+=1
        except Exception as e:
            stats['failed']+=1
            logging.error("[vtpass_rewards] trader error %s: %s", sub.get('submission_id','?'), e)
    return stats

def process_validators(conn):
    stats = {'found':0,'paid':0,'pending':0,'failed':0,'skipped':0}
    cur = conn.cursor(as_dict=True)
    cur.execute("""
        SELECT TOP %d s.submission_id,s.validator_1,s.vote_1,s.validator_2,
               s.vote_2,s.validator_3,s.vote_3,s.consensus_result
        FROM dbo.Submissions s
        WHERE s.validation_status IN ('APPROVED','REJECTED')
          AND s.consensus_result IS NOT NULL
          AND s.trader_id NOT LIKE 'SYN-%%'
        ORDER BY s.approved_at DESC
    """ % BATCH_SIZE)
    rows = cur.fetchall(); cur.close()
    stats['found'] = len(rows)
    for sub in rows:
        consensus = sub['consensus_result']
        for i in range(1,4):
            val_id = sub.get(f'validator_{i}'); vote = sub.get(f'vote_{i}')
            if not val_id or not vote or val_id.startswith('SYN-'): continue
            vote_ok = (consensus=='APPROVED' and vote=='APPROVE') or \
                      (consensus=='REJECTED' and vote=='REJECT')
            if not vote_ok: continue
            if already_rewarded(conn,sub['submission_id'],'VALIDATION_REWARD',val_id):
                stats['skipped']+=1; continue
            try:
                vc = conn.cursor(as_dict=True)
                vc.execute("SELECT phone_number,balance FROM dbo.Validators WHERE validator_id=%s AND status='ACTIVE'",(val_id,))
                vrow = vc.fetchone(); vc.close()
                if not vrow: stats['skipped']+=1; continue
                phone = strip_phone(str(vrow['phone_number']))
                bal = Decimal(str(vrow['balance'] or 0))
                new_bal = bal + VALIDATOR_REWARD
                result = call_vtpass(phone, VALIDATOR_REWARD)
                log_reward(conn,phone,val_id,'VALIDATOR','VALIDATION_REWARD',
                          VALIDATOR_REWARD,sub['submission_id'],
                          f"Vote {vote} consensus={consensus}",result,
                          new_bal if result['success'] else bal)
                if result['success']:
                    uc = conn.cursor()
                    uc.execute("UPDATE dbo.Validators SET balance=%s,total_earned=total_earned+%s,updated_at=%s WHERE validator_id=%s",
                               (float(new_bal),int(VALIDATOR_REWARD),datetime.now(timezone.utc),val_id))
                    conn.commit(); uc.close()
                    stats['paid']+=1
                elif not VTPASS_ENABLED: stats['pending']+=1
                else: stats['failed']+=1
            except Exception as e:
                stats['failed']+=1
                logging.error("[vtpass_rewards] validator error %s: %s", val_id, e)
    return stats

def main(myTimer: func.TimerRequest) -> None:
    logging.info("[vtpass_rewards] START | enabled=%s", VTPASS_ENABLED)
    if myTimer.past_due:
        logging.warning("[vtpass_rewards] past due")
    conn = None
    try:
        conn = get_connection()
        ts = process_traders(conn)
        vs = process_validators(conn)
        logging.info("[vtpass_rewards] DONE | traders: found=%d paid=%d pending=%d failed=%d | validators: found=%d paid=%d pending=%d failed=%d",
            ts['found'],ts['paid'],ts['pending'],ts['failed'],
            vs['found'],vs['paid'],vs['pending'],vs['failed'])
    except Exception as e:
        logging.error("[vtpass_rewards] FATAL: %s", e); raise
    finally:
        if conn:
            try: conn.close()
            except: pass
