"""
price_alert_checker — NaijaMarket Intel
========================================
Timer trigger: every 30 minutes (0 */30 * * * *)
Checks Price_Alerts (status=ACTIVE) against Latest_Prices_Summary.
Delivers triggered alerts via Meta Cloud API WhatsApp.
Logs every delivery attempt to Alert_Notifications.
Updates Price_Alerts status to TRIGGERED on success.
Schema confirmed 2026-06-05.
"""
import azure.functions as func
import logging, os, sys, json, requests
from datetime import datetime, timezone
from decimal import Decimal

sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))
from shared.db import get_connection

META_TOKEN    = os.environ.get("META_ACCESS_TOKEN", "")
META_PHONE_ID = os.environ.get("META_PHONE_NUMBER_ID", "1040415905832961")
META_API_URL  = f"https://graph.facebook.com/v18.0/{META_PHONE_ID}/messages"
BATCH_SIZE    = 50

def format_naira(amount):
    return f"₦{amount:,.2f}"

def build_alert_message(alert, current_price):
    direction = "dropped below" if alert["alert_type"] == "BELOW" else "risen above"
    change_abs = abs(current_price - alert["target_price"])
    change_word = "below" if current_price < alert["target_price"] else "above"
    return (
        f"🔔 *NaijaMarket Intel Price Alert*\n\n"
        f"*{alert['item_name']}*\n"
        f"📍 {alert['market_name']}\n\n"
        f"Current price has {direction} your target:\n"
        f"• Current: *{format_naira(current_price)}*\n"
        f"• Your target: {format_naira(alert['target_price'])}\n"
        f"• {format_naira(change_abs)} {change_word} target\n\n"
        f"📅 {datetime.now(timezone.utc).strftime('%d %b %Y, %H:%M')} UTC\n\n"
        f"Reply *MENU* for more prices or *ALERTS* to manage alerts."
    )

def send_whatsapp(phone_number, message):
    clean_phone = str(phone_number).lstrip("+")
    try:
        resp = requests.post(META_API_URL,
            headers={"Authorization": f"Bearer {META_TOKEN}", "Content-Type": "application/json"},
            json={"messaging_product": "whatsapp", "to": clean_phone,
                  "type": "text", "text": {"body": message, "preview_url": False}},
            timeout=15)
        data = resp.json()
        if resp.status_code == 200 and "messages" in data:
            return {"success": True, "message_id": data["messages"][0].get("id",""), "error": None}
        return {"success": False, "message_id": None, "error": data.get("error",{}).get("message", str(data))}
    except Exception as e:
        return {"success": False, "message_id": None, "error": str(e)}

def main(myTimer: func.TimerRequest) -> None:
    start = datetime.now(timezone.utc)
    logging.info("[price_alert_checker] START %s", start.isoformat())
    if myTimer.past_due:
        logging.warning("[price_alert_checker] past due")
    if not META_TOKEN:
        logging.error("[price_alert_checker] META_ACCESS_TOKEN not set")
        return
    conn = None
    stats = {"checked": 0, "triggered": 0, "sent": 0, "failed": 0, "errors": 0}
    try:
        conn = get_connection()
        cur = conn.cursor(as_dict=True)
        cur.execute("""
            SELECT TOP %d pa.alert_id, pa.phone_number, pa.item_id, pa.item_name,
                pa.market_id, pa.market_name, pa.target_price, pa.alert_type,
                lp.price_naira AS current_price, lp.price_date
            FROM dbo.Price_Alerts pa
            INNER JOIN dbo.Latest_Prices_Summary lp
                ON lp.item_id=pa.item_id AND lp.market_id=pa.market_id
                AND lp.is_nbs_ref=0 AND lp.is_food=1
            WHERE pa.status='ACTIVE'
            ORDER BY pa.created_at ASC
        """ % BATCH_SIZE)
        alerts = cur.fetchall()
        cur.close()
        stats["checked"] = len(alerts)
        for alert in alerts:
            try:
                cp = alert["current_price"]
                t  = alert["target_price"]
                triggered = (alert["alert_type"]=="BELOW" and cp<=t) or \
                            (alert["alert_type"]=="ABOVE" and cp>=t)
                if not triggered:
                    continue
                stats["triggered"] += 1
                result = send_whatsapp(alert["phone_number"], build_alert_message(alert, cp))
                now = datetime.now(timezone.utc)
                status = "SENT" if result["success"] else "FAILED"
                ic = conn.cursor()
                ic.execute("""
                    INSERT INTO dbo.Alert_Notifications
                    (alert_id,phone_number,item_name,market_name,target_price,
                     triggered_price,alert_type,channel,recipient,status,sent_at,
                     error_message,created_at,message_sid,delivery_status,retry_count)
                    VALUES(%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)
                """, (alert["alert_id"],alert["phone_number"],alert["item_name"],
                      alert["market_name"],float(t),float(cp),alert["alert_type"],
                      "WHATSAPP",alert["phone_number"],status,now,
                      result["error"],now,result["message_id"],result["message_id"],0))
                conn.commit(); ic.close()
                if result["success"]:
                    uc = conn.cursor()
                    uc.execute("UPDATE dbo.Price_Alerts SET status='TRIGGERED',triggered_at=%s,updated_at=%s WHERE alert_id=%s",
                               (now, now, alert["alert_id"]))
                    conn.commit(); uc.close()
                    stats["sent"] += 1
                else:
                    stats["failed"] += 1
            except Exception as e:
                stats["errors"] += 1
                logging.error("[price_alert_checker] ERROR %s: %s", alert.get("alert_id","?"), e)
    except Exception as e:
        logging.error("[price_alert_checker] FATAL: %s", e); raise
    finally:
        if conn:
            try: conn.close()
            except: pass
    logging.info("[price_alert_checker] DONE checked=%d triggered=%d sent=%d failed=%d errors=%d",
                 stats["checked"],stats["triggered"],stats["sent"],stats["failed"],stats["errors"])
