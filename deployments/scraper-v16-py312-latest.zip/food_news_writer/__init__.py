"""
food_news_writer — NaijaMarket Intel
Timer: Monday 05:30 UTC. Reads News_Events → writes News_Articles.
Schema confirmed 2026-06-05.
"""
import azure.functions as func
import logging, os, sys, json, re
from datetime import datetime, timezone, timedelta
from collections import defaultdict

sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))
from shared.db import get_connection

CLUSTER_TO_CATEGORY = {
    "WEATHER_FLOOD":"WEATHER","WEATHER_DROUGHT":"WEATHER",
    "SUPPLY_DISRUPTION":"SUPPLY_CHAIN","TRANSPORT_COST":"LOGISTICS",
    "GOVT_POLICY":"GOVT_POLICY","HARVEST_SEASON":"HARVEST",
    "PRICE_SURGE":"PRICE_MOVEMENT","PRICE_DROP":"PRICE_MOVEMENT",
    "FOREX_IMPACT":"FOREX","SECURITY":"SECURITY","GENERAL_FOOD_NEWS":"GENERAL",
}
CLUSTER_LABELS = {
    "WEATHER_FLOOD":"Flood & Rainfall Disruption","WEATHER_DROUGHT":"Drought Pressure",
    "SUPPLY_DISRUPTION":"Supply Chain Disruption","TRANSPORT_COST":"Transport Cost",
    "GOVT_POLICY":"Government Policy","HARVEST_SEASON":"Harvest Activity",
    "PRICE_SURGE":"Price Surge","PRICE_DROP":"Price Decline",
    "FOREX_IMPACT":"Forex Impact","SECURITY":"Security Issues",
    "GENERAL_FOOD_NEWS":"Food Market Update",
}
MIN_VOLATILITY = 4

def slugify(text):
    text = text.lower().strip()
    text = re.sub(r'[^\w\s-]', '', text)
    text = re.sub(r'[\s_-]+', '-', text)
    return text[:120]

def get_week_start():
    today = datetime.now(timezone.utc).date()
    return today - timedelta(days=today.weekday())

def slug_exists(conn, slug):
    cur = conn.cursor()
    cur.execute("SELECT COUNT(*) FROM dbo.News_Articles WHERE slug=%s", (slug,))
    c = cur.fetchone()[0]; cur.close(); return c > 0

def insert_article(conn, a):
    if slug_exists(conn, a["slug"]):
        return False
    cur = conn.cursor()
    cur.execute("""
        INSERT INTO dbo.News_Articles
        (slug,title,summary,source_name,source_url,category,
         affected_commodities,affected_states,published_date,
         week_start,is_published,tier_access,created_at)
        VALUES(%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)
    """, (a["slug"],a["title"],a["summary"],a["source_name"],a["source_url"],
          a["category"],a["affected_commodities"],a["affected_states"],
          a["published_date"],a["week_start"],1,"ALL",datetime.now(timezone.utc)))
    conn.commit(); cur.close(); return True

def main(myTimer: func.TimerRequest) -> None:
    logging.info("[food_news_writer] START")
    if myTimer.past_due:
        logging.warning("[food_news_writer] past due")
    week_start = get_week_start()
    since = datetime.now(timezone.utc) - timedelta(days=7)
    conn = None
    stats = {"events": 0, "written": 0, "skipped": 0}
    try:
        conn = get_connection()
        cur = conn.cursor(as_dict=True)
        cur.execute("""
            SELECT event_id,headline,source_name,scraped_at,event_cluster,
                   direction,volatility_score,affected_commodities,
                   affected_markets,consumer_summary
            FROM dbo.News_Events
            WHERE is_active=1 AND scraped_at>=%s
            ORDER BY volatility_score DESC
        """, (since,))
        events = cur.fetchall(); cur.close()
        stats["events"] = len(events)
        if not events:
            logging.warning("[food_news_writer] No events in past 7 days — skipping")
            return
        groups = defaultdict(lambda: {"events":[],"headlines":[],"sources":set(),
                                       "max_score":0,"direction":"NEUTRAL"})
        for ev in events:
            c = ev["event_cluster"] or "GENERAL_FOOD_NEWS"
            g = groups[c]
            g["events"].append(ev); g["headlines"].append(ev["headline"])
            g["sources"].add(ev["source_name"])
            if ev["volatility_score"] > g["max_score"]:
                g["max_score"] = ev["volatility_score"]
                g["direction"] = ev["direction"] or "NEUTRAL"
        for cluster, group in groups.items():
            if group["max_score"] < MIN_VOLATILITY:
                stats["skipped"] += 1; continue
            label = CLUSTER_LABELS.get(cluster, cluster)
            wlabel = week_start.strftime("%d %B %Y").lstrip("0")
            src = sorted(group["sources"])[0]
            headlines = " ".join(f"{h.rstrip('.')}." for h in group["headlines"][:3])
            article = {
                "slug": slugify(f"{week_start.strftime('%Y-%m-%d')}-{cluster.lower()}"),
                "title": f"Week of {wlabel}: {label} in Nigerian Food Markets"[:399],
                "summary": (f"{len(group['events'])} reports from {src} flagged "
                           f"{label.lower()} this week. {headlines}")[:1990],
                "source_name": src[:100],
                "source_url": "https://naijamarketintel.ng/food-news",
                "category": CLUSTER_TO_CATEGORY.get(cluster, "GENERAL"),
                "affected_commodities": None,
                "affected_states": None,
                "published_date": datetime.now(timezone.utc).date(),
                "week_start": week_start,
            }
            if insert_article(conn, article):
                stats["written"] += 1
                logging.info("[food_news_writer] Written: %s", article["slug"])
            else:
                stats["skipped"] += 1
    except Exception as e:
        logging.error("[food_news_writer] FATAL: %s", e); raise
    finally:
        if conn:
            try: conn.close()
            except: pass
    logging.info("[food_news_writer] DONE events=%d written=%d skipped=%d",
                 stats["events"],stats["written"],stats["skipped"])
