import time
import threading
from typing import Any, Optional

_TTL = {"pg": 60, "digest": 300, "ref": 3600}
_DEFAULT_TTL = 60
_store = {}
_lock  = threading.Lock()

def _ttl_for(ns): return _TTL.get(ns, _DEFAULT_TTL)

def get_cache(namespace, key):
    with _lock:
        ns = _store.get(namespace)
        if not ns: return None
        entry = ns.get(key)
        if not entry: return None
        value, expires_at = entry
        if time.monotonic() > expires_at:
            del ns[key]
            return None
        return value

def set_cache(namespace, key, value, ttl=None):
    ttl = ttl if ttl is not None else _ttl_for(namespace)
    expires_at = time.monotonic() + ttl
    with _lock:
        if namespace not in _store: _store[namespace] = {}
        _store[namespace][key] = (value, expires_at)

def invalidate_cache(namespace, key):
    with _lock:
        ns = _store.get(namespace)
        if ns and key in ns: del ns[key]

def invalidate_namespace(namespace):
    with _lock: _store.pop(namespace, None)
