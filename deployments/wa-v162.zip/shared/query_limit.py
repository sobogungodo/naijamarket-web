"""
shared/query_limit.py — Query limit enforcement for all consumer tiers
Called before dispatching any price query in the WA engine.

Limits (from Subscription_Tiers):
  FREE       3/week
  SILVER    10/day
  GOLD      25/day
  BUSINESS 100/day
  CORPORATE  unlimited
  ENTERPRISE unlimited
"""
import logging
from datetime import datetime, timezone
from shared.db import get_connection

UNLIMITED = -1

def check_query_limit(phone: str, consumer: dict) -> tuple[bool, str]:
    """
    Returns (allowed, message).
    allowed=True  → query can proceed
    allowed=False → message explains the limit and how to upgrade
    """
    tier = (consumer.get("subscription_tier") or "FREE").upper()

    try:
        conn = get_connection()
        cur  = conn.cursor(as_dict=True)

        # Get limit from Subscription_Tiers
        cur.execute(
            "SELECT query_limit, query_period FROM dbo.Subscription_Tiers WHERE tier_id = %s",
            (tier,)
        )
        row = cur.fetchone()
        if not row:
            conn.close()
            return True, ""

        limit  = row["query_limit"]
        period = (row["query_period"] or "DAY").upper()

        # Unlimited tiers
        if limit == UNLIMITED:
            conn.close()
            return True, ""

        # Count queries in current period
        today = datetime.now(timezone.utc).date()
        clean = phone.replace("+", "").strip()
        from datetime import date
        week_start = date.fromordinal(today.toordinal() - today.weekday())  # Monday 00:00 of this week

        if period == "WEEK":
            # FREE tier — single source of truth = Consumers.queries_remaining
            # (shared with the web gate + mobile app). Weekly reset Monday 00:00 UTC.
            cur.execute("""
                SELECT queries_remaining, last_query_date FROM dbo.Consumers
                WHERE REPLACE(phone_number,'+','') = %s OR REPLACE(phone,'+','') = %s
            """, (clean, clean))
            crow = cur.fetchone()
            conn.close()
            if not crow:
                return True, ""  # unknown consumer — fail open
            last = crow.get("last_query_date")
            last_date = last.date() if hasattr(last, "date") else last
            needs_reset = (last_date is None) or (last_date < week_start)
            qr = crow.get("queries_remaining")
            remaining = limit if needs_reset else (qr if qr is not None else limit)
        else:
            # DAY tiers (SILVER/GOLD/BUSINESS) — count today's Query_Log rows
            cur.execute("""
                SELECT COUNT(*) as cnt FROM dbo.Query_Log
                WHERE consumer_phone = %s
                  AND query_date = %s
                  AND counted_against_limit = 'Y'
            """, (clean, today.isoformat()))
            row2  = cur.fetchone()
            count = row2.get("cnt", 0) if isinstance(row2, dict) else row2[0]
            conn.close()
            remaining = limit - count

        if remaining <= 0:
            if period == "WEEK":
                msg = (
                    f"You've used your {limit} free price checks this week.\n\n"
                    f"SILVER — ₦500/week unlocks:\n"
                    f"✅ 10 price checks/day\n"
                    f"✅ Price alerts on any item\n"
                    f"✅ Weekly price forecast\n"
                    f"✅ Best market finder\n\n"
                    f"Most users save more than ₦500/week by buying at the right market.\n\n"
                    f"Type *upgrade* to subscribe now."
                )
            else:
                msg = (
                    f"You have reached your *{limit} query limit* for today ({tier} plan).\n\n"
                    f"Upgrade for more queries.\n\n"
                    f"Type *upgrade* to see plans or *menu* to go back."
                )
            return False, msg

        # Warn when 1 remaining
        if remaining == 1:
            logging.info(f"[query_limit] {phone} tier={tier} 1 query remaining")

        return True, ""

    except Exception as e:
        logging.error(f"[query_limit] check FAILED — failing open: {type(e).__name__}: {e}", exc_info=True)
        return True, ""  # Fail open — never block on DB error


def log_query(phone: str, consumer: dict, item_name: str = "", market_name: str = "", query_type: str = "PRICE"):
    """Write a row to Query_Log after a successful price result."""
    try:
        clean = phone.replace("+", "").strip()
        tier  = (consumer.get("subscription_tier") or "FREE").upper()
        today = datetime.now(timezone.utc).date().isoformat()
        import uuid
        conn = get_connection()
        cur  = conn.cursor()
        cur.execute("""
            INSERT INTO dbo.Query_Log (
                query_id, consumer_phone, subscription_tier,
                item_name, market_name,
                query_source, query_type,
                query_timestamp, query_date,
                counted_against_limit, created_at
            ) VALUES (
                %s, %s, %s,
                %s, %s,
                'WHATSAPP', %s,
                GETUTCDATE(), %s,
                'Y', GETUTCDATE()
            )
        """, (
            str(uuid.uuid4()), clean, tier,
            item_name[:100] if item_name else "",
            market_name[:100] if market_name else "",
            (query_type or "PRICE")[:20],
            today
        ))
        # Update Consumers: total_queries + last_query_date for everyone.
        # FREE tier ALSO decrements the shared queries_remaining counter
        # (weekly-reset-aware), so web/WA/app stay in sync on one source of truth.
        try:
            if tier == "FREE":
                from datetime import date
                _today_d = datetime.now(timezone.utc).date()
                _week_start = date.fromordinal(_today_d.toordinal() - _today_d.weekday())
                cur2 = conn.cursor(as_dict=True)
                cur2.execute("""
                    SELECT queries_remaining, last_query_date FROM dbo.Consumers
                    WHERE REPLACE(phone_number,'+','') = %s OR REPLACE(phone,'+','') = %s
                """, (clean, clean))
                _crow = cur2.fetchone()
                _last = _crow.get("last_query_date") if _crow else None
                _last_d = _last.date() if hasattr(_last, "date") else _last
                _needs_reset = (_last_d is None) or (_last_d < _week_start)
                _qr = _crow.get("queries_remaining") if _crow else None
                _base = 3 if _needs_reset else (_qr if _qr is not None else 3)
                _new_remaining = max(0, _base - 1)
                cur.execute("""
                    UPDATE dbo.Consumers
                    SET queries_remaining = %s,
                        total_queries = ISNULL(total_queries,0) + 1,
                        last_query_date = CAST(GETUTCDATE() AS date)
                    WHERE REPLACE(phone_number,'+','') = %s OR REPLACE(phone,'+','') = %s
                """, (_new_remaining, clean, clean))
            else:
                cur.execute("""
                    UPDATE dbo.Consumers
                    SET total_queries = ISNULL(total_queries,0) + 1,
                        last_query_date = CAST(GETUTCDATE() AS date)
                    WHERE phone = %s OR phone_number = %s OR phone = %s OR phone_number = %s
                """, (clean, clean, f"+{clean}", f"+{clean}"))
        except Exception as _ue:
            logging.warning(f"[query_limit] consumer counter update failed: {_ue}")
        conn.commit()
        conn.close()
    except Exception as e:
        logging.warning(f"[query_limit] log_query silently failed: {e}")


def remaining_queries(phone: str, consumer: dict) -> str:
    """Returns a human-readable string of remaining queries. Used for status display."""
    tier = (consumer.get("subscription_tier") or "FREE").upper()
    try:
        conn = get_connection()
        cur  = conn.cursor()
        cur.execute(
            "SELECT query_limit, query_period FROM dbo.Subscription_Tiers WHERE tier_id = %s",
            (tier,)
        )
        row = cur.fetchone()
        if not row:
            conn.close()
            return ""
        limit  = row["query_limit"]
        period = (row["query_period"] or "DAY").upper()
        if limit == UNLIMITED:
            conn.close()
            return "Unlimited queries"
        today = datetime.now(timezone.utc).date()
        clean = phone.replace("+", "").strip()
        if period == "WEEK":
            # FREE — read the shared counter (weekly reset Monday 00:00 UTC)
            from datetime import date
            week_start = date.fromordinal(today.toordinal() - today.weekday())
            cur.execute("""
                SELECT queries_remaining, last_query_date FROM dbo.Consumers
                WHERE REPLACE(phone_number,'+','') = %s OR REPLACE(phone,'+','') = %s
            """, (clean, clean))
            crow = cur.fetchone()
            conn.close()
            _last = crow.get("last_query_date") if crow else None
            _last_d = _last.date() if hasattr(_last, "date") else _last
            _needs_reset = (_last_d is None) or (_last_d < week_start)
            _qr = crow.get("queries_remaining") if crow else None
            remaining = limit if _needs_reset else max(0, _qr if _qr is not None else limit)
        else:
            cur.execute("""
                SELECT COUNT(*) as cnt FROM dbo.Query_Log
                WHERE consumer_phone = %s AND query_date = %s
                  AND counted_against_limit = 'Y'
            """, (clean, today.isoformat()))
            row2  = cur.fetchone()
            count = row2.get("cnt", 0) if isinstance(row2, dict) else row2[0]
            conn.close()
            remaining = max(0, limit - count)
        period_label = "this week" if period == "WEEK" else "today"
        return f"{remaining}/{limit} queries left {period_label}"
    except Exception as e:
        logging.error(f"[query_limit] remaining_queries failed: {e}")
        return ""


def get_value_nudge(phone: str, consumer: dict, lang: str) -> str:
    """Return a milestone value message every 5 queries, else empty string."""
    try:
        total = int(consumer.get("total_queries") or 0)
        if total > 0 and total % 10 == 0:
            if lang=="pcm":
                return f"\n\n\U0001f4ca _You don make *{total}* price check! Share NaijaMarket Intel with your people — type *invite* to get your referral code._"
            return f"\n\n\U0001f4ca _You've made *{total}* price checks! Know a trader who'd benefit? Type *invite* to share your referral code._"
        if total > 0 and total % 5 == 0:
            tier = (consumer.get("subscription_tier") or "FREE").upper()
            if lang == "pcm":
                return f"\n\n📊 _You don make *{total}* price check so far on NaijaMarket Intel. {tier} plan dey work for you!_"
            return f"\n\n📊 _You've made *{total}* price checks on NaijaMarket Intel. Keep saving smarter!_"
    except Exception as _e:
        logging.warning(f"[query_limit] get_value_nudge: {_e}")
    return ""
