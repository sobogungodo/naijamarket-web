# shared/market_request.py (wa-v160)
# "register new market": a price reporter is asking us to add a market that isn't in
# dbo.Markets yet. We DURABLY capture the request in dbo.Market_Registration_Requests
# (so nothing is lost) and best-effort forward it to support by email. Email is enabled
# only when BREVO_API_KEY is set on the func app — until then this runs in DB-capture mode.
# Never raises: a logging/email failure must not break the WhatsApp reply.

import os
import logging
import requests
from shared.db import get_connection

SUPPORT_EMAIL      = os.environ.get("SUPPORT_EMAIL", "support@naijamarketintel.ng")
BREVO_API_KEY      = os.environ.get("BREVO_API_KEY", "")
BREVO_SENDER_EMAIL = os.environ.get("BREVO_SENDER_EMAIL", "no-reply@naijamarketintel.ng")
BREVO_SENDER_NAME  = os.environ.get("BREVO_SENDER_NAME", "NaijaMarket Bot")


def forward_market_request(phone: str, message: str) -> None:
    """Persist a new-market request, then best-effort email support."""
    new_id = None
    # 1) Durable capture — works even before email is configured.
    try:
        conn = get_connection()
        cur = conn.cursor(as_dict=True)
        cur.execute(
            "INSERT INTO dbo.Market_Registration_Requests (phone_number, raw_message, requested_at, status) "
            "VALUES (%s, %s, SYSUTCDATETIME(), 'NEW'); SELECT CAST(SCOPE_IDENTITY() AS INT) AS id;",
            (phone, (message or "")[:1000]),
        )
        row = cur.fetchone()
        new_id = row.get("id") if row else None
        conn.commit()
        conn.close()
    except Exception as e:
        logging.error(f"[market_request] DB insert failed: {e}")

    # 2) Best-effort email to support (only if a Brevo key is configured).
    if not BREVO_API_KEY:
        logging.warning("[market_request] BREVO_API_KEY not set — captured in DB only (email deferred)")
        return
    try:
        r = requests.post(
            "https://api.brevo.com/v3/smtp/email",
            headers={"api-key": BREVO_API_KEY, "Content-Type": "application/json", "accept": "application/json"},
            json={
                "sender": {"email": BREVO_SENDER_EMAIL, "name": BREVO_SENDER_NAME},
                "to": [{"email": SUPPORT_EMAIL}],
                "subject": "New market registration request (WhatsApp)",
                "textContent": (
                    "A price reporter has requested a new market be registered.\n\n"
                    f"Phone: {phone}\n"
                    f"Message: {message}\n"
                ),
            },
            timeout=15,
        )
        if 200 <= r.status_code < 300:
            if new_id is not None:
                try:
                    conn = get_connection()
                    cur = conn.cursor()
                    cur.execute("UPDATE dbo.Market_Registration_Requests SET status='EMAILED' WHERE id=%s", (new_id,))
                    conn.commit()
                    conn.close()
                except Exception:
                    pass
        else:
            logging.error(f"[market_request] Brevo {r.status_code}: {r.text[:300]}")
    except Exception as e:
        logging.error(f"[market_request] Brevo send failed: {e}")
