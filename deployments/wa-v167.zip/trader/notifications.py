"""
trader/notifications.py — Template-based trader onboarding notifications.

3 templates (submit to Meta Business Manager for approval):
  1. naijamarket_trader_welcome     — on approval
  2. naijamarket_trader_first_sub   — 24-72h after approval, zero submissions
  3. naijamarket_trader_reengage    — 7+ days approved, fewer than 5 submissions

Called from:
  - func-naijamarket-scraper daily_trader_summary (when scraper is fixed)
  - OR any HTTP-triggered admin function

DB columns required on Traders_register (DDL already run):
  welcome_sent BIT, first_sub_nudge_sent BIT, reengage_sent_at DATETIME2
"""
import logging
from shared.db import get_connection
from shared.sender import send_template_message


def run_trader_notifications() -> dict:
    """Entry point. Returns count of messages sent per type."""
    results = {"welcome": 0, "first_sub": 0, "reengage": 0, "errors": 0}
    try:
        results["welcome"]   = _send_welcome()
        results["first_sub"] = _send_first_sub_nudge()
        results["reengage"]  = _send_reengage()
    except Exception as e:
        logging.error(f"[trader.notifications.run] {e}")
        results["errors"] += 1
    logging.info(f"[trader.notifications] {results}")
    return results


# ── On-approval message — split by whether a home market is locked yet ──
#   • no market  → naijamarket_trader_approved  ({{1}} first_name)  — "log in & choose your market"
#   • has market → naijamarket_trader_welcome    ({{1}} first_name, {{2}} market_name)
# Both flag welcome_sent=1 on success; a failed send is NOT flagged, so it retries next tick
# (self-heals once the template is approved in Meta).
def _send_welcome() -> int:
    sent = 0
    conn = get_connection()
    try:
        cur = conn.cursor(as_dict=True)
        cur.execute("""
            SELECT trader_id, phone_number, first_name, full_name,
                   assigned_market_id, assigned_market_name
            FROM   dbo.Traders_register
            WHERE  registration_status = 'APPROVED'
              AND  (welcome_sent = 0 OR welcome_sent IS NULL)
              AND  ISNULL(is_suspended, 0) = 0
        """)
        traders = cur.fetchall() or []
        conn.close()
        for t in traders:
            phone  = (t.get("phone_number") or "").strip()
            first  = (t.get("first_name") or
                      (t.get("full_name") or "Trader").split()[0])
            if not phone:
                continue
            has_market = bool((t.get("assigned_market_id") or "").strip()) \
                if isinstance(t.get("assigned_market_id"), str) else bool(t.get("assigned_market_id"))
            if has_market:
                market = t.get("assigned_market_name") or "your market"
                ok = send_template_message(
                    phone, "naijamarket_trader_welcome",
                    body_params=[first, market]
                )
                kind = "welcome"
            else:
                # Approved but no locked market yet — nudge them to log in and choose one.
                ok = send_template_message(
                    phone, "naijamarket_trader_approved",
                    body_params=[first]
                )
                kind = "approved(no-market)"
            if ok:
                sent += 1
                _flag(t["trader_id"], "welcome")
            logging.info(f"[notifications.welcome] {phone} [{kind}] → {'OK' if ok else 'FAIL'}")
    except Exception as e:
        logging.error(f"[notifications._welcome] {e}")
        try: conn.close()
        except: pass
    return sent


# ── Template 2: naijamarket_trader_first_sub ─────────────────────
# Vars: {{1}} = first_name
def _send_first_sub_nudge() -> int:
    sent = 0
    conn = get_connection()
    try:
        cur = conn.cursor(as_dict=True)
        cur.execute("""
            SELECT t.trader_id, t.phone_number,
                   t.first_name, t.full_name
            FROM   dbo.Traders_register t
            WHERE  t.registration_status = 'APPROVED'
              AND  t.approved_at BETWEEN DATEADD(HOUR,-72,GETUTCDATE())
                                     AND DATEADD(HOUR,-24,GETUTCDATE())
              AND  ISNULL(t.is_suspended, 0) = 0
              AND  (t.first_sub_nudge_sent = 0 OR t.first_sub_nudge_sent IS NULL)
              AND  NOT EXISTS (
                  SELECT 1 FROM dbo.Submissions s
                  WHERE  (s.trader_phone = t.phone_number
                     OR   s.trader_phone = REPLACE(t.phone_number,'+',''))
                    AND  s.trader_id NOT LIKE 'SYN-%%'
              )
        """)
        traders = cur.fetchall() or []
        conn.close()
        for t in traders:
            phone = (t.get("phone_number") or "").strip()
            first = (t.get("first_name") or
                     (t.get("full_name") or "Trader").split()[0])
            if not phone:
                continue
            ok = send_template_message(
                phone, "naijamarket_trader_first_sub",
                body_params=[first]
            )
            if ok:
                sent += 1
                _flag(t["trader_id"], "first_sub")
    except Exception as e:
        logging.error(f"[notifications._first_sub] {e}")
        try: conn.close()
        except: pass
    return sent


# ── Template 3: naijamarket_trader_reengage ──────────────────────
# Vars: {{1}} = first_name, {{2}} = market_name, {{3}} = sub_count
def _send_reengage() -> int:
    sent = 0
    conn = get_connection()
    try:
        cur = conn.cursor(as_dict=True)
        cur.execute("""
            SELECT t.trader_id, t.phone_number,
                   t.first_name, t.full_name,
                   t.assigned_market_name,
                   ISNULL(sub.cnt, 0) AS sub_count
            FROM   dbo.Traders_register t
            LEFT JOIN (
                SELECT trader_phone, COUNT(*) AS cnt
                FROM   dbo.Submissions
                WHERE  trader_id NOT LIKE 'SYN-%%'
                GROUP BY trader_phone
            ) sub ON (sub.trader_phone = t.phone_number
                  OR  sub.trader_phone = REPLACE(t.phone_number,'+',''))
            WHERE  t.registration_status = 'APPROVED'
              AND  t.approved_at <= DATEADD(DAY,-7,GETUTCDATE())
              AND  ISNULL(t.is_suspended, 0) = 0
              AND  ISNULL(sub.cnt, 0) < 5
              AND  (t.reengage_sent_at IS NULL
                OR  t.reengage_sent_at <= DATEADD(DAY,-14,GETUTCDATE()))
        """)
        traders = cur.fetchall() or []
        conn.close()
        for t in traders:
            phone     = (t.get("phone_number") or "").strip()
            first     = (t.get("first_name") or
                         (t.get("full_name") or "Trader").split()[0])
            market    = t.get("assigned_market_name") or "your market"
            sub_count = str(int(t.get("sub_count") or 0))
            if not phone:
                continue
            ok = send_template_message(
                phone, "naijamarket_trader_reengage",
                body_params=[first, market, sub_count]
            )
            if ok:
                sent += 1
                _flag(t["trader_id"], "reengage")
    except Exception as e:
        logging.error(f"[notifications._reengage] {e}")
        try: conn.close()
        except: pass
    return sent


# ── Flag helper ──────────────────────────────────────────────────
def _flag(trader_id: str, nudge: str) -> None:
    try:
        conn = get_connection()
        cur  = conn.cursor()
        if nudge == "welcome":
            cur.execute(
                "UPDATE dbo.Traders_register SET welcome_sent=1 WHERE trader_id=%s",
                (trader_id,)
            )
        elif nudge == "first_sub":
            cur.execute(
                "UPDATE dbo.Traders_register SET first_sub_nudge_sent=1 WHERE trader_id=%s",
                (trader_id,)
            )
        else:
            cur.execute(
                "UPDATE dbo.Traders_register SET reengage_sent_at=GETUTCDATE() WHERE trader_id=%s",
                (trader_id,)
            )
        conn.commit()
        conn.close()
    except Exception as e:
        logging.error(f"[notifications._flag] {e}")
