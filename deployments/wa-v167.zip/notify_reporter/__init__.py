"""
notify_reporter — HTTP endpoint (authLevel: function) that sends a reporter a WhatsApp
template and/or an email in one call. [wa-v167]

The single, central reporter-notification sender: the admin dashboard and the registration
flows POST here instead of each replicating WA/Brevo senders (per the design decision).

POST body:
  {
    "phone":        "+234…",          # required (E.164)
    "wa_template":  "template_name",  # optional; omit to skip WhatsApp
    "wa_params":    ["a","b"],         # optional ordered {{1}},{{2}}…
    "wa_button_url":"token",           # optional dynamic URL-button suffix
    "email":        "x@y.com",         # optional; omit to skip email
    "email_subject":"…",
    "email_html":   "<p>…</p>"
  }

Returns 200 { "wa": bool|null, "email": bool|null }.
BEST-EFFORT: a channel failure (missing/unapproved template, Brevo hiccup) does NOT fail the
request — callers must never be blocked by a notification problem.
"""
import json
import logging
import azure.functions as func

from shared.sender import send_template_message
from shared.email import send_brevo_email


def main(req: func.HttpRequest) -> func.HttpResponse:
    try:
        body = req.get_json()
    except ValueError:
        return func.HttpResponse(
            json.dumps({"error": "invalid JSON"}),
            status_code=400, mimetype="application/json",
        )

    phone = (body.get("phone") or "").strip()
    if not phone:
        return func.HttpResponse(
            json.dumps({"error": "phone required"}),
            status_code=400, mimetype="application/json",
        )

    # WhatsApp channel
    wa_result = None
    wa_template = body.get("wa_template")
    if wa_template:
        try:
            wa_result = send_template_message(
                phone, wa_template,
                body_params=body.get("wa_params") or [],
                button_url_param=body.get("wa_button_url"),
            )
        except Exception as e:
            logging.error(f"[notify_reporter] WA send error: {e}")
            wa_result = False

    # Email channel
    email_result = None
    email = (body.get("email") or "").strip()
    if email:
        try:
            email_result = send_brevo_email(
                email,
                body.get("email_subject") or "NaijaMarket Reporter",
                body.get("email_html") or "",
            )
        except Exception as e:
            logging.error(f"[notify_reporter] email send error: {e}")
            email_result = False

    logging.info(
        f"[notify_reporter] {phone} wa={wa_result} email={email_result} tmpl={wa_template}"
    )
    return func.HttpResponse(
        json.dumps({"wa": wa_result, "email": email_result}),
        status_code=200, mimetype="application/json",
    )
