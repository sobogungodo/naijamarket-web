import logging, os, uuid, requests
from datetime import datetime
from shared.db import get_connection
from shared.sender import send_message
from shared.session import save_session, clear_session
from consumer.menu import show_main_menu

# Token-pack checkout: creates a PENDING Token_Transactions row keyed by the
# Paystack reference; the account-level Paystack webhook credits it on
# charge.success via /api/tokens/verify (atomic PENDING->COMPLETED, dedup-safe).
PAYMENTS_ENABLED = True

def _packs():
    """Active token packs (excludes the PROMO_FREE welcome bonus)."""
    conn = get_connection()
    try:
        cur = conn.cursor(as_dict=True)
        cur.execute("""
            SELECT pack_id, pack_name, tokens, bonus_tokens, price_naira, is_popular
            FROM dbo.Token_Packs
            WHERE is_active = 1 AND pack_id <> 'PROMO_FREE'
            ORDER BY sort_order ASC, price_naira ASC
        """)
        return cur.fetchall() or []
    finally:
        conn.close()

def _balance(phone):
    """Token balance for this phone (0 if no wallet)."""
    clean = phone.replace("+", "").strip()
    conn = get_connection()
    try:
        cur = conn.cursor(as_dict=True)
        cur.execute("""
            SELECT token_balance FROM dbo.Token_Wallets
            WHERE consumer_phone = %s OR consumer_phone = %s
        """, (clean, f"+{clean}"))
        row = cur.fetchone()
        return int(row["token_balance"]) if row and row.get("token_balance") is not None else 0
    finally:
        conn.close()

def handle_token_wallet(phone, message="", session=None, consumer=None, *args):
    session = session or {}; consumer = consumer or {}
    text = (message or "").strip(); msg = text.lower()
    step = session.get("step", 0)
    if msg in ("0", "menu") or (msg == "back" and step == 0):
        clear_session(phone); show_main_menu(phone); return
    if step == 0:
        _menu(phone, session)
    elif step == 1:
        _pick(phone, text, session, consumer)

def _menu(phone, session):
    try:
        packs = _packs()
    except Exception as e:
        logging.error(f"[token_wallet] packs load failed: {e}"); packs = []
    try:
        bal = _balance(phone)
    except Exception as e:
        logging.error(f"[token_wallet] balance load failed: {e}"); bal = 0
    if not packs:
        clear_session(phone)
        send_message(phone, "\U0001f4b0 *TOKEN WALLET*\n\nToken packs are unavailable right now. Please try again later.\n\n*menu* — Back to menu")
        return
    lines = "\n".join(
        f"{i+1}️⃣ {p.get('pack_name') or p.get('pack_id')} — {p['tokens']}"
        + (f" (+{p['bonus_tokens']})" if p.get('bonus_tokens') else "")
        + f" tokens — ₦{int(p['price_naira']):,}"
        for i, p in enumerate(packs)
    )
    session.update({"_flow": "TOKEN_WALLET", "step": 1, "pack_ids": [p["pack_id"] for p in packs]})
    save_session(phone, session)
    send_message(phone,
        "\U0001f4b0 *TOKEN WALLET*\n\n"
        f"Balance: {bal} tokens\n\n"
        "Token packs:\n"
        f"{lines}\n\n"
        "Reply with the pack number to buy\n"
        "Or reply *MENU* to go back")

def _pick(phone, text, session, consumer):
    pack_ids = session.get("pack_ids", [])
    try:
        idx = int(text) - 1
        assert 0 <= idx < len(pack_ids)
    except Exception:
        send_message(phone, "Please reply with a valid pack number, or *MENU* to go back.")
        return

    if not PAYMENTS_ENABLED:
        clear_session(phone)
        send_message(phone, "Token purchases are not yet available. You will be notified when payments open.")
        return

    pack_id = pack_ids[idx]
    secret = os.environ.get("PAYSTACK_SECRET_KEY", "")
    if not secret:
        clear_session(phone)
        send_message(phone, "Payment is temporarily unavailable. Please try again later.")
        return
    try:
        clean = phone.replace("+", "").strip()
        pplus = f"+{clean}"
        conn = get_connection(); cur = conn.cursor(as_dict=True)
        cur.execute("SELECT pack_id, pack_name, tokens, bonus_tokens, price_naira FROM dbo.Token_Packs WHERE pack_id=%s AND is_active=1", (pack_id,))
        pack = cur.fetchone()
        if not pack:
            conn.close(); clear_session(phone)
            send_message(phone, "That pack is no longer available. Reply *WALLET* to try again."); return
        cid = (consumer or {}).get("consumer_id", "")
        name = ((consumer or {}).get("name") or (consumer or {}).get("consumer_name") or "")[:200]
        email = (consumer or {}).get("email") or f"{clean}@naijamarketintel.ng"
        total_tokens = int(pack["tokens"]) + int(pack.get("bonus_tokens") or 0)
        price_naira = float(pack["price_naira"])
        ref = f"TKN-{str(pack_id)[:4].upper()}-{uuid.uuid4().hex[:8].upper()}"

        # Get-or-create the wallet (keyed by phone), then log a PENDING transaction
        # keyed by ref. The Paystack webhook credits it on charge.success.
        cur.execute("SELECT TOP 1 wallet_id, token_balance FROM dbo.Token_Wallets WHERE consumer_phone IN (%s, %s)", (clean, pplus))
        w = cur.fetchone()
        if w:
            wallet_id = w["wallet_id"]; balance = int(w.get("token_balance") or 0)
        else:
            wallet_id = f"TWL-{datetime.utcnow().strftime('%Y%m%d%H%M%S')}-{clean[-4:]}"; balance = 0
            cur.execute(
                "INSERT INTO dbo.Token_Wallets (wallet_id, consumer_phone, consumer_name, "
                "token_balance, total_purchased, total_spent, total_expired, total_refunded, "
                "total_amount_paid, total_queries_made, wallet_status, created_at, updated_at) "
                "VALUES (%s, %s, %s, 0,0,0,0,0,0,0, 'ACTIVE', GETUTCDATE(), GETUTCDATE())",
                (wallet_id, pplus, name))
        txn_id = "TXN-" + datetime.utcnow().strftime("%Y%m%d%H%M%S%f")[:17]
        cur.execute(
            "INSERT INTO dbo.Token_Transactions (transaction_id, wallet_id, consumer_phone, "
            "transaction_type, tokens_amount, token_balance_before, token_balance_after, pack_id, "
            "payment_reference, payment_provider, payment_amount, payment_status, description, channel, created_at) "
            "VALUES (%s,%s,%s,'PURCHASE',%s,%s,%s,%s,%s,'PAYSTACK',%s,'PENDING',%s,'WHATSAPP', GETUTCDATE())",
            (txn_id, wallet_id, pplus, total_tokens, balance, balance, pack_id, ref, price_naira,
             f"Token purchase: {pack['pack_name']} ({total_tokens} tokens)"))
        conn.commit(); conn.close()

        resp = requests.post("https://api.paystack.co/transaction/initialize",
            headers={"Authorization": f"Bearer {secret}"},
            json={"email": email, "amount": int(round(price_naira * 100)), "reference": ref,
                  "metadata": {"phone": pplus, "pack_id": pack_id, "pack_name": pack["pack_name"],
                               "consumer_id": cid, "total_tokens": total_tokens, "purchase_type": "TOKEN_PACK"}},
            timeout=15)
        data = resp.json()
        if data.get("status") and data.get("data", {}).get("authorization_url"):
            clear_session(phone)
            send_message(phone,
                f"\U0001f4b3 *{pack['pack_name']}* — {total_tokens} tokens — ₦{int(price_naira):,}\n\n"
                f"Pay here:\n{data['data']['authorization_url']}\n\n"
                f"Your tokens are credited automatically after payment.\n\nRef: {ref}")
        else:
            raise Exception(data.get("message", "init failed"))
    except Exception as e:
        logging.error(f"[token_wallet] {e}")
        try:
            clear_session(phone)
        except Exception:
            pass
        send_message(phone, "⚠️ Could not start the payment. Please try again later.")
