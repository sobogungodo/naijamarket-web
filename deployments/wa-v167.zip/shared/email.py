"""
shared/email.py — Brevo transactional email sender [wa-v167].
Mirrors the inline Brevo pattern used across the web apps (POST /v3/smtp/email,
api-key header, sender noreply@naijamarketintel.ng). Best-effort: returns bool, never raises
to the caller. Requires app setting BREVO_API_KEY on the function.
"""
import os
import logging
import requests

BREVO_URL    = "https://api.brevo.com/v3/smtp/email"
SENDER_EMAIL = "noreply@naijamarketintel.ng"
SENDER_NAME  = "NaijaMarket Intel"


def send_brevo_email(to_email: str, subject: str, html: str) -> bool:
    api_key = os.environ.get("BREVO_API_KEY", "")
    if not api_key:
        logging.warning("[email] BREVO_API_KEY not set — skipping email")
        return False
    to_email = (to_email or "").strip()
    if not to_email:
        return False
    try:
        r = requests.post(
            BREVO_URL,
            headers={"api-key": api_key, "Content-Type": "application/json"},
            json={
                "sender": {"name": SENDER_NAME, "email": SENDER_EMAIL},
                "to": [{"email": to_email}],
                "subject": subject or "NaijaMarket Intel",
                "htmlContent": html or "",
            },
            timeout=10,
        )
        if r.status_code not in (200, 201):
            logging.error(f"[email] Brevo {r.status_code}: {r.text[:200]}")
            return False
        return True
    except Exception as e:
        logging.error(f"[email] {e}")
        return False
