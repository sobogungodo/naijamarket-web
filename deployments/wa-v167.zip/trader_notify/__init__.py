"""
trader_notify — TimerTrigger: every 15 minutes, send trader onboarding notifications
(approval / first-submission / re-engagement). [wa-v165]

Wires up trader.notifications.run_trader_notifications, which until now was dead code
(no trigger). On-approval delivery is therefore near-immediate (<=15 min) and covers BOTH
approval paths (admin-approve and WhatsApp auto-approve) because it polls
Traders_register.welcome_sent. Failed sends do NOT flag, so the reporter is retried on the
next tick — the timer self-heals once a template is approved in Meta.

Schedule "0 */15 * * * *" runs in UTC (Linux Functions host, WEBSITE_TIME_ZONE unset).
"""
import logging
import azure.functions as func

from trader.notifications import run_trader_notifications


def main(mytimer: func.TimerRequest) -> None:
    if getattr(mytimer, "past_due", False):
        logging.warning("[trader_notify] timer is past due")
    logging.info("[trader_notify] timer fired — running trader onboarding notifications")
    try:
        results = run_trader_notifications()
        logging.info(f"[trader_notify] done: {results}")
    except Exception as e:  # never let the timer crash the host
        logging.error(f"[trader_notify] unhandled error: {e}")
