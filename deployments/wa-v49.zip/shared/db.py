import os, pymssql

def get_connection():
    return pymssql.connect(
        server=os.environ["SQL_SERVER"],
        user=os.environ.get("SQL_USERNAME", os.environ.get("SQL_USER","")),
        password=os.environ["SQL_PASSWORD"],
        database=os.environ["SQL_DATABASE"],
        as_dict=True, timeout=30
    )

def get_consumer(phone):
    conn = get_connection()
    try:
        cur = conn.cursor(as_dict=True)
        clean = phone.replace("+","").strip()
        cur.execute("""
            SELECT consumer_id, phone, phone_number, subscription_tier,
                   subscription_end_date, account_status, preferred_language,
                   pending_downgrade_tier, downgrade_effective_date
            FROM dbo.Consumers
            WHERE phone = %s OR phone_number = %s OR phone = %s OR phone_number = %s
        """, (clean, clean, f"+{clean}", f"+{clean}"))
        return cur.fetchone() or {}
    finally:
        conn.close()

def get_role(phone):
    """Returns 'TRADER', 'VALIDATOR', 'CONSUMER', or None from User_Roles."""
    conn = get_connection()
    try:
        cur = conn.cursor(as_dict=True)
        clean = phone.replace("+","").strip()
        cur.execute("""
            SELECT role FROM dbo.User_Roles
            WHERE phone_number = %s OR phone_number = %s
        """, (clean, f"+{clean}"))
        row = cur.fetchone()
        return row['role'].upper() if row else None
    except Exception:
        return None
    finally:
        conn.close()

def get_trader(phone):
    """Returns trader record from Traders_register or None."""
    conn = get_connection()
    try:
        cur = conn.cursor(as_dict=True)
        clean = phone.replace("+","").strip()
        cur.execute("""
            SELECT trader_id, full_name, first_name,
                   assigned_market_id, assigned_market_name, assigned_state,
                   reputation, registration_status, is_suspended
            FROM dbo.Traders_register
            WHERE phone_number = %s OR phone_number = %s
        """, (clean, f"+{clean}"))
        return cur.fetchone() or None
    except Exception:
        return None
    finally:
        conn.close()

def get_validator(phone):
    """Returns validator record from Validators or None."""
    conn = get_connection()
    try:
        cur = conn.cursor(as_dict=True)
        clean = phone.replace("+","").strip()
        cur.execute("""
            SELECT validator_id, full_name, status
            FROM dbo.Validators
            WHERE phone_number = %s OR phone_number = %s
        """, (clean, f"+{clean}"))
        return cur.fetchone() or None
    except Exception:
        return None
    finally:
        conn.close()
