"""
shared/search.py — Free-text commodity search for router fallback [1k]

When user types something like "rice lagos" or "tomato price" that doesn't
match any keyword, we try to identify the commodity and route to the prices
flow with the item pre-matched (skipping the item-browse step).

Only does a lightweight LIKE query on item_name — no fuzzy matching.
Returns None quickly on no match to avoid latency on every unknown input.
"""
import logging
import re
from shared.db import get_connection

# Known state names / abbreviations for quick extraction
_STATES = {
    "lagos", "abuja", "kano", "oyo", "rivers", "kaduna", "anambra", "ogun",
    "delta", "edo", "imo", "enugu", "borno", "katsina", "bauchi", "kwara",
    "benue", "plateau", "cross river", "crossriver", "akwa ibom", "akwaibom",
    "abia", "ebonyi", "ekiti", "gombe", "jigawa", "kebbi", "kogi", "nasarawa",
    "niger", "ondo", "osun", "sokoto", "taraba", "yobe", "zamfara", "fct",
    "adamawa", "bayelsa",
}

# Common price-query noise words to strip before matching
_NOISE = {
    "price", "prices", "cost", "how", "much", "naira", "today", "market",
    "buy", "sell", "check", "show", "me", "what", "is", "the", "in", "at",
    "of", "for", "current", "now", "cheap",
}


def _clean_query(text: str) -> tuple:
    """
    Strip noise words and state names from user input.
    Returns (commodity_tokens, state_hint).
    """
    words = re.sub(r"[^\w\s]", " ", text.lower()).split()
    state_hint = None
    commodity = []

    for i, w in enumerate(words):
        # Check for two-word state names
        two = f"{w} {words[i+1]}" if i + 1 < len(words) else ""
        if two in _STATES:
            state_hint = two
            continue
        if w in _STATES:
            state_hint = w
            continue
        if w in _NOISE:
            continue
        commodity.append(w)

    return commodity, state_hint


# Nigerian commodity aliases — maps common names/spellings to catalog search terms
_ALIASES = {
    "garri":"Garri","eba":"Garri","gari":"Garri",
    "tomatoe":"Tomatoes","tomato":"Tomatoes","tomattos":"Tomatoes",
    "groundnut":"Groundnut","peanut":"Groundnut","groundnuts":"Groundnut",
    "palm oil":"Palm Oil","palmoil":"Palm Oil","red oil":"Palm Oil",
    "egusi":"Egusi","melon seed":"Egusi","egushi":"Egusi",
    "yam":"Yam","pounded yam":"Yam",
    "beans":"Beans","black eyed beans":"Beans","oloyin":"Beans",
    "pepper":"Pepper","tatashe":"Pepper","rodo":"Pepper","scotch bonnet":"Pepper",
    "onion":"Onion","onions":"Onion",
    "plantain":"Plantain","unripe plantain":"Plantain",
    "cassava":"Cassava","abacha":"Abacha",
    "crayfish":"Crayfish","kpanla":"Crayfish",
    "stockfish":"Stockfish","okporoko":"Stockfish","panla":"Stockfish",
    "semovita":"Semovita","semo":"Semovita","semolina":"Semolina",
    "wheat":"Wheat Flour","flour":"Wheat Flour",
    "sugar":"Sugar","salt":"Salt",
    "vegetable oil":"Vegetable Oil","veg oil":"Vegetable Oil",
    "noodles":"Noodles","indomie":"Noodles","spaghetti":"Spaghetti",
    "rice":"Rice","ofada":"Ofada Rice","parboiled rice":"Rice",
    "maize":"Maize","corn":"Maize",
    "soya":"Soya Beans","soybean":"Soya Beans","soybeans":"Soya Beans",
    "potatoes":"Irish Potato","potato":"Irish Potato","irish potato":"Irish Potato",
    "sweet potato":"Sweet Potato","sweet potatoes":"Sweet Potato",
    "cocoyam":"Cocoyam","taro":"Cocoyam",
    "okro":"Okro","okra":"Okro",
    "spinach":"Spinach","ugu":"Ugu Leaves","waterleaf":"Water Leaf",
    "zobo":"Zobo","hibiscus":"Zobo",
    "milk":"Milk","peak milk":"Milk",
    "butter":"Butter","margarine":"Margarine",
    "egg":"Eggs","eggs":"Eggs",
    "chicken":"Chicken","broiler":"Chicken",
    "beef":"Beef","cow meat":"Beef","meat":"Beef",
    "fish":"Fish","catfish":"Catfish","tilapia":"Tilapia",
    "mackerel":"Mackerel","titus":"Mackerel",
}

def _resolve_alias(tokens: list) -> str:
    """Check 1-3 token combinations against alias table, return resolved term."""
    joined = " ".join(tokens).lower()
    if joined in _ALIASES: return _ALIASES[joined]
    for n in (2, 1):
        partial = " ".join(tokens[:n]).lower()
        if partial in _ALIASES: return _ALIASES[partial]
    return " ".join(tokens[:2])

def search_commodity(query: str) -> dict | None:
    """
    Try to match the user's free-text query to an item in the catalog.
    Returns a dict with {item_id, item_name, unit} or None if no match.

    Keeps it fast: one LIKE query, TOP 1, indexed item_name.
    """
    if not query or len(query.strip()) < 3:
        return None

    commodity_tokens, state_hint = _clean_query(query)
    if not commodity_tokens:
        return None

    # Resolve alias first, then use as search term
    search_term = _resolve_alias(commodity_tokens)
    if len(search_term) < 3:
        return None

    try:
        conn = get_connection()
        cur  = conn.cursor()
        cur.execute(
            """
            SELECT TOP 1 item_id, item_name, Unit AS unit
            FROM dbo.Items_Catalog
            WHERE item_name LIKE %s
              AND (status = 'ACTIVE' OR status IS NULL)
            ORDER BY
                CASE WHEN item_name LIKE %s THEN 0 ELSE 1 END,
                item_name
            """,
            (f"%{search_term}%", f"{search_term}%")
        )
        row = cur.fetchone()
        conn.close()
        if row:
            return {
                "item_id":   row["item_id"],
                "item_name": row["item_name"],
                "unit":      row.get("unit", "unit"),
                "state_hint": state_hint,
            }
        return None
    except Exception as e:
        logging.warning(f"[search] search_commodity '{search_term}': {e}")
        return None
