"""
trader/kyc.py — Trader KYC registration placeholder
Redirects to PWA registration for now.
Full KYC flow is handled via the trader PWA (naijamarket-trader.vercel.app).
"""

def handle_kyc(phone, message="", session=None, *args):
    from shared.sender import send_message
    send_message(phone,
        "📋 *Trader Registration*\n\n"
        "To register as a NaijaMarket trader, please visit:\n"
        "👉 *https://naijamarket-trader.vercel.app*\n\n"
        "Registration takes 5 minutes. You'll need:\n"
        "• Your full name and date of birth\n"
        "• NIN (National ID Number)\n"
        "• Bank account details for payouts\n\n"
        "Already registered? Type *submit* to start submitting prices.\n"
        "Type *menu* to go back."
    )
