import logging, os, uuid, requests
from datetime import datetime, date, timezone
from shared.db import get_connection
from shared.sender import send_message
from validator.banks import BANKS, BANK_LIST_MSG, get_bank_code

NIGERIAN_STATES = [
    "Abia","Adamawa","Akwa Ibom","Anambra","Bauchi","Bayelsa","Benue",
    "Borno","Cross River","Delta","Ebonyi","Edo","Ekiti","Enugu","FCT",
    "Gombe","Imo","Jigawa","Kaduna","Kano","Katsina","Kebbi","Kogi",
    "Kwara","Lagos","Nasarawa","Niger","Ogun","Ondo","Osun","Oyo",
    "Plateau","Rivers","Sokoto","Taraba","Yobe","Zamfara"
]
STATE_LIST_MSG = "\n".join(f"{i+1}. {s}" for i, s in enumerate(NIGERIAN_STATES))

TC_TEXT = """*NaijaMarket Intel — Validator Terms*

By joining as a validator, you agree to:
1. Submit HONEST votes based on physical market observation
2. Be present within 500m of your assigned market when voting
3. Never collude with traders or other validators
4. Maintain at least 60% accuracy rate
5. Respond to assignments within 30 minutes

Violations result in immediate suspension and forfeiture of balance.

Reply *ACCEPT* to agree, or *CANCEL* to exit."""

MAX_INVITE_ATTEMPTS = 3
MAX_BANK_ATTEMPTS = 3


def _get_or_create_session(phone):
    conn = get_connection()
    cur = conn.cursor()
    cur.execute("""
        SELECT session_id, step, status, invite_code, invite_code_valid,
               invite_code_market_id, invite_code_market_name,
               full_name, first_name, last_name, date_of_birth,
               address, state, bank_name, bank_code, account_number,
               bank_account_name, invite_code_attempts, bank_verification_attempts,
               error_count, preferred_language
        FROM dbo.Validator_Reg_Sessions
        WHERE phone_number=%s AND status='IN_PROGRESS'
        ORDER BY started_at DESC
    """, (phone,))
    row = cur.fetchone()
    conn.close()
    if row:
        keys = ["session_id","step","status","invite_code","invite_code_valid",
                "invite_code_market_id","invite_code_market_name",
                "full_name","first_name","last_name","date_of_birth",
                "address","state","bank_name","bank_code","account_number",
                "bank_account_name","invite_code_attempts","bank_verification_attempts",
                "error_count","preferred_language"]
        return dict(zip(keys, row))
    session_id = f"VRS-{uuid.uuid4().hex[:12].upper()}"
    conn = get_connection()
    cur = conn.cursor()
    cur.execute("""
        INSERT INTO dbo.Validator_Reg_Sessions
          (session_id, phone_number, step, status, invite_code_attempts,
           bank_verification_attempts, error_count, started_at,
           last_activity_at, expires_at, created_at, updated_at)
        VALUES (%s,%s,1,'IN_PROGRESS',0,0,0,
                GETUTCDATE(),GETUTCDATE(),
                DATEADD(HOUR,24,GETUTCDATE()),
                GETUTCDATE(),GETUTCDATE())
    """, (session_id, phone))
    conn.commit()
    conn.close()
    return {"session_id": session_id, "step": 1, "status": "IN_PROGRESS",
            "invite_code_attempts": 0, "bank_verification_attempts": 0, "error_count": 0}


def _save_session(session_id, fields):
    if not fields:
        return
    sets = ", ".join(f"{k}=%s" for k in fields)
    sets += ", updated_at=GETUTCDATE(), last_activity_at=GETUTCDATE()"
    vals = list(fields.values()) + [session_id]
    conn = get_connection()
    cur = conn.cursor()
    cur.execute(f"UPDATE dbo.Validator_Reg_Sessions SET {sets} WHERE session_id=%s", vals)
    conn.commit()
    conn.close()


def _validate_invite_code(code, phone):
    conn = get_connection()
    cur = conn.cursor()
    cur.execute("""
        SELECT market_id, market_name, status, expires_at, used_by_phone
        FROM dbo.Validator_Invite_Codes
        WHERE invite_code=%s
    """, (code.upper().strip(),))
    row = cur.fetchone()
    conn.close()
    if not row:
        return {"valid": False, "reason": "not_found"}
    market_id, market_name, status, expires_at, used_by = row
    if status != 'ACTIVE':
        return {"valid": False, "reason": "used"}
    if expires_at and expires_at < datetime.utcnow():
        return {"valid": False, "reason": "expired"}
    if used_by and used_by != phone:
        return {"valid": False, "reason": "used"}
    return {"valid": True, "market_id": market_id, "market_name": market_name}


def _resolve_bank_account(account_number, bank_code):
    key = os.environ.get("PAYSTACK_SECRET_KEY", "")
    if not key:
        return {"valid": False, "reason": "no_key"}
    try:
        r = requests.get(
            "https://api.paystack.co/bank/resolve",
            params={"account_number": account_number, "bank_code": bank_code},
            headers={"Authorization": f"Bearer {key}"},
            timeout=15
        )
        data = r.json()
        if data.get("status") and data.get("data", {}).get("account_name"):
            return {"valid": True, "account_name": data["data"]["account_name"]}
        return {"valid": False, "reason": data.get("message", "unresolved")}
    except Exception as e:
        logging.error(f"[validator_reg] Paystack error: {e}")
        return {"valid": False, "reason": "timeout"}


def _complete_registration(session, phone):
    validator_id = f"VAL-{uuid.uuid4().hex[:8].upper()}"
    conn = get_connection()
    cur = conn.cursor()
    cur.execute("""
        INSERT INTO dbo.Validators (
            validator_id, phone_number, full_name, first_name, last_name,
            date_of_birth, address, state,
            assigned_market, market_id, assigned_at,
            bank_name, bank_code, account_number,
            bank_account_name, invite_code, registration_status,
            tc_version_accepted, tc_accepted_at,
            total_votes, correct_votes, approval_count, rejection_count,
            accuracy_rate, balance, current_balance, total_earned,
            status, tier, preferred_language,
            registered_at, created_at, updated_at
        ) VALUES (
            %s,%s,%s,%s,%s,
            %s,%s,%s,
            %s,%s,GETUTCDATE(),
            %s,%s,%s,
            %s,%s,'PENDING_APPROVAL',
            1,GETUTCDATE(),
            0,0,0,0,
            0,0.00,0.00,0,
            'ACTIVE','STANDARD',%s,
            GETUTCDATE(),GETUTCDATE(),GETUTCDATE()
        )
    """, (
        validator_id, phone,
        session.get("full_name"), session.get("first_name"), session.get("last_name"),
        session.get("date_of_birth"), session.get("address"), session.get("state"),
        session.get("invite_code_market_name"), session.get("invite_code_market_id"),
        session.get("bank_name"), str(session.get("bank_code", "")), session.get("account_number"),
        session.get("bank_account_name"), session.get("invite_code"),
        session.get("preferred_language", "en")
    ))
    cur.execute("""
        INSERT INTO dbo.User_Roles (phone_number, role, assigned_at, created_at)
        VALUES (%s,'VALIDATOR',GETUTCDATE(),GETUTCDATE())
    """, (phone,))
    cur.execute("""
        UPDATE dbo.Validator_Invite_Codes
        SET status='USED', used_by_phone=%s, used_by_name=%s,
            used_at=GETUTCDATE(), updated_at=GETUTCDATE()
        WHERE invite_code=%s
    """, (phone, session.get("full_name"), session.get("invite_code")))
    cur.execute("""
        UPDATE dbo.Validator_Reg_Sessions
        SET status='COMPLETED', registration_successful=1,
            validator_id=%s, completed_at=GETUTCDATE(), updated_at=GETUTCDATE()
        WHERE session_id=%s
    """, (validator_id, session.get("session_id")))
    conn.commit()
    conn.close()
    return validator_id


def handle_validator_registration(phone, message):
    msg = message.strip()

    if msg.lower() in ("cancel", "exit", "quit", "menu", "0"):
        conn = get_connection()
        cur = conn.cursor()
        cur.execute("""
            UPDATE dbo.Validator_Reg_Sessions
            SET status='ABANDONED', abandoned_at=GETUTCDATE(), updated_at=GETUTCDATE()
            WHERE phone_number=%s AND status='IN_PROGRESS'
        """, (phone,))
        conn.commit()
        conn.close()
        send_message(phone,
            "Registration cancelled. Send *VAL-START* anytime to begin again.\n\n"
            "Or type *menu* to go back.")
        return

    session = _get_or_create_session(phone)
    step = session.get("step", 1)

    # STEP 1: Invite code
    if step == 1:
        if not msg or msg.upper() == "VAL-START":
            send_message(phone,
                "Welcome to *NaijaMarket Intel Validator Registration*\n\n"
                "You earn *N50* for every submission you verify.\n\n"
                "Enter your *VAL-XXXXX* invite code to begin.\n"
                "_(Reply CANCEL anytime to exit)_")
            return
        attempts = (session.get("invite_code_attempts") or 0) + 1
        result = _validate_invite_code(msg, phone)
        if not result["valid"]:
            if attempts >= MAX_INVITE_ATTEMPTS:
                _save_session(session["session_id"], {"status": "BLOCKED", "invite_code_attempts": attempts})
                send_message(phone,
                    "Too many invalid attempts. Registration blocked.\n"
                    "Contact support if you have a valid invite code.")
                return
            reason_msg = {
                "not_found": "That code does not exist.",
                "used": "That code has already been used.",
                "expired": "That code has expired."
            }.get(result["reason"], "Invalid code.")
            _save_session(session["session_id"], {"invite_code_attempts": attempts})
            send_message(phone,
                f"{reason_msg}\n\n"
                f"Please check your code and try again. "
                f"({MAX_INVITE_ATTEMPTS - attempts} attempt(s) remaining)")
            return
        _save_session(session["session_id"], {
            "step": 2,
            "invite_code": msg.upper().strip(),
            "invite_code_valid": 1,
            "invite_code_market_id": result["market_id"],
            "invite_code_market_name": result["market_name"],
            "invite_code_attempts": attempts
        })
        send_message(phone,
            f"Code accepted! You will be assigned to *{result['market_name']}*.\n\n"
            f"*Step 1 of 7 - Full Name*\n"
            f"Enter your full name as it appears on your ID.\n"
            f"_(e.g. Amaka Okonkwo)_")

    # STEP 2: Full name
    elif step == 2:
        parts = msg.strip().split()
        if len(parts) < 2:
            send_message(phone,
                "Please enter your *full name* (first and last name).\n"
                "_(e.g. Amaka Okonkwo)_")
            return
        first = parts[0].capitalize()
        last = " ".join(p.capitalize() for p in parts[1:])
        full = f"{first} {last}"
        _save_session(session["session_id"], {
            "step": 3, "full_name": full,
            "first_name": first, "last_name": last
        })
        send_message(phone,
            f"Name saved: *{full}*\n\n"
            f"*Step 2 of 7 - Date of Birth*\n"
            f"Enter your date of birth: *DD/MM/YYYY*\n"
            f"_(e.g. 15/03/1990)_")

    # STEP 3: Date of birth
    elif step == 3:
        try:
            dob = datetime.strptime(msg.strip(), "%d/%m/%Y").date()
            age = (date.today() - dob).days // 365
            if age < 18:
                send_message(phone, "You must be at least 18 years old to register.")
                return
            if age > 80:
                send_message(phone, "Invalid date of birth. Please check and try again.")
                return
            _save_session(session["session_id"], {"step": 4, "date_of_birth": dob.isoformat()})
            send_message(phone,
                f"DOB saved.\n\n"
                f"*Step 3 of 7 - Home Address*\n"
                f"Enter your home address (street, area, city).\n"
                f"_(e.g. 12 Balogun Street, Surulere, Lagos)_")
        except ValueError:
            send_message(phone,
                "Invalid format. Please use *DD/MM/YYYY*\n"
                "_(e.g. 15/03/1990)_")

    # STEP 4: Address
    elif step == 4:
        if len(msg.strip()) < 10:
            send_message(phone, "Please enter your full address (at least 10 characters).")
            return
        _save_session(session["session_id"], {"step": 5, "address": msg.strip()})
        send_message(phone,
            f"Address saved.\n\n"
            f"*Step 4 of 7 - State*\n"
            f"Select your state of residence:\n\n"
            f"{STATE_LIST_MSG}\n\n"
            f"Reply with the number.")

    # STEP 5: State
    elif step == 5:
        state = None
        if msg.strip().isdigit():
            idx = int(msg.strip()) - 1
            if 0 <= idx < len(NIGERIAN_STATES):
                state = NIGERIAN_STATES[idx]
        else:
            for s in NIGERIAN_STATES:
                if msg.strip().lower() in s.lower():
                    state = s
                    break
        if not state:
            send_message(phone,
                f"Invalid selection. Reply with a number (1-{len(NIGERIAN_STATES)}).\n\n"
                f"{STATE_LIST_MSG}")
            return
        _save_session(session["session_id"], {"step": 6, "state": state})
        send_message(phone,
            f"State: *{state}*\n\n"
            f"*Step 5 of 7 - Bank*\n"
            f"Select your bank:\n\n"
            f"{BANK_LIST_MSG}\n\n"
            f"Reply with the number.")

    # STEP 6: Bank selection
    elif step == 6:
        bank = get_bank_code(msg.strip())
        if not bank:
            send_message(phone,
                f"Invalid selection. Reply with a number (1-{len(BANKS)}).\n\n"
                f"{BANK_LIST_MSG}")
            return
        _save_session(session["session_id"], {
            "step": 7,
            "bank_name": bank["name"],
            "bank_code": bank["code"]
        })
        send_message(phone,
            f"Bank: *{bank['name']}*\n\n"
            f"*Step 6 of 7 - Account Number*\n"
            f"Enter your 10-digit {bank['name']} account number.")

    # STEP 7: Account number + Paystack resolve
    elif step == 7:
        acc = msg.strip().replace(" ", "")
        if not acc.isdigit() or len(acc) != 10:
            send_message(phone,
                "Account number must be exactly *10 digits*. Please try again.")
            return
        attempts = (session.get("bank_verification_attempts") or 0) + 1
        result = _resolve_bank_account(acc, str(session.get("bank_code", "")))
        if not result["valid"]:
            if attempts >= MAX_BANK_ATTEMPTS:
                _save_session(session["session_id"], {
                    "bank_verification_attempts": attempts, "step": 6
                })
                send_message(phone,
                    f"Could not verify account after 3 attempts.\n"
                    f"Let's try a different bank.\n\n"
                    f"*Select your bank:*\n\n{BANK_LIST_MSG}")
                return
            _save_session(session["session_id"], {
                "bank_verification_attempts": attempts,
                "account_number": acc
            })
            send_message(phone,
                f"Could not verify that account number with {session.get('bank_name')}.\n"
                f"Please check and try again. "
                f"({MAX_BANK_ATTEMPTS - attempts} attempt(s) remaining)")
            return
        _save_session(session["session_id"], {
            "step": 8,
            "account_number": acc,
            "bank_account_name": result["account_name"],
            "bank_verification_attempts": attempts,
            "bank_verification_status": "VERIFIED"
        })
        send_message(phone,
            f"Account verified!\n\n"
            f"Account name: *{result['account_name']}*\n"
            f"Bank: *{session.get('bank_name')}*\n\n"
            f"Is this correct? Reply *YES* to continue or *NO* to re-enter.")

    # STEP 8: Bank confirmation
    elif step == 8:
        if msg.upper() == "YES":
            _save_session(session["session_id"], {"step": 9})
            send_message(phone, TC_TEXT)
        elif msg.upper() == "NO":
            _save_session(session["session_id"], {
                "step": 6, "bank_verification_attempts": 0
            })
            send_message(phone,
                f"Let's try again.\n\n*Select your bank:*\n\n{BANK_LIST_MSG}")
        else:
            send_message(phone,
                "Reply *YES* to confirm or *NO* to re-enter your bank details.")

    # STEP 9: T&C acceptance
    elif step == 9:
        if msg.upper() == "ACCEPT":
            try:
                validator_id = _complete_registration(session, phone)
                first = session.get("first_name") or session.get("full_name", "").split()[0]
                market = session.get("invite_code_market_name", "your market")
                send_message(phone,
                    f"*Welcome to NaijaMarket Intel, {first}!*\n\n"
                    f"Your validator ID: *{validator_id}*\n"
                    f"Assigned market: *{market}*\n\n"
                    f"Your account is under review. You will receive a message "
                    f"within 24 hours once approved.\n\n"
                    f"After approval, type *menu* to access your validator dashboard.")
            except Exception as e:
                logging.error(f"[validator_reg] complete error: {e}", exc_info=True)
                send_message(phone,
                    "Registration saved but we hit a technical issue finalising your account. "
                    "Our team will complete your setup within 24 hours.")
        elif msg.upper() == "CANCEL":
            _save_session(session["session_id"], {"status": "ABANDONED"})
            send_message(phone,
                "Registration cancelled. Send *VAL-START* to begin again.")
        else:
            send_message(phone, TC_TEXT)
