import logging
from shared.db import get_connection
from shared.sender import send_message
from shared.session import save_session, clear_session
from shared.lang import get_lang
from shared.i18n import t
from consumer.menu import show_main_menu

def handle_history(phone, message="", session=None, consumer=None, *args):
    session=session or {}; consumer=consumer or {}
    lang=get_lang(session,consumer)
    msg=(message or "").strip().lower()
    clear_session(phone)

    # Re-run a previous search
    if msg.isdigit() and session.get("_flow")=="HISTORY":
        _rerun(phone, int(msg), session, lang, consumer)
        return

    _show(phone, lang, session, consumer)

def _show(phone, lang, session, consumer):
    try:
        conn=get_connection(); cur=conn.cursor()
        cur.execute(
            "SELECT TOP 5 item_name, market_name, query_timestamp "
            "FROM dbo.Query_Log "
            "WHERE consumer_phone=%s AND item_name!='' "
            "ORDER BY query_timestamp DESC",
            (phone,))
        rows=cur.fetchall(); conn.close()
        if not rows:
            send_message(phone,t(lang,"history_empty")); return
        lines=[]
        items=[]
        for i,r in enumerate(rows):
            item=r["item_name"]; mkt=r.get("market_name") or ""
            ts=str(r.get("query_timestamp") or "")[:10]
            label=f"{item}" + (f" @ {mkt}" if mkt else "")
            lines.append(f"*{i+1}* {label} _({ts})_")
            items.append({"item":item,"market":mkt})
        body="\n".join(lines)
        session.update({"_flow":"HISTORY","_history_items":items,"step":1})
        save_session(phone,session)
        send_message(phone,t(lang,"history_list",body=body))
    except Exception as e:
        logging.error(f"[history._show] {e}"); send_message(phone,t(lang,"error_generic"))

def _rerun(phone, idx, session, lang, consumer):
    items=session.get("_history_items",[])
    if not items or idx<1 or idx>len(items):
        send_message(phone,t(lang,"invalid_choice")); return
    item=items[idx-1]
    clear_session(phone)
    # Route to trend flow with item pre-filled
    try:
        import importlib
        new_session={"_flow":"TREND","step":1}
        save_session(phone,new_session)
        importlib.import_module("consumer.trend").handle_trend(
            phone, item["item"], new_session, consumer)
    except Exception as e:
        logging.error(f"[history._rerun] {e}"); send_message(phone,t(lang,"error_generic"))
