import logging
TIER_ORDER=["FREE","SILVER","GOLD","BUSINESS","CORPORATE","ENTERPRISE"]
from shared.db import get_connection
from shared.query_limit import log_query
from shared.sender import send_message
from shared.session import save_session, clear_session
from shared.lang import get_lang
from shared.i18n import t
from consumer.menu import show_main_menu
from shared.nudge import get_nudge

def handle_forecast(phone, message="", session=None, consumer=None, *args):
    session=session or {}; consumer=consumer or {}
    lang=get_lang(session,consumer); text=(message or "").strip(); msg=text.lower()
    tier=((consumer or {}).get("subscription_tier") or "FREE").upper()
    step=session.get("step",0)
    if msg in ("0","menu","back"): clear_session(phone); show_main_menu(phone); return
    if TIER_ORDER.index(tier)<TIER_ORDER.index("GOLD"): clear_session(phone); send_message(phone,t(lang,"forecast_locked")); return
    if step==0:
        session.update({"_flow":"FORECAST","step":1}); save_session(phone,session)
        send_message(phone,t(lang,"forecast_title"))
    elif step==1:
        _show(phone,text,lang,session)
    elif step==99:
        _handle_repeat_search(phone,text,session,lang,consumer)

def _show(phone,query,lang,session):
    try:
        conn=get_connection(); cur=conn.cursor()
        cur.execute("SELECT TOP 1 item_name,AVG(price_naira) AS now,AVG(price_change_pct) AS trend_pct FROM dbo.Latest_Prices_Summary WHERE item_name LIKE %s AND is_nbs_ref=0 AND is_food=1 AND price_naira>0 GROUP BY item_name",(f"%{query}%",))
        row=cur.fetchone(); conn.close()
        if not row: send_message(phone,t(lang,"not_found",q=query)); return
        item=row["item_name"]; now=float(row["now"] or 0); pct=float(row["trend_pct"] or 0)
        wk1=now*(1+pct/100); wk2=wk1*(1+pct/100); mo1=now*(1+pct/100)**4
        direction=("rising" if lang=="en" else "go up") if pct>0.5 else (("falling" if lang=="en" else "come down") if pct<-0.5 else "stable")
        arrow="\U0001f4c8" if pct>0.5 else ("\U0001f4c9" if pct<-0.5 else "\u27a1\ufe0f")
        session.update({"step":99,"_last_query":query}); save_session(phone,session)
        log_query(phone,{},""+item,"")
        send_message(phone,t(lang,"forecast_result",item=item,now=now,arrow=arrow,direction=direction,wk1=wk1,wk2=wk2,mo1=mo1,pct=pct)+get_nudge(lang,"FORECAST"))
    except Exception as e:
        logging.error(f"[forecast] {e}")
        session["step"] = 1; save_session(phone, session)
        send_message(phone, t(lang, "error_retry_search"))

def _handle_repeat_search(phone,text,session,lang,consumer):
    msg=text.strip().lower()
    if msg in ("0","menu","back"): clear_session(phone); show_main_menu(phone); return
    if msg=="1" or msg=="forecast":
        session["step"]=0; save_session(phone,session)
        handle_forecast(phone,"",session,consumer); return
    # treat any other text as a new commodity search
    _show(phone,text,lang,session)
