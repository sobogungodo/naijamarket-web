import logging
from shared.db import get_connection
from shared.nbs_compare import get_nbs_comparison
from shared.query_limit import log_query
from shared.sender import send_message
from shared.session import save_session, clear_session
from shared.lang import get_lang
from shared.i18n import t
from consumer.menu import show_main_menu
from shared.nudge import get_nudge

def handle_trend(phone, message="", session=None, consumer=None, *args):
    session=session or {}; consumer=consumer or {}
    lang=get_lang(session,consumer); text=(message or "").strip(); msg=text.lower()
    step=session.get("step",0)
    if msg in ("0","menu","back"): clear_session(phone); show_main_menu(phone); return
    if step==0:
        session.update({"_flow":"TREND","step":1}); save_session(phone,session)
        send_message(phone,t(lang,"trend_title"))
    elif step==1: _show(phone,text,lang,session)
    elif step==99: _handle_repeat_search(phone,text,session,lang,consumer)

def _show(phone,query,lang,session):
    try:
        conn=get_connection(); cur=conn.cursor()
        cur.execute("SELECT TOP 1 item_name FROM dbo.Latest_Prices_Summary WHERE item_name LIKE %s AND is_nbs_ref=0 AND is_food=1 GROUP BY item_name ORDER BY item_name",(f"%{query}%",))
        row=cur.fetchone()
        if not row: conn.close(); send_message(phone,t(lang,"not_found",q=query)); return
        item_name=row["item_name"]
        cur.execute("SELECT price_date,AVG(price_naira) AS avg_p,MIN(price_naira) AS min_p,MAX(price_naira) AS max_p,COUNT(DISTINCT market_id) AS mkts FROM dbo.Latest_Prices_Summary WHERE item_name=%s AND is_nbs_ref=0 AND is_food=1 GROUP BY price_date ORDER BY price_date DESC",(item_name,))
        rows=cur.fetchall(); conn.close()
        if not rows: send_message(phone,t(lang,"error_generic")); return
        lines="\n".join(f"\U0001f4c5 {str(r['price_date'])[:10]}: *\u20a6{float(r['avg_p']):,.0f}* (\u20a6{float(r['min_p']):,.0f}\u2013\u20a6{float(r['max_p']):,.0f})" for r in rows[:6])
        session.update({"step":99,"_last_query":query}); save_session(phone,session)
        _repeat="\n\n━━━━━━━━━━━━━━━━━━━━━━\n*1* — Search again\n*0* — Menu"
        log_query(phone,{},""+item_name,"")
        nbs_note=get_nbs_comparison(item_name,float(rows[0]["avg_p"] or 0),lang)
        send_message(phone,t(lang,"trend_result",item=item_name,lines=lines,mkts=rows[0]["mkts"])+nbs_note+_repeat+get_nudge(lang,"TREND"))
    except Exception as e:
        logging.error(f"[trend] {e}")
        session["step"] = 1; save_session(phone, session)
        send_message(phone, t(lang, "error_retry_search"))

def _handle_repeat_search(phone,text,session,lang,consumer):
    msg=text.strip().lower()
    if msg in ("0","menu","back"): clear_session(phone); show_main_menu(phone); return
    if msg=="1" or msg=="trend":
        session["step"]=0; save_session(phone,session)
        handle_trend(phone,"",session,consumer); return
    _show(phone,text,lang,session)
