from shared.sender import send_message
from shared.db import get_consumer
from shared.lang import get_lang
from shared.i18n import t

def show_main_menu(phone: str):
    consumer = get_consumer(phone) or {}
    tier  = (consumer.get("subscription_tier") or "FREE").upper()
    last4 = (consumer.get("phone_number") or consumer.get("phone") or phone)[-4:]
    lang  = get_lang({}, consumer)
    send_message(phone, t(lang, "menu_header", tier=tier, last4=last4))
