"""
consumer/downgrade.py — NaijaMarket Intel
==========================================
Handles subscription downgrade requests.

Rules:
  - Downgrade takes effect at END of current billing period
  - No refunds for remaining period (enforced in messaging)
  - User can cancel a pending downgrade before it takes effect
  - FREE is always available as downgrade target
  - Cannot downgrade to same or higher tier (use upgrade flow)
  - Scheduled downgrades stored in Consumers.pending_downgrade_tier
    + Consumers.downgrade_effective_date

DB columns used (confirmed live schema):
  Consumers: subscription_tier, subscription_end_date,
             pending_downgrade_tier, downgrade_effective_date,
             grace_period_end, phone, phone_number, consumer_id
"""

import logging
from datetime import datetime, timezone
from shared.sender import send_message
from shared.session import save_session, clear_session
from shared.db import get_connection
from consumer.menu import show_main_menu

# Tier order — lower index = lower tier
TIER_ORDER = ['FREE', 'SILVER', 'GOLD', 'BUSINESS', 'CORPORATE', 'ENTERPRISE']

TIER_INFO = {
    'FREE':       {'label': '🆓 FREE',        'price': '₦0'},
    'SILVER':     {'label': '🥈 SILVER',       'price': '₦500/week'},
    'GOLD':       {'label': '🥇 GOLD',         'price': '₦2,000/month'},
    'BUSINESS':   {'label': '💼 BUSINESS',     'price': '₦15,000/month'},
    'CORPORATE':  {'label': '🏢 CORPORATE',    'price': '₦50,000/month'},
    'ENTERPRISE': {'label': '🏆 ENTERPRISE',   'price': '₦150,000/month'},
}


def _fmt_date(d) -> str:
    """Format a date/datetime for display."""
    if not d:
        return 'N/A'
    if isinstance(d, str):
        return d[:10]
    return str(d)[:10]


def _get_consumer(phone: str) -> dict | None:
    """Fetch consumer record by phone."""
    conn = get_connection()
    try:
        cur = conn.cursor(as_dict=True)
        cur.execute("""
            SELECT consumer_id, phone, phone_number,
                   subscription_tier, subscription_end_date,
                   pending_downgrade_tier, downgrade_effective_date,
                   grace_period_end
            FROM dbo.Consumers
            WHERE phone = %s OR phone_number = %s
        """, (phone, phone))
        return cur.fetchone()
    finally:
        conn.close()


def _available_downgrades(current_tier: str) -> list:
    """Return list of tiers the user can downgrade to."""
    if current_tier not in TIER_ORDER:
        return ['FREE']
    idx = TIER_ORDER.index(current_tier)
    return TIER_ORDER[:idx]  # all tiers below current


def handle_downgrade(phone: str, text: str, session: dict) -> None:
    """Main entry point for the downgrade flow."""
    step = session.get('_step', '')
    text = text.strip().lower()

    # ── Entry point ────────────────────────────────────────────────────────
    if not step:
        _show_downgrade_menu(phone, session)
        return

    # ── Tier selection ─────────────────────────────────────────────────────
    if step == 'await_tier':
        if text == '0' or text == 'menu':
            clear_session(phone)
            show_main_menu(phone)
            return
        if text == 'cancel-downgrade':
            _cancel_pending_downgrade(phone)
            return
        _handle_tier_selection(phone, text, session)
        return

    # ── Confirmation ───────────────────────────────────────────────────────
    if step == 'await_confirm':
        if text == 'confirm':
            _execute_downgrade_schedule(phone, session)
        elif text in ('cancel', '0', 'menu', 'back'):
            clear_session(phone)
            send_message(phone,
                "↩️ Downgrade cancelled.\n\n"
                "Your current subscription remains unchanged.\n\n"
                "_Type *menu* to go back_"
            )
        else:
            send_message(phone,
                "⚠️ Please reply *confirm* to schedule the downgrade\n"
                "or *cancel* to keep your current plan."
            )
        return

    # Fallback
    clear_session(phone)
    show_main_menu(phone)


def _show_downgrade_menu(phone: str, session: dict) -> None:
    """Show available downgrade tiers."""
    consumer = _get_consumer(phone)
    if not consumer:
        send_message(phone, "❌ Account not found. Type *menu* to go back.")
        return

    current_tier = (consumer.get('subscription_tier') or 'FREE').upper()
    end_date = _fmt_date(consumer.get('subscription_end_date'))
    pending = consumer.get('pending_downgrade_tier')
    effective = _fmt_date(consumer.get('downgrade_effective_date'))

    available = _available_downgrades(current_tier)

    if not available:
        send_message(phone,
            "ℹ️ You are already on the *FREE* plan.\n\n"
            "There are no lower tiers to downgrade to.\n\n"
            "_Type *menu* to go back_"
        )
        return

    msg = "📉 *DOWNGRADE SUBSCRIPTION*\n"
    msg += "─────────────────────────\n\n"
    msg += f"Current Plan: *{current_tier}*\n"
    if end_date != 'N/A':
        msg += f"Expires: *{end_date}*\n"
    msg += "\n"

    # Show any existing pending downgrade
    if pending:
        msg += f"⚠️ Pending downgrade to *{pending}* on {effective}\n"
        msg += "Type *cancel-downgrade* to cancel this\n\n"

    msg += "📊 *Available lower tiers:*\n\n"
    for i, tier in enumerate(reversed(available), 1):
        info = TIER_INFO.get(tier, {})
        msg += f"*{i}*. {info.get('label', tier)} — {info.get('price', '')}\n"

    msg += f"\n*0* — Back to menu\n"
    msg += "\n⚠️ *Downgrade Policy:*\n"
    msg += "Your current plan continues until the end of your billing period. "
    msg += "No refunds are issued for unused time.\n\n"
    msg += "Reply with a number to select a tier."

    session['_flow'] = 'downgrade'
    session['_step'] = 'await_tier'
    session['_available'] = available
    session['_current_tier'] = current_tier
    session['_end_date'] = end_date
    save_session(phone, session)
    send_message(phone, msg)


def _handle_tier_selection(phone: str, text: str, session: dict) -> None:
    """Process tier number selection."""
    available = session.get('_available', [])
    # User picks from reversed list (highest first)
    reversed_available = list(reversed(available))

    try:
        idx = int(text) - 1
        if idx < 0 or idx >= len(reversed_available):
            raise ValueError()
        target_tier = reversed_available[idx]
    except (ValueError, IndexError):
        send_message(phone,
            f"❌ Invalid selection. Please enter a number between 1 and {len(available)}.\n"
            "Or type *0* to go back."
        )
        return

    current_tier = session.get('_current_tier', 'FREE')
    end_date = session.get('_end_date', 'N/A')
    info = TIER_INFO.get(target_tier, {})

    msg = "⚠️ *CONFIRM DOWNGRADE*\n"
    msg += "─────────────────────────\n\n"
    msg += f"📉 From: *{current_tier}*\n"
    msg += f"📊 To: *{target_tier}* — {info.get('price', '')}\n\n"
    msg += f"📅 Your *{current_tier}* benefits continue until:\n"
    msg += f"   *{end_date}*\n\n"
    msg += f"After that date, you will be moved to *{target_tier}*.\n\n"
    msg += "⚠️ *No refunds will be issued for the remaining period.*\n"
    msg += "This is in line with our Terms & Conditions.\n\n"
    msg += "Reply *confirm* to schedule the downgrade\n"
    msg += "Reply *cancel* to keep your current plan\n"
    msg += "Reply *back* to choose a different tier"

    session['_step'] = 'await_confirm'
    session['_target_tier'] = target_tier
    save_session(phone, session)
    send_message(phone, msg)


def _execute_downgrade_schedule(phone: str, session: dict) -> None:
    """Write the pending downgrade to the DB."""
    target_tier = session.get('_target_tier', 'FREE')
    current_tier = session.get('_current_tier', 'FREE')
    end_date = session.get('_end_date', 'N/A')

    consumer = _get_consumer(phone)
    if not consumer:
        send_message(phone, "❌ Account not found. Type *menu* to go back.")
        return

    # Use subscription_end_date as the effective date
    effective_date = consumer.get('subscription_end_date')

    conn = get_connection()
    try:
        cur = conn.cursor()
        cur.execute("""
            UPDATE dbo.Consumers
            SET pending_downgrade_tier   = %s,
                downgrade_effective_date = %s
            WHERE phone = %s OR phone_number = %s
        """, (
            target_tier,
            effective_date,
            phone, phone
        ))
        conn.commit()
        cur.close()
    except Exception as e:
        logging.error(f"[downgrade] DB update failed: {e}")
        send_message(phone,
            "❌ Could not schedule downgrade. Please try again or contact support.\n\n"
            "_Type *menu* to go back_"
        )
        return
    finally:
        conn.close()

    clear_session(phone)

    info = TIER_INFO.get(target_tier, {})
    msg = "✅ *DOWNGRADE SCHEDULED*\n"
    msg += "─────────────────────────\n\n"
    msg += f"📉 From: *{current_tier}*\n"
    msg += f"📊 To: *{target_tier}* — {info.get('price', '')}\n"
    msg += f"📅 Effective: *{end_date}*\n\n"
    msg += f"Your *{current_tier}* benefits remain active until the effective date.\n\n"
    msg += "💡 Changed your mind?\n"
    msg += "Type *cancel-downgrade* before the effective date to keep your current plan.\n\n"
    msg += "_Type *menu* to go back_"

    send_message(phone, msg)


def _cancel_pending_downgrade(phone: str) -> None:
    """Cancel a scheduled downgrade."""
    consumer = _get_consumer(phone)
    if not consumer:
        send_message(phone, "❌ Account not found.")
        return

    pending = consumer.get('pending_downgrade_tier')
    if not pending:
        send_message(phone,
            "ℹ️ You have no pending downgrade to cancel.\n\n"
            "_Type *menu* to go back_"
        )
        return

    conn = get_connection()
    try:
        cur = conn.cursor()
        cur.execute("""
            UPDATE dbo.Consumers
            SET pending_downgrade_tier   = NULL,
                downgrade_effective_date = NULL
            WHERE phone = %s OR phone_number = %s
        """, (phone, phone))
        conn.commit()
        cur.close()
    except Exception as e:
        logging.error(f"[downgrade] Cancel failed: {e}")
        send_message(phone, "❌ Could not cancel downgrade. Please try again.")
        return
    finally:
        conn.close()

    current_tier = (consumer.get('subscription_tier') or 'FREE').upper()
    msg = "✅ *DOWNGRADE CANCELLED*\n\n"
    msg += f"You will remain on *{current_tier}* after your current billing period.\n\n"
    msg += "_Type *menu* to go back_"
    send_message(phone, msg)
