import logging,os,requests,uuid
TIER_ORDER=["FREE","SILVER","GOLD","BUSINESS","CORPORATE","ENTERPRISE"]
TIERS={"SILVER":{"price":500,"label":"\U0001f948 SILVER","days":7},"GOLD":{"price":2000,"label":"\U0001f947 GOLD","days":30},"BUSINESS":{"price":15000,"label":"\U0001f4bc BUSINESS","days":30},"CORPORATE":{"price":500000,"label":"\U0001f3e2 CORPORATE","days":30},"ENTERPRISE":{"price":1500000,"label":"\U0001f3c6 ENTERPRISE","days":30},"API_STARTER":{"price":500000,"label":"\U0001f4e1 API STARTER","days":30},"API_BUSINESS":{"price":1000000,"label":"\U0001f4e1 API BUSINESS","days":30},"API_ENTERPRISE":{"price":1500000,"label":"\U0001f4e1 API ENTERPRISE","days":30}}
from shared.sender import send_message
from shared.session import save_session, clear_session
from shared.lang import get_lang
from shared.i18n import t
from consumer.menu import show_main_menu

def handle_tokens_flow(phone, message="", session=None, consumer=None, *args):
    session=session or {}; consumer=consumer or {}
    lang=get_lang(session,consumer); text=(message or "").strip(); msg=text.lower()
    step=session.get("step",0)
    if msg in ("0","menu") or (msg=="back" and step==0): clear_session(phone); show_main_menu(phone); return
    if msg=="back" and step==1: session["step"]=0; save_session(phone,session); _menu(phone,session,consumer,lang); return
    if step==0: _menu(phone,session,consumer,lang)
    elif step==1: _pick(phone,text,session,consumer,lang)

def _menu(phone,session,consumer,lang):
    cur_tier=((consumer or {}).get("subscription_tier") or "FREE").upper()
    cur_idx=TIER_ORDER.index(cur_tier) if cur_tier in TIER_ORDER else 0
    available=TIER_ORDER[cur_idx+1:] if cur_idx<len(TIER_ORDER)-1 else []
    if not available: clear_session(phone); send_message(phone,t(lang,"upgrade_top")); return
    lines="\n".join(f"*{i+1}*. {TIERS.get(t2,{}).get('label',t2)} — \u20a6{TIERS.get(t2,{}).get('price',0):,}" for i,t2 in enumerate(available))
    session.update({"_flow":"TOKENS","step":1,"cur_tier":cur_tier,"available":available}); save_session(phone,session)
    send_message(phone,t(lang,"upgrade_menu",tier=cur_tier,lines=lines))

def _pick(phone,text,session,consumer,lang):
    available=session.get("available",[])
    try:
        idx=int(text)-1; assert 0<=idx<len(available); tier=available[idx]
    except: send_message(phone,t(lang,"invalid_choice")); return
    cfg=TIERS.get(tier,{})
    secret=os.environ.get("PAYSTACK_SECRET_KEY","")
    if not secret:
        clear_session(phone); send_message(phone,f"\U0001f4b3 {cfg.get('label',tier)}\n\nAmount: \u20a6{cfg.get('price',0):,}\n\nVisit: naijamarketintel.ng/subscribe\n\n*menu* — Menu"); return
    try:
        cid=(consumer or {}).get("consumer_id","")
        ref=f"NMI-{tier[:3].upper()}-{uuid.uuid4().hex[:8].upper()}"
        email=(consumer or {}).get("email") or f"{phone}@naijamarketintel.ng"
        resp=requests.post("https://api.paystack.co/transaction/initialize",headers={"Authorization":f"Bearer {secret}"},json={"email":email,"amount":cfg["price"]*100,"reference":ref,"metadata":{"phone":phone,"tier":tier,"consumer_id":cid}},timeout=15)
        data=resp.json()
        if data.get("status") and data.get("data",{}).get("authorization_url"):
            url=data["data"]["authorization_url"]
            send_message(phone,t(lang,"upgrade_link",label=cfg.get("label",tier),price=cfg.get("price",0),ref=ref,url=url))
        else: raise Exception(data.get("message",""))
    except Exception as e:
        logging.error(f"[tokens] {e}"); clear_session(phone)
        send_message(phone,f"\u26a0\ufe0f Could not generate payment link.\n\nVisit naijamarketintel.ng/subscribe\n\n*menu* — Menu")
