"""
shared/unregistered.py — State management for unregistered users.
Uses Unregistered_Exit_Log only. Never touches Consumer_Query_Sessions.
"""
import logging
import json
from datetime import datetime, timezone, timedelta
from shared.db import get_connection

MAX_EXITS    = 4
BLOCK_DAYS   = 3


def get_unreg_record(phone: str) -> dict:
    """Fetch record for this phone. Returns {} if not found."""
    try:
        clean = phone.replace("+", "").strip()
        conn  = get_connection()
        cur   = conn.cursor(as_dict=True)
        cur.execute(
            "SELECT phone_number, exit_count, last_exit_at, blocked_until, current_step, step_data "
            "FROM dbo.Unregistered_Exit_Log WHERE phone_number=%s",
            (clean,)
        )
        row = cur.fetchone()
        conn.close()
        return row or {}
    except Exception as e:
        logging.error(f"[unreg] get_unreg_record error: {e}")
        return {}


def is_blocked(phone: str) -> tuple[bool, str]:
    """Returns (blocked, message). Checks blocked_until."""
    rec = get_unreg_record(phone)
    if not rec:
        return False, ""
    blocked_until = rec.get("blocked_until")
    if not blocked_until:
        return False, ""
    now = datetime.now(timezone.utc)
    if hasattr(blocked_until, "tzinfo") and blocked_until.tzinfo is None:
        blocked_until = blocked_until.replace(tzinfo=timezone.utc)
    if now < blocked_until:
        until_str = blocked_until.strftime("%d %b %Y, %I:%M %p UTC")
        return True, (
            f"\U0001f6ab Your number has been temporarily blocked for {BLOCK_DAYS} days "
            f"due to repeated exits without registering.\n\n"
            f"Please try again after *{until_str}*."
        )
    return False, ""


def get_step(phone: str) -> tuple[str, dict]:
    """Returns (current_step, step_data_dict) for unregistered user."""
    rec = get_unreg_record(phone)
    step      = rec.get("current_step") or "WELCOME"
    step_data = {}
    raw = rec.get("step_data")
    if raw:
        try:
            step_data = json.loads(raw)
        except Exception:
            step_data = {}
    return step, step_data


def save_step(phone: str, step: str, step_data: dict = None):
    """Save current welcome step to Unregistered_Exit_Log."""
    try:
        clean     = phone.replace("+", "").strip()
        data_json = json.dumps(step_data or {})
        conn      = get_connection()
        cur       = conn.cursor(as_dict=True)
        cur.execute(
            "SELECT phone_number FROM dbo.Unregistered_Exit_Log WHERE phone_number=%s",
            (clean,)
        )
        exists = cur.fetchone()
        if exists:
            cur.execute(
                "UPDATE dbo.Unregistered_Exit_Log "
                "SET current_step=%s, step_data=%s "
                "WHERE phone_number=%s",
                (step, data_json, clean)
            )
        else:
            cur.execute(
                "INSERT INTO dbo.Unregistered_Exit_Log "
                "(phone_number, exit_count, current_step, step_data) "
                "VALUES (%s, 0, %s, %s)",
                (clean, step, data_json)
            )
        conn.commit()
        conn.close()
    except Exception as e:
        logging.error(f"[unreg] save_step error: {e}")


def record_exit(phone: str) -> tuple[bool, str]:
    """
    Increment exit count. If >= MAX_EXITS, block for BLOCK_DAYS.
    Returns (blocked, message_to_send).
    """
    try:
        clean = phone.replace("+", "").strip()
        conn  = get_connection()
        cur   = conn.cursor(as_dict=True)
        cur.execute(
            "SELECT exit_count FROM dbo.Unregistered_Exit_Log WHERE phone_number=%s",
            (clean,)
        )
        row   = cur.fetchone()
        count = (row.get("exit_count") or 0) + 1 if row else 1
        now   = datetime.now(timezone.utc)

        if count >= MAX_EXITS:
            blocked_until = now + timedelta(days=BLOCK_DAYS)
            until_str     = blocked_until.strftime("%d %b %Y")
            if row:
                cur.execute(
                    "UPDATE dbo.Unregistered_Exit_Log "
                    "SET exit_count=%s, last_exit_at=%s, blocked_until=%s, current_step='BLOCKED', step_data='{}' "
                    "WHERE phone_number=%s",
                    (count, now, blocked_until, clean)
                )
            else:
                cur.execute(
                    "INSERT INTO dbo.Unregistered_Exit_Log "
                    "(phone_number, exit_count, last_exit_at, blocked_until, current_step, step_data) "
                    "VALUES (%s, %s, %s, %s, 'BLOCKED', '{}')",
                    (clean, count, now, blocked_until)
                )
            conn.commit()
            conn.close()
            return True, (
                f"\U0001f6ab You have exited {count} times without registering.\n\n"
                f"Your number has been blocked for *{BLOCK_DAYS} days* (until {until_str}).\n\n"
                f"We hope to see you back. NaijaMarket Intel gives you real-time food prices "
                f"from 282 markets across Nigeria — completely free."
            )
        else:
            remaining = MAX_EXITS - count
            if row:
                cur.execute(
                    "UPDATE dbo.Unregistered_Exit_Log "
                    "SET exit_count=%s, last_exit_at=%s, current_step='WELCOME', step_data='{}' "
                    "WHERE phone_number=%s",
                    (count, now, clean)
                )
            else:
                cur.execute(
                    "INSERT INTO dbo.Unregistered_Exit_Log "
                    "(phone_number, exit_count, last_exit_at, current_step, step_data) "
                    "VALUES (%s, %s, %s, 'WELCOME', '{}')",
                    (clean, count, now)
                )
            conn.commit()
            conn.close()
            return False, (
                f"Thanks for visiting NaijaMarket Intel. \U0001f1f3\U0001f1ec\n\n"
                f"We hope you come back to register — it's free and takes 30 seconds.\n\n"
                f"Type *1* anytime to join and access real-time food prices from 282 markets."
            )
    except Exception as e:
        logging.error(f"[unreg] record_exit error: {e}")
        return False, "Thanks for visiting. Type *1* to register anytime."


def clear_unreg(phone: str):
    """Called after successful registration — clear the exit log entry."""
    try:
        clean = phone.replace("+", "").strip()
        conn  = get_connection()
        cur   = conn.cursor()
        cur.execute(
            "DELETE FROM dbo.Unregistered_Exit_Log WHERE phone_number=%s",
            (clean,)
        )
        conn.commit()
        conn.close()
    except Exception as e:
        logging.error(f"[unreg] clear_unreg error: {e}")
