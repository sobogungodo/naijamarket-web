def handle_kyc(phone, message="", session=None, *args):
    from shared.sender import send_message
    send_message(phone, "Trader kyc — coming back online. Type *menu* to go back.")
