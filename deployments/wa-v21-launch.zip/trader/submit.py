def handle_submit(phone, message="", session=None, *args):
    from shared.sender import send_message
    send_message(phone, "Trader submit — coming back online. Type *menu* to go back.")
