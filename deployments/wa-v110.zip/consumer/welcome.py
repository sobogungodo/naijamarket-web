"""
consumer/welcome.py - First-touch welcome flow with name + age collection
"""
import logging
import uuid
from shared.db      import get_connection
from shared.sender  import send_message
from shared.session import clear_session
from shared.lang    import set_lang
from shared.i18n    import t
from shared.optin        import record_optin
from shared.unregistered import get_step, save_step, record_exit, clear_unreg, is_blocked

AGE_RANGES = {
    "1": "Under 25",
    "2": "25-34",
    "3": "35-44",
    "4": "45-54",
    "5": "55 and above"
}

GENDERS = {
    "1": "Male",
    "2": "Female",
    "3": "Prefer not to say"
}

NIGERIAN_STATES = {
    "1": "Abia", "2": "Adamawa", "3": "Akwa Ibom", "4": "Anambra",
    "5": "Bauchi", "6": "Bayelsa", "7": "Benue", "8": "Borno",
    "9": "Cross River", "10": "Delta", "11": "Ebonyi", "12": "Edo",
    "13": "Ekiti", "14": "Enugu", "15": "FCT Abuja", "16": "Gombe",
    "17": "Imo", "18": "Jigawa", "19": "Kaduna", "20": "Kano",
    "21": "Katsina", "22": "Kebbi", "23": "Kogi", "24": "Kwara",
    "25": "Lagos", "26": "Nasarawa", "27": "Niger", "28": "Ogun",
    "29": "Ondo", "30": "Osun", "31": "Oyo", "32": "Plateau",
    "33": "Rivers", "34": "Sokoto", "35": "Taraba", "36": "Yobe",
    "37": "Zamfara"
}

def _get_sample_prices():
    try:
        conn = get_connection()
        cur  = conn.cursor()
        cur.execute("""
            SELECT TOP 3 item_name, price_naira, unit, trend
            FROM dbo.Latest_Prices_Summary
            WHERE state = 'Lagos'
              AND is_nbs_ref = 0
              AND is_food    = 1
              AND price_naira > 0
            ORDER BY NEWID()
        """)
        rows = cur.fetchall()
        conn.close()
        if not rows:
            return "Rice 50kg - N54,000\nBeans Brown - N98,000\nTomatoes (basket) - N35,000"
        lines = []
        for r in rows:
            lines.append(f"- {r['item_name']}: N{float(r['price_naira']):,.0f}/{r.get('unit','unit')}")
        return "\n".join(lines)
    except Exception as e:
        logging.warning(f"[welcome] sample prices error: {e}")
        return "Rice 50kg - N54,000\nBeans Brown - N98,000\nTomatoes (basket) - N35,000"

def _create_consumer(phone, lang, full_name, age_range, gender="", state="", referrer_phone=""):
    clean      = phone.replace("+", "").strip()
    phone_plus = f"+{clean}"
    first_name = full_name.strip().split()[0] if full_name.strip() else full_name.strip()
    consumer_id = str(uuid.uuid4())

    conn = None
    try:
        conn = get_connection()
        cur  = conn.cursor()

        # Check if already exists
        cur.execute(
            "SELECT COUNT(*) as cnt FROM dbo.Consumers WHERE phone = %s OR phone_number = %s",
            (clean, phone_plus)
        )
        row = cur.fetchone()
        exists = (row.get('cnt', 0) if isinstance(row, dict) else row[0]) > 0

        if not exists:
            cur.execute(
                """INSERT INTO dbo.Consumers (
                    consumer_id, phone, phone_number,
                    first_name, full_name, age_range,
                    gender, state,
                    preferred_language, subscription_tier,
                    referral_code, referred_by,
                    account_status, created_at
                ) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, 'FREE', %s, %s, 'ACTIVE', GETUTCDATE())""",
                (consumer_id, clean, phone_plus,
                 first_name, full_name.strip(), age_range,
                 gender, state, lang,
                 str(consumer_id).replace("-","")[:8].upper(),
                 referrer_phone)
            )
            logging.info(f"[welcome] Consumers INSERT done for {phone_plus}")
        else:
            logging.info(f"[welcome] Consumers already exists for {phone_plus}")

        # Check User_Roles
        cur.execute(
            "SELECT COUNT(*) as cnt FROM dbo.User_Roles WHERE phone_number = %s OR phone_number = %s",
            (clean, phone_plus)
        )
        row = cur.fetchone()
        role_exists = (row.get('cnt', 0) if isinstance(row, dict) else row[0]) > 0

        if not role_exists:
            cur.execute(
                "INSERT INTO dbo.User_Roles (phone_number, role, created_at) VALUES (%s, 'CONSUMER', GETUTCDATE())",
                (phone_plus,)
            )
            logging.info(f"[welcome] User_Roles INSERT done for {phone_plus}")

        conn.commit()
        logging.info(f"[welcome] consumer created OK: {phone_plus} name={full_name} age={age_range}")
        clear_unreg(phone)  # Remove from unregistered exit log

    except Exception as e:
        logging.error(f"[welcome] _create_consumer FAILED: {e}", exc_info=True)
        if conn:
            try:
                conn.rollback()
            except Exception:
                pass
    finally:
        if conn:
            try:
                conn.close()
            except Exception:
                pass

def start_welcome(phone):
    """Show sample prices and registration prompt. Never writes to Consumer_Query_Sessions."""
    sample = _get_sample_prices()
    # Save step in Unregistered_Exit_Log only — not Consumer_Query_Sessions
    save_step(phone, "REGISTER_PROMPT", {})
    send_message(phone, t("en", "welcome_sample", sample_lines=sample, first_name=""))

def handle_welcome(phone, message, session, consumer):
    step      = session.get("_step", "LANG_PICK")
    msg       = message.strip()
    msg_lower = msg.lower()

    if msg_lower in ("0", "menu", "back", "cancel"):
        clear_session(phone)
        from consumer.menu import show_main_menu
        show_main_menu(phone)
        return

    if step == "REGISTER_PROMPT":
        if msg.lower() in ("1", "register", "yes"):
            save_step(phone, "LANG_PICK", {})
            send_message(phone, t("en", "welcome_greeting"))
        elif msg.lower() == "2":
            blocked, msg_out = record_exit(phone)
            send_message(phone, msg_out)
        else:
            # Any other input — resend welcome prompt, never show menu
            start_welcome(phone)
        return

    if step == "LANG_PICK":
        if msg == "1":
            lang = "en"
        elif msg == "2":
            lang = "pcm"
        else:
            send_message(phone, t("en", "welcome_invalid"))
            return
        set_lang(phone, lang)
        save_step(phone, "REF_PICK_EARLY", {"_lang": lang})
        send_message(phone, t(lang, "invite_ref_prompt"))
        return

    if step == "REF_PICK_EARLY":
        lang = session.get("_lang", "en")
        referrer_phone = ""
        if msg_lower != "skip" and len(msg.strip()) >= 6:
            try:
                from shared.db import get_connection as _gc
                _conn=_gc(); _cur=_conn.cursor(as_dict=True)
                _cur.execute("SELECT phone FROM dbo.Consumers WHERE referral_code=%s",(msg.strip().upper(),))
                _row=_cur.fetchone(); _conn.close()
                if _row:
                    referrer_phone=(_row.get("phone","") if isinstance(_row,dict) else _row[0])
                    send_message(phone, t(lang, "invite_ref_ok"))
                else:
                    send_message(phone, t(lang, "invite_ref_invalid"))
                    return
            except Exception as _re:
                logging.warning(f"[welcome.REF_PICK_EARLY] {_re}")
        _sd = {"_lang": lang, "_ref": referrer_phone}
        save_step(phone, "NAME_PICK", _sd)
        send_message(phone, t(lang, "welcome_ask_name"))
        return

    if step == "NAME_PICK":
        lang = session.get("_lang", "en")
        name = msg.strip()
        if len(name) < 2:
            send_message(phone, t(lang, "welcome_name_invalid"))
            return
        _sd = {"_lang": session.get("_lang","en"), "_name": name, "_ref": session.get("_ref","")}
        save_step(phone, "AGE_PICK", _sd)
        send_message(phone, t(lang, "welcome_ask_age"))
        return

    if step == "AGE_PICK":
        lang = session.get("_lang", "en")
        name = session.get("_name", "")
        if msg not in AGE_RANGES:
            send_message(phone, t(lang, "welcome_age_invalid"))
            return
        age_range = AGE_RANGES[msg]
        _sd = {"_lang": session.get("_lang","en"), "_name": session.get("_name",""), "_age": age_range, "_ref": session.get("_ref","")}
        save_step(phone, "GENDER_PICK", _sd)
        gender_prompt = (
            "\U0001f464 *What is your gender?*\n\n"
            "*1* \u2014 Male\n"
            "*2* \u2014 Female\n"
            "*3* \u2014 Prefer not to say\n\n"
            "*0* - Cancel"
        )
        send_message(phone, gender_prompt)
        return

    if step == "GENDER_PICK":
        lang = session.get("_lang", "en")
        if msg not in GENDERS:
            send_message(phone, "❌ Please reply *1* (Male), *2* (Female) or *3* (Prefer not to say).")
            return
        gender = GENDERS[msg]
        _sd = {
            "_lang": lang,
            "_name": session.get("_name",""),
            "_age": session.get("_age","Under 25"),
            "_gender": gender,
            "_ref": session.get("_ref","")
        }
        save_step(phone, "STATE_PICK", _sd)
        # Build state list
        state_lines = "\n".join(f"*{k}* \u2014 {v}" for k, v in NIGERIAN_STATES.items())
        send_message(phone,
            "\U0001f4cd *Which state are you in?*\n\n" + state_lines + "\n\n*0* - Cancel"
        )
        return

    if step == "STATE_PICK":
        lang = session.get("_lang", "en")
        if msg not in NIGERIAN_STATES:
            send_message(phone, "❌ Please reply with a number (1-37).")
            return
        state = NIGERIAN_STATES[msg]
        _sd = {
            "_lang": lang,
            "_name": session.get("_name",""),
            "_age": session.get("_age","Under 25"),
            "_gender": session.get("_gender","Prefer not to say"),
            "_state": state,
            "_ref": session.get("_ref","")
        }
        save_step(phone, "TC_ACCEPT", _sd)
        tc_msg = (
            "\U0001f4dc *Terms & Conditions*\n\n"
            "By registering on NaijaMarket Intel, you agree to:\n\n"
            "1. Provide accurate personal information\n"
            "2. Use price data for personal/business decisions only\n"
            "3. Not share or resell our data without permission\n"
            "4. Accept our Privacy Policy\n\n"
            "Read full T&C: https://www.naijamarketintel.com/terms\n\n"
            "*1* \u2014 I Accept\n"
            "*2* \u2014 Exit registration"
        )
        send_message(phone, tc_msg)
        return

    if step == "TC_ACCEPT":
        lang      = session.get("_lang", "en")
        name      = session.get("_name", "")
        age_range = session.get("_age", "Under 25")
        gender    = session.get("_gender", "Prefer not to say")
        state     = session.get("_state", "")
        ref       = session.get("_ref", "")
        if msg_lower == "1":
            record_optin(phone, channel="WELCOME_FLOW")
            _create_consumer(phone, lang, name, age_range, gender, state, ref)
            send_message(phone,
                "✅ You now have access to live Nigerian commodity prices.\n"
                "Before you go to the market, check prices here first "
                "so you don't get surprised when you arrive\n\n"
                "📊 Compare prices across markets\n"
                "📍 Find the cheapest market near you\n"
                "🔔 Set alerts when prices drop\n\n"
                "These prices are reported by real people inside real "
                "markets — updated 3 times daily.\n\n"
                "Type *menu* to see everything available."
            )
        elif msg_lower == "2":
            blocked, msg_out = record_exit(phone)
            send_message(phone, msg_out)
        else:
            tc_msg = (
                "\U0001f4dc *Terms & Conditions*\n\n"
                "Please reply:\n"
                "*1* \u2014 I Accept\n"
                "*2* \u2014 Exit registration"
            )
            send_message(phone, tc_msg)
        return

    save_step(phone, "LANG_PICK", {})
    send_message(phone, t("en", "welcome_greeting"))
