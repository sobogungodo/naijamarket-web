"""
trader/kyc.py — Trader KYC registration placeholder
Redirects to the trader PWA for full KYC registration.
Full KYC flow is handled via the trader PWA (trader.naijamarketintel.com).
"""
def handle_kyc(phone, message="", session=None, *args):
    from shared.sender import send_message

    send_message(phone,
        "\U0001f4cb *Price Reporter Registration*\n\n"
        "NaijaMarket Intel is now live. "
        "Register now and start earning ₦50 per approved submission.\n\n"
        "To complete your registration, please visit:\n"
        "\U0001f449 *https://trader.naijamarketintel.com*\n\n"
        "You'll need:\n"
        "• Your full name and date of birth\n"
        "• NIN (National ID Number)\n"
        "• Bank account details for payouts\n\n"
        "Already registered? Type *submit* to start submitting prices.\n"
        "Type *menu* to go back."
    )
