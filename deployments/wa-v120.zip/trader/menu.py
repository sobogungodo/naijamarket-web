"""
trader/menu.py — Complete trader routing module.
=================================================
The router's TRADER block is replaced by a 3-line delegate:

    if role == "TRADER":
        from trader.menu import handle_trader_menu
        handle_trader_menu(phone, message, session)
        return func.HttpResponse("OK", status_code=200)

This module owns ALL trader routing decisions.
Options 2 (Earnings) and 3 (Submissions) are stateless — zero session dependency.
Option 1 delegates to trader/submit.py:handle_submit(phone, message, session).

DB rules (non-negotiable):
  - get_connection() + cursor(as_dict=True) + %s placeholders (pymssql)
  - NEVER use query() with ? — that is the stale pyodbc pattern, will 500
  - Traders_register: reputation, total_earned, approved_submissions,
    total_submissions, rejected_submissions are NVARCHAR — always parse-guarded
  - Traders_register: balance, current_balance are DECIMAL — safe to float()
  - Submissions: trader_phone (match both +phone and plain phone)
  - Submissions: exclude synthetics with trader_id NOT LIKE 'SYN-%%'
    (double-percent is pymssql literal escape for %)
  - Rewards_Ledger: phone_number, net_amount, status
"""

import logging
import secrets
from shared.db import get_connection
from shared.sender import send_message, send_template_message
from shared.session import clear_session, save_session
from shared.trader_i18n import tt
from shared.trader_lang import get_trader_lang, set_trader_lang

# Business constants — must match PWA payout rules
EARLY_TRANSFER_MIN  = 4_000   # ₦4,000 minimum for manual transfer
REWARD_PER_APPROVED = 20      # ₦20 per approved submission

FRESH_KEYWORDS = {
    "menu", "hi", "hello", "start", "home", "back",
    "main", "options", "go back",
}


# ──────────────────────────────────────────────────────────────
# Phone normalisation
# ──────────────────────────────────────────────────────────────

def _pv(phone: str):
    """
    Return (digits_only, +digits) for dual-variant WHERE clauses.
    trader_phone in Submissions and phone_number in Rewards_Ledger
    may be stored with or without leading '+'.
    """
    clean = phone.lstrip("+").strip()
    return clean, f"+{clean}"


# ──────────────────────────────────────────────────────────────
# Safe type helpers (nvarchar guard)
# ──────────────────────────────────────────────────────────────

def _sf(val, default: float = 0.0) -> float:
    """Safe float from nvarchar — never raises."""
    try:
        return float(str(val or "").replace(",", "").strip() or default)
    except (ValueError, TypeError):
        return default


def _si(val, default: int = 0) -> int:
    """Safe int from nvarchar — never raises."""
    try:
        return int(float(str(val or "").strip() or default))
    except (ValueError, TypeError):
        return default


# ──────────────────────────────────────────────────────────────
# DB queries — each opens its own connection (short-lived)
# ──────────────────────────────────────────────────────────────

def _get_trader(phone: str) -> dict:
    """
    Slim trader record — guards and greeting only.
    Called on every trader message: must be a fast single-row lookup.
    Columns: trader_id, full_name, first_name, registration_status,
             is_suspended, suspension_reason, assigned_market_name,
             assigned_state.
    """
    conn = get_connection()
    try:
        cur = conn.cursor(as_dict=True)
        p, pp = _pv(phone)
        cur.execute("""
            SELECT trader_id,
                   full_name,
                   first_name,
                   registration_status,
                   is_suspended,
                   suspension_reason,
                   assigned_market_name,
                   assigned_state,
                   preferred_language
            FROM   dbo.Traders_register
            WHERE  phone_number = %s
               OR  phone_number = %s
        """, (p, pp))
        return cur.fetchone() or {}
    except Exception as e:
        logging.error(f"[trader.menu._get_trader] {e}")
        return {}
    finally:
        conn.close()


def _get_full_trader(phone: str) -> dict:
    """
    Full trader record — includes balance, reputation, tier.
    Called only for menu display and option 2 (Earnings).
    Note: reputation, tier_name are nvarchar — use _si()/_sf() on them.
    """
    conn = get_connection()
    try:
        cur = conn.cursor(as_dict=True)
        p, pp = _pv(phone)
        cur.execute("""
            SELECT trader_id,
                   full_name,
                   first_name,
                   registration_status,
                   is_suspended,
                   assigned_market_name,
                   assigned_state,
                   current_balance,
                   balance,
                   reputation,
                   tier_name,
                   preferred_language
            FROM   dbo.Traders_register
            WHERE  phone_number = %s
               OR  phone_number = %s
        """, (p, pp))
        return cur.fetchone() or {}
    except Exception as e:
        logging.error(f"[trader.menu._get_full_trader] {e}")
        return {}
    finally:
        conn.close()


def _get_total_earned(phone: str) -> float:
    """
    Authoritative total confirmed earnings.
    Uses Rewards_Ledger SUM(net_amount WHERE status='COMPLETED').
    The total_earned column in Traders_register is an nvarchar
    counter that may be stale — do NOT use it here.
    """
    conn = get_connection()
    try:
        cur = conn.cursor(as_dict=True)
        p, pp = _pv(phone)
        cur.execute("""
            SELECT ISNULL(SUM(net_amount), 0) AS total_earned
            FROM   dbo.Rewards_Ledger
            WHERE  (phone_number = %s OR phone_number = %s)
              AND  status = 'COMPLETED'
        """, (p, pp))
        row = cur.fetchone()
        return float(row["total_earned"]) if row and row.get("total_earned") is not None else 0.0
    except Exception as e:
        logging.error(f"[trader.menu._get_total_earned] {e}")
        return 0.0
    finally:
        conn.close()


def _get_today_subs(phone: str) -> dict:
    """
    Today's submission counts broken down by validation_status.
    Excludes synthetic submissions (trader_id NOT LIKE 'SYN-%%').
    Double %% is pymssql's way to pass a literal % in LIKE patterns.
    """
    conn = get_connection()
    try:
        cur = conn.cursor(as_dict=True)
        p, pp = _pv(phone)
        cur.execute("""
            SELECT
                COUNT(*) AS total,
                SUM(CASE WHEN validation_status = 'APPROVED' THEN 1 ELSE 0 END) AS approved,
                SUM(CASE WHEN validation_status = 'PENDING'  THEN 1 ELSE 0 END) AS pending,
                SUM(CASE WHEN validation_status = 'REJECTED' THEN 1 ELSE 0 END) AS rejected
            FROM   dbo.Submissions
            WHERE  (trader_phone = %s OR trader_phone = %s)
              AND  trader_id NOT LIKE 'SYN-%%'
              AND  CAST(submitted_at AS DATE) = CAST(GETUTCDATE() AS DATE)
        """, (p, pp))
        return cur.fetchone() or {}
    except Exception as e:
        logging.error(f"[trader.menu._get_today_subs] {e}")
        return {}
    finally:
        conn.close()


def _get_alltime_and_recent(phone: str):
    """
    All-time totals + last 3 submissions (most recent first).
    Returns (alltime_dict, recent_list).
    Uses item and price columns (Submissions uses 'price', not 'price_naira').
    """
    conn = get_connection()
    try:
        cur = conn.cursor(as_dict=True)
        p, pp = _pv(phone)

        cur.execute("""
            SELECT
                COUNT(*) AS total,
                SUM(CASE WHEN validation_status = 'APPROVED' THEN 1 ELSE 0 END) AS approved
            FROM   dbo.Submissions
            WHERE  (trader_phone = %s OR trader_phone = %s)
              AND  trader_id NOT LIKE 'SYN-%%'
        """, (p, pp))
        alltime = cur.fetchone() or {}

        cur.execute("""
            SELECT TOP 3
                   item,
                   price,
                   validation_status
            FROM   dbo.Submissions
            WHERE  (trader_phone = %s OR trader_phone = %s)
              AND  trader_id NOT LIKE 'SYN-%%'
            ORDER BY submitted_at DESC
        """, (p, pp))
        recent = cur.fetchall() or []

        return alltime, recent
    except Exception as e:
        logging.error(f"[trader.menu._get_alltime_and_recent] {e}")
        return {}, []
    finally:
        conn.close()


# ──────────────────────────────────────────────────────────────
# Message builders — pure functions, no DB calls
# ──────────────────────────────────────────────────────────────

def _msg_menu(trader: dict, lang: str = "en") -> str:
    first  = (trader.get("first_name") or
              (trader.get("full_name") or "Trader").split()[0])
    market = trader.get("assigned_market_name") or "your market"
    # current_balance is decimal (preferred); balance is decimal (fallback)
    avail  = float(trader.get("current_balance") or trader.get("balance") or 0)
    return tt(lang, "menu", first=first, market=market, avail=avail)


def _msg_earnings(trader: dict, total_earned: float, lang: str = "en") -> str:
    avail  = float(trader.get("current_balance") or trader.get("balance") or 0)
    rep    = _si(trader.get("reputation"), 50)
    tier   = (trader.get("tier_name") or
              ("Gold Trader"   if rep >= 80 else
               "Active Trader" if rep >= 50 else "New Trader"))
    needed = EARLY_TRANSFER_MIN - avail
    if avail >= EARLY_TRANSFER_MIN:
        transfer_line = tt(lang, "earn_eligible")
    else:
        transfer_line = tt(lang, "earn_need_more", needed=needed)
    return tt(lang, "earnings",
              avail=avail, transfer_line=transfer_line,
              total_earned=total_earned, rep=rep, tier=tier)


def _msg_submissions(today: dict, alltime: dict, recent: list, lang: str = "en") -> str:
    t_total    = _si(today.get("total"))
    t_approved = _si(today.get("approved"))
    t_pending  = _si(today.get("pending"))
    t_rejected = _si(today.get("rejected"))
    earned_today = t_approved * REWARD_PER_APPROVED

    a_total    = _si(alltime.get("total"))
    a_approved = _si(alltime.get("approved"))

    _E = {"APPROVED": "✅", "PENDING": "⏳", "REJECTED": "❌"}
    recent_lines = []
    for r in recent:
        emoji = _E.get((r.get("validation_status") or "").upper(), "⏳")
        item  = r.get("item") or "Unknown"
        price = _sf(r.get("price"))
        recent_lines.append(f"{emoji} {item} — ₦{price:,.0f}")

    recent_block = "\n".join(recent_lines) if recent_lines else tt(lang, "subs_none_recent")
    return tt(lang, "submissions",
              t_total=t_total, t_approved=t_approved,
              t_pending=t_pending, t_rejected=t_rejected,
              earned_today=earned_today,
              a_total=a_total, a_approved=a_approved,
              recent_block=recent_block)


# ──────────────────────────────────────────────────────────────
# Magic-link login — issue a one-time web sign-in link
# ──────────────────────────────────────────────────────────────

def _handle_login(phone: str, trader: dict, lang: str = "en") -> None:
    """
    Generate a one-time login token, store it in Trader_Login_Tokens (10-min,
    single-use), and send the approved trader_magic_login template whose URL
    button carries the token. Approved traders only (caller enforces guards).
    """
    token = secrets.token_hex(32)  # 64 hex chars
    p, _pp = _pv(phone)

    conn = get_connection()
    failed = False
    try:
        cur = conn.cursor()
        cur.execute("""
            INSERT INTO dbo.Trader_Login_Tokens
                (token, trader_id, phone_number, expires_at, used)
            VALUES
                (%s, %s, %s, DATEADD(MINUTE, 10, GETUTCDATE()), 0)
        """, (token, trader.get("trader_id"), p))
        conn.commit()
    except Exception as e:
        logging.error(f"[trader.menu._handle_login] {e}")
        failed = True
    finally:
        try: conn.close()
        except Exception: pass

    if failed:
        send_message(phone, tt(lang, "login_gen_fail"))
        return

    ok = send_template_message(
        phone=phone,
        template_name="trader_magic_login",
        body_params=[],
        language="en",
        button_url_param=token,
    )
    if ok:
        send_message(phone, tt(lang, "login_sent"))
    else:
        send_message(phone, tt(lang, "login_send_fail"))


# ──────────────────────────────────────────────────────────────
# Public entrypoint — called by router
# ──────────────────────────────────────────────────────────────

def handle_trader_menu(phone: str, message: str, session) -> None:
    """
    Sole public entrypoint.

    Router calls this and returns immediately:
        if role == "TRADER":
            from trader.menu import handle_trader_menu
            handle_trader_menu(phone, message, session)
            return func.HttpResponse("OK", status_code=200)

    Args:
        phone:   Webhook phone number (may have + prefix or not — handled internally).
        message: Raw message text from user.
        session: Parsed session_data dict from Consumer_Query_Sessions, or None.
                 Must not contain binary data — always a plain dict or None.
    """
    msg     = (message or "").strip().lower()
    session = session or {}

    # ── 1. Load slim trader record for all guards ─────────────────────
    trader = _get_trader(phone)

    # ── 1.5 Resolve language once (session override → DB pref → 'en') ──
    lang = get_trader_lang(trader, session)

    # ── 2. Guard: suspended ───────────────────────────────────────────
    if trader.get("is_suspended"):
        reason = trader.get("suspension_reason") or "Please contact support."
        send_message(phone, tt(lang, "suspended", reason=reason))
        return

    # ── 3. Guard: not yet approved ────────────────────────────────────
    reg_status = (trader.get("registration_status") or "PENDING").upper()
    if reg_status != "APPROVED":
        if msg in ("register", "join", "kyc"):
            clear_session(phone)
            from trader.kyc import handle_kyc
            handle_kyc(phone, message, {"_flow": "TRADER_KYC", "_step": "START"})
            return
        send_message(phone, tt(lang, "reg_pending", status=reg_status.title()))
        return

    # ── 3.5 LOGIN keyword → issue web magic-link (approved traders only) ─
    if msg == "login":
        _handle_login(phone, trader, lang)
        return

    # ── 4. Determine flow context ─────────────────────────────────────
    current_flow = session.get("_flow", "").upper()

    # ── 4.1 LANGUAGE toggle ───────────────────────────────────────────
    #   Await-choice MUST be handled before the numbered-options block,
    #   otherwise the 1/2 reply is swallowed as a menu selection.
    if current_flow == "TRADER_LANG":
        if msg in ("1", "english", "en"):
            set_trader_lang(phone, "en")
            clear_session(phone)
            save_session(phone, {"_flow": "TRADER_MENU"})
            send_message(phone, tt("en", "lang_set_en"))
            full = _get_full_trader(phone)
            send_message(phone, _msg_menu(full, "en"))
        elif msg in ("2", "pidgin", "pcm", "pg"):
            set_trader_lang(phone, "pcm")
            clear_session(phone)
            save_session(phone, {"_flow": "TRADER_MENU"})
            send_message(phone, tt("pcm", "lang_set_pcm"))
            full = _get_full_trader(phone)
            send_message(phone, _msg_menu(full, "pcm"))
        else:
            send_message(phone, tt(lang, "lang_invalid"))
        return

    if msg in ("lang", "language"):
        clear_session(phone)
        save_session(phone, {"_flow": "TRADER_LANG", "_step": "await_choice"})
        send_message(phone, tt(lang, "lang_prompt"))
        return
    in_submit    = current_flow in ("TRADER_SUBMIT", "SUBMIT")

    # ── 5. In-progress submit session: delegate without intercepting ──
    #       (but NEVER intercept 2/3/menu — let those fall through)
    if in_submit and msg not in FRESH_KEYWORDS and msg not in ("2", "3"):
        from trader.submit import handle_submit
        handle_submit(phone, message, session)
        return

    # ── 6. Numbered options — MUST come before the `not current_flow`
    #       gate below, otherwise "2"/"3" bounce back to menu when no
    #       session is saved (which is the case right after menu display).
    if msg == "1" or msg in ("submit", "price", "submitprice"):
        clear_session(phone)
        new_sess = {"_flow": "TRADER_SUBMIT", "_step": "START"}
        save_session(phone, new_sess)
        from trader.submit import handle_submit
        handle_submit(phone, message, new_sess)
        return

    if msg == "2" or msg == "balance":
        full   = _get_full_trader(phone)
        earned = _get_total_earned(phone)
        send_message(phone, _msg_earnings(full, earned, lang))
        return

    if msg == "3":
        today           = _get_today_subs(phone)
        alltime, recent = _get_alltime_and_recent(phone)
        send_message(phone, _msg_submissions(today, alltime, recent, lang))
        return

    # ── 7. Fresh / menu keyword → show menu ──────────────────────────
    #       save_session so the next message has a flow context.
    if msg in FRESH_KEYWORDS or not current_flow:
        clear_session(phone)
        save_session(phone, {"_flow": "TRADER_MENU"})
        full = _get_full_trader(phone)
        send_message(phone, _msg_menu(full, lang))
        return

    # ── 8. Fallback ───────────────────────────────────────────────────
    clear_session(phone)
    save_session(phone, {"_flow": "TRADER_MENU"})
    full = _get_full_trader(phone)
    send_message(phone, _msg_menu(full, lang))
