"""
trader/kyc.py — Trader KYC registration placeholder
Redirects to the trader PWA for full KYC registration.
Full KYC flow is handled via the trader PWA (trader.naijamarketintel.com).
"""
def handle_kyc(phone, message="", session=None, *args):
    from shared.sender import send_message
    from shared.trader_i18n import tt
    from shared.trader_lang import get_trader_lang

    # Best-effort language lookup — a pending trader may already have a stored
    # preference (set via the mobile app / PWA). Falls back to 'en' on any error.
    lang = "en"
    try:
        from shared.db import get_connection
        conn = get_connection()
        cur  = conn.cursor(as_dict=True)
        p = (phone or "").lstrip("+").strip()
        cur.execute(
            "SELECT preferred_language FROM dbo.Traders_register "
            "WHERE phone_number = %s OR phone_number = %s",
            (p, f"+{p}")
        )
        row = cur.fetchone()
        conn.close()
        lang = get_trader_lang(row or {})
    except Exception:
        lang = "en"

    send_message(phone, tt(lang, "kyc_redirect"))

    # [audit wa-v113] log PWA registration redirect (NOT KYC completion —
    # WA only redirects; actual KYC completion happens in the naijamarket-trader PWA)
    try:
        from shared.db import log_activity
        log_activity(phone_number=phone, platform="WA", event_type="KYC_REDIRECT_PWA")
    except Exception:
        pass
