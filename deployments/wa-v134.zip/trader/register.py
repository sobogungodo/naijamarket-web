"""
trader/register.py — WhatsApp Trader (Price Reporter) Registration Flow
==========================================================================
Adapted from validator/register.py (623 lines, live).

CORRECTED DRAFT — fixes applied after a verification pass against live
sources (User_Roles columns, validator.banks API shape, consumer.menu
import path, _save_session call-site misuse, market disambiguation
persistence). Five blockers + two smells resolved, plus a follow-up fix
to the step-7 disambiguation branch (non-numeric reply now starts a fresh
search instead of locking the user into the old candidate list).

Step sequence (11 internal steps, numbered "of 9" in user-facing prompts
to mirror validator's "of 7" labeling convention — cosmetic only):
  1. Welcome / optional invite code
  2. Full name
  3. Date of birth
  4. Address
  5. BVN (format-only — STUBBED until Paystack Identity/Okra live)
  6. State
  7. Market (numbered list or search, depending on state size)
  8. Bank
  9. Account number (Paystack resolve)
  10. Bank confirm
  11. Terms & Conditions -> completion
"""

import logging
import re
import uuid
from datetime import datetime, date

from shared.db import get_connection
from shared.sender import send_message
from validator.banks import BANKS, BANK_LIST_MSG, get_bank_code

NIGERIAN_STATES = [
    "Abia", "Adamawa", "Akwa Ibom", "Anambra", "Bauchi", "Bayelsa", "Benue",
    "Borno", "Cross River", "Delta", "Ebonyi", "Edo", "Ekiti", "Enugu",
    "FCT", "Gombe", "Imo", "Jigawa", "Kaduna", "Kano", "Katsina", "Kebbi",
    "Kogi", "Kwara", "Lagos", "Nasarawa", "Niger", "Ogun", "Ondo", "Osun",
    "Oyo", "Plateau", "Rivers", "Sokoto", "Taraba", "Yobe", "Zamfara",
]
STATE_LIST_MSG = "\n".join(f"{i+1}. {s}" for i, s in enumerate(NIGERIAN_STATES))

MARKET_LIST_THRESHOLD = 10
MAX_BVN_ATTEMPTS = 3
MAX_BANK_ATTEMPTS = 3
MAX_MARKET_SEARCH_ATTEMPTS = 3

REFERRAL_REWARD_DEFAULT = 20

TC_TEXT = """📜 *NAIJAMARKET INTEL — PRICE REPORTER TERMS*

By registering as a Price Reporter, you agree to:

1️⃣ *Accurate Reporting*
Submit only prices you have personally observed at the market, at the time of submission. Submitting false, outdated, or estimated prices may result in rejection, reputation loss, or suspension.

2️⃣ *Location Verification*
Each submission requires your GPS location. You must be physically present at the market (within 500m) when submitting. Submissions outside this radius will be flagged.

3️⃣ *Rewards*
Approved submissions earn ₦20 each, paid as airtime to your registered phone number. Rewards are processed periodically and are subject to verification. NaijaMarket Intel reserves the right to withhold rewards for submissions found to be fraudulent.

4️⃣ *Identity & Banking Information*
You confirm that the BVN, bank account, and personal details you provide are accurate and belong to you. This information is used solely for identity verification and reward disbursement, and is stored securely in accordance with the Nigeria Data Protection Act (NDPA).

5️⃣ *Fraud & Suspension*
Repeated submission of inaccurate prices, GPS spoofing, duplicate accounts, or any attempt to manipulate the reward system will result in account suspension and forfeiture of pending rewards. Serious or repeated violations may be reported to relevant authorities.

6️⃣ *One Account Per Person*
You may hold only one role (Price Reporter, Validator, or Consumer) per phone number. Attempting to register multiple roles will result in registration being blocked.

7️⃣ *Daily Limits*
Submissions are capped per day as determined by NaijaMarket Intel and may change without prior notice. Limits exist to maintain data quality and prevent abuse.

8️⃣ *Referrals*
If you registered using a referral code, the person who referred you may receive a reward once your account is approved. This does not affect your own status or rewards.

9️⃣ *Account Termination*
NaijaMarket Intel may suspend or terminate any account at its discretion for violations of these terms, suspected fraud, or platform abuse.

🔟 *Changes to Terms*
These terms may be updated from time to time. Continued use of the Price Reporter program after changes constitutes acceptance.

By replying *ACCEPT*, you confirm you have read, understood, and agree to these terms.
Reply *CANCEL* to exit registration."""


class RoleConflictError(Exception):
    def __init__(self, existing_role):
        self.existing_role = existing_role
        super().__init__(f"Phone already registered as {existing_role}")


# ──────────────────────────────────────────────────────────────────────────
# Session helpers
# ──────────────────────────────────────────────────────────────────────────

def _get_or_create_session(phone):
    conn = get_connection()
    try:
        cur = conn.cursor(as_dict=True)
        cur.execute(
            """
            SELECT TOP 1 *
            FROM dbo.Trader_Reg_Sessions
            WHERE phone_number = %s AND status = 'IN_PROGRESS'
            ORDER BY started_at DESC
            """,
            (phone,)
        )
        row = cur.fetchone()
        if row:
            return row

        session_id = f"TRS-{uuid.uuid4().hex[:12]}"
        cur.execute(
            """
            INSERT INTO dbo.Trader_Reg_Sessions
                (session_id, phone_number, step, status,
                 started_at, last_activity_at, expires_at,
                 bank_verification_attempts, error_count)
            VALUES
                (%s, %s, 1, 'IN_PROGRESS',
                 GETUTCDATE(), GETUTCDATE(), DATEADD(HOUR, 24, GETUTCDATE()),
                 0, 0)
            """,
            (session_id, phone)
        )
        conn.commit()

        cur.execute("SELECT * FROM dbo.Trader_Reg_Sessions WHERE session_id = %s", (session_id,))
        return cur.fetchone()
    finally:
        conn.close()


def _save_session(session_id, fields):
    """
    Dynamic UPDATE for DATA VALUES ONLY. Column names come from `fields`
    keys — every call site here passes a hardcoded dict literal, never
    user-derived keys. This matches validator's pattern exactly.

    FIX (blocker): timestamp fields that need GETUTCDATE() (abandoned_at,
    completed_at, bank_verified_at) are NEVER passed through this function
    as string values — they go through _touch_timestamp() below, which
    issues a dedicated inline UPDATE, same as the validator does. Passing
    "GETUTCDATE()" as a parameterized value here would insert literal text
    into a DATETIME2 column and throw a conversion error.
    """
    if not fields:
        return
    conn = get_connection()
    try:
        cur = conn.cursor()
        set_clauses = ", ".join(f"{k} = %s" for k in fields.keys())
        values = list(fields.values())
        cur.execute(
            f"""
            UPDATE dbo.Trader_Reg_Sessions
            SET {set_clauses}, last_activity_at = GETUTCDATE(), updated_at = GETUTCDATE()
            WHERE session_id = %s
            """,
            values + [session_id]
        )
        conn.commit()
    finally:
        conn.close()


def _touch_timestamp(session_id, *, status=None, timestamp_col=None):
    """
    FIX (blocker #1): dedicated path for setting status + a GETUTCDATE()
    timestamp column in one inline UPDATE — mirrors validator's approach.
    timestamp_col must be one of a fixed allowlist (never derived from
    user input) to keep this injection-safe despite the f-string.
    """
    allowed_cols = {"abandoned_at", "completed_at", "bank_verified_at", "tc_accepted_at"}
    if timestamp_col is not None and timestamp_col not in allowed_cols:
        raise ValueError(f"Refusing to touch unrecognized timestamp column: {timestamp_col}")

    conn = get_connection()
    try:
        cur = conn.cursor()
        if status and timestamp_col:
            cur.execute(
                f"""
                UPDATE dbo.Trader_Reg_Sessions
                SET status = %s, {timestamp_col} = GETUTCDATE(),
                    last_activity_at = GETUTCDATE(), updated_at = GETUTCDATE()
                WHERE session_id = %s
                """,
                (status, session_id)
            )
        elif status:
            cur.execute(
                """
                UPDATE dbo.Trader_Reg_Sessions
                SET status = %s, last_activity_at = GETUTCDATE(), updated_at = GETUTCDATE()
                WHERE session_id = %s
                """,
                (status, session_id)
            )
        elif timestamp_col:
            cur.execute(
                f"""
                UPDATE dbo.Trader_Reg_Sessions
                SET {timestamp_col} = GETUTCDATE(),
                    last_activity_at = GETUTCDATE(), updated_at = GETUTCDATE()
                WHERE session_id = %s
                """,
                (session_id,)
            )
        conn.commit()
    finally:
        conn.close()


# ──────────────────────────────────────────────────────────────────────────
# Identity / referral / lookup helpers
# ──────────────────────────────────────────────────────────────────────────

def _validate_invite_code(code, phone):
    conn = get_connection()
    try:
        cur = conn.cursor(as_dict=True)
        cur.execute(
            "SELECT TOP 1 referrer_phone, status FROM dbo.Reporter_Referral_Chain WHERE referral_code = %s",
            (code,)
        )
        row = cur.fetchone()
        if not row:
            return {"valid": False, "reason": "Code not found"}
        if row["referrer_phone"] == phone:
            return {"valid": False, "reason": "Cannot refer yourself"}
        return {"valid": True, "referrer_phone": row["referrer_phone"]}
    except Exception as e:
        logging.error(f"[trader.register] _validate_invite_code error: {e}")
        return {"valid": False, "reason": "Lookup error"}
    finally:
        conn.close()


def _validate_bvn_format(bvn):
    """STUBBED until Paystack Identity / Okra live. Format-only: 11 digits."""
    return bool(re.fullmatch(r"\d{11}", bvn))


def _resolve_bank_account(account_number, bank_code):
    """Reused verbatim from validator/register.py — Paystack /bank/resolve."""
    import os
    import requests
    try:
        resp = requests.get(
            "https://api.paystack.co/bank/resolve",
            params={"account_number": account_number, "bank_code": bank_code},
            headers={"Authorization": f"Bearer {os.environ['PAYSTACK_SECRET_KEY']}"},
            timeout=15,
        )
        data = resp.json()
        if data.get("status"):
            return {"valid": True, "account_name": data["data"]["account_name"]}
        return {"valid": False, "reason": data.get("message", "Could not verify account")}
    except Exception as e:
        logging.error(f"[trader.register] _resolve_bank_account error: {e}")
        return {"valid": False, "reason": "Verification service unavailable"}


def _check_dual_role(phone):
    """
    FIX (smell #6): now also checks Traders_register, not just
    Consumers/Validators — blocks duplicate trader registration since
    that table has no unique constraint on phone_number.
    """
    conn = get_connection()
    try:
        cur = conn.cursor(as_dict=True)
        clean = phone.lstrip("+")

        cur.execute(
            "SELECT 1 AS x FROM dbo.Consumers WHERE phone IN (%s, %s) OR phone_number IN (%s, %s)",
            (clean, "+" + clean, clean, "+" + clean)
        )
        if cur.fetchone():
            return "CONSUMER"

        cur.execute(
            "SELECT 1 AS x FROM dbo.Validators WHERE phone_number IN (%s, %s)",
            (clean, "+" + clean)
        )
        if cur.fetchone():
            return "VALIDATOR"

        cur.execute(
            "SELECT 1 AS x FROM dbo.Traders_register WHERE phone_number IN (%s, %s)",
            (clean, "+" + clean)
        )
        if cur.fetchone():
            return "TRADER"  # already registered — not a conflict per se, but blocks duplicate insert

        return None
    finally:
        conn.close()


def _get_markets_for_state(state):
    conn = get_connection()
    try:
        cur = conn.cursor(as_dict=True)
        cur.execute(
            "SELECT market_id, market_name FROM dbo.Markets WHERE state = %s ORDER BY market_name",
            (state,)
        )
        return cur.fetchall()
    finally:
        conn.close()


def _search_markets(state, query):
    conn = get_connection()
    try:
        cur = conn.cursor(as_dict=True)
        cur.execute(
            """
            SELECT TOP 10 market_id, market_name
            FROM dbo.Markets
            WHERE state = %s AND market_name LIKE %s
            ORDER BY market_name
            """,
            (state, f"%{query}%")
        )
        return cur.fetchall()
    finally:
        conn.close()


def _get_referral_reward_amount():
    conn = get_connection()
    try:
        cur = conn.cursor(as_dict=True)
        cur.execute(
            "SELECT key_value FROM dbo.Admin_Config WHERE section = 'rewards' AND key_name = 'referralRewardAmount'"
        )
        row = cur.fetchone()
        return int(row["key_value"]) if row else REFERRAL_REWARD_DEFAULT
    except Exception:
        return REFERRAL_REWARD_DEFAULT
    finally:
        conn.close()


def _complete_registration(session, phone):
    conn = get_connection()
    try:
        existing_role = _check_dual_role(phone)
        if existing_role:
            raise RoleConflictError(existing_role)

        trader_id = f"TRD-{uuid.uuid4().hex[:8]}"
        clean_phone = phone if phone.startswith("+") else "+" + phone

        cur = conn.cursor()
        cur.execute(
            """
            INSERT INTO dbo.Traders_register (
                trader_id, phone_number, full_name, first_name,
                date_of_birth, Address, bvn, bank_name, bank_code,
                account_number, bank_account_verified, bank_account_name,
                assigned_market_id, assigned_market_name, assigned_state,
                registration_status, tc_version_accepted, tc_accepted_at,
                reputation, registered_at
            ) VALUES (
                %s, %s, %s, %s,
                %s, %s, %s, %s, %s,
                %s, 1, %s,
                %s, %s, %s,
                'PENDING_APPROVAL', 'v1', GETUTCDATE(),
                50, GETUTCDATE()
            )
            """,
            (
                trader_id, clean_phone, session["full_name"], session["first_name"],
                session["date_of_birth"], session["address"], session["bvn"],
                session["bank_name"], session["bank_code"],
                session["account_number"], session["bank_account_name"],
                session["assigned_market_id"], session["assigned_market_name"], session["state"],
            )
        )

        # FIX (blocker #2): real User_Roles columns, no assigned_at
        cur.execute(
            "INSERT INTO dbo.User_Roles (phone_number, role, status, created_at) VALUES (%s, 'TRADER', 'ACTIVE', GETUTCDATE())",
            (clean_phone,)
        )

        cur.execute(
            "UPDATE dbo.Trader_Reg_Sessions SET status='COMPLETED', completed_at=GETUTCDATE(), trader_id=%s, registration_successful=1 WHERE session_id=%s",
            (trader_id, session["session_id"])
        )

        conn.commit()

        invite_code = session.get("invite_code")
        if invite_code:
            try:
                validation = _validate_invite_code(invite_code, phone)
                if validation.get("valid"):
                    referrer_phone = validation["referrer_phone"]
                    reward_amount = _get_referral_reward_amount()

                    rcur = conn.cursor()
                    rcur.execute(
                        """
                        INSERT INTO dbo.Reporter_Referral_Chain
                            (referrer_phone, referee_phone, referral_code,
                             referee_joined_at, activated_at, reward_triggered_at,
                             reward_amount, status, created_at, updated_at, source_system)
                        VALUES
                            (%s, %s, %s,
                             GETUTCDATE(), GETUTCDATE(), GETUTCDATE(),
                             %s, 'REWARD_PENDING', GETUTCDATE(), GETUTCDATE(), 'WA')
                        """,
                        (referrer_phone, clean_phone, invite_code, reward_amount)
                    )

                    ref_tx_id = f"RL-{uuid.uuid4().hex.upper()[:8]}"
                    rcur.execute(
                        """
                        INSERT INTO dbo.Rewards_Ledger
                            (transaction_id, timestamp, phone_number, transaction_type,
                             amount, fee, net_amount, status, description, user_type)
                        VALUES
                            (%s, GETUTCDATE(), %s, 'REFERRAL_REWARD',
                             %s, 0, %s, 'PENDING', %s, 'TRADER')
                        """,
                        (ref_tx_id, referrer_phone, reward_amount, reward_amount,
                         f"Referral reward for inviting {clean_phone}")
                    )
                    conn.commit()
            except Exception as re_err:
                logging.error(f"[trader.register] referral reward write failed: {re_err}")

        return trader_id
    finally:
        conn.close()


def _resend_step_prompt(phone, step, session):
    prompts = {
        1: "📝 *PRICE REPORTER REGISTRATION*\n\nDo you have a referral code? Reply with the code, or type *SKIP* to continue without one.",
        2: "👤 *Step 1 of 9: Full Name*\n\nWhat is your full name?",
        3: "🎂 *Step 2 of 9: Date of Birth*\n\nWhat is your date of birth? (DD/MM/YYYY)",
        4: "🏠 *Step 3 of 9: Address*\n\nWhat is your home address?",
        5: "🔢 *Step 4 of 9: BVN*\n\nPlease enter your 11-digit Bank Verification Number (BVN).",
        6: f"📍 *Step 5 of 9: State*\n\nWhich state will you be reporting prices from?\n\n{STATE_LIST_MSG}",
        7: "🏪 *Step 6 of 9: Market*\n\nWhich market will you report prices from?",
        8: f"🏦 *Step 7 of 9: Bank*\n\nWhich bank do you use?\n\n{BANK_LIST_MSG}",
        9: "💳 *Step 8 of 9: Account Number*\n\nPlease enter your 10-digit account number.",
        10: "✅ Confirm this is your account? Reply YES or NO.",
        11: TC_TEXT,
    }
    send_message(phone, prompts.get(step, "Let's continue your registration. Type *exit* to cancel."))


# ──────────────────────────────────────────────────────────────────────────
# Main entry point
# ──────────────────────────────────────────────────────────────────────────

def handle_trader_registration(phone, message=""):
    msg = (message or "").strip()
    msg_lower = msg.lower()

    session = _get_or_create_session(phone)
    step = session["step"]

    if msg_lower in ("cancel", "exit", "quit", "00"):
        _touch_timestamp(session["session_id"], status="ABANDONED", timestamp_col="abandoned_at")
        send_message(phone, "Registration cancelled. Type *reporter* anytime to start again.")
        return

    if msg_lower == "menu":
        _touch_timestamp(session["session_id"], status="ABANDONED", timestamp_col="abandoned_at")
        # FIX (blocker #3): correct import path
        from consumer.menu import show_main_menu
        show_main_menu(phone)
        return

    if msg == "0" and step > 1:
        new_step = step - 1
        _save_session(session["session_id"], {"step": new_step})
        _resend_step_prompt(phone, new_step, session)
        return

    # ── Step 1: Optional invite code ──────────────────────────────────────
    if step == 1:
        if msg_lower == "skip" or not msg:
            _save_session(session["session_id"], {"step": 2})
            _resend_step_prompt(phone, 2, session)
            return
        validation = _validate_invite_code(msg, phone)
        if validation.get("valid"):
            _save_session(session["session_id"], {"invite_code": msg, "step": 2})
            send_message(phone, "✅ Referral code accepted!")
        else:
            _save_session(session["session_id"], {"step": 2})
            send_message(phone, "That code wasn't recognized, but you can still continue registering.")
        _resend_step_prompt(phone, 2, session)
        return

    # ── Step 2: Full name ──────────────────────────────────────────────────
    if step == 2:
        words = msg.split()
        if len(words) < 2:
            send_message(phone, "Please enter your full name (first and last name).")
            return
        first_name = words[0]
        _save_session(session["session_id"], {"full_name": msg, "first_name": first_name, "step": 3})
        _resend_step_prompt(phone, 3, session)
        return

    # ── Step 3: DOB ─────────────────────────────────────────────────────────
    if step == 3:
        try:
            dob = datetime.strptime(msg, "%d/%m/%Y").date()
            age = (date.today() - dob).days // 365
            if not (18 <= age <= 80):
                send_message(phone, "You must be between 18 and 80 years old to register.")
                return
        except ValueError:
            send_message(phone, "Please use the format DD/MM/YYYY, e.g. 15/03/1990.")
            return
        _save_session(session["session_id"], {"date_of_birth": dob.isoformat(), "step": 4})
        _resend_step_prompt(phone, 4, session)
        return

    # ── Step 4: Address ─────────────────────────────────────────────────────
    if step == 4:
        if len(msg) < 10:
            send_message(phone, "Please enter your full home address (at least 10 characters).")
            return
        _save_session(session["session_id"], {"address": msg, "step": 5})
        _resend_step_prompt(phone, 5, session)
        return

    # ── Step 5: BVN ──────────────────────────────────────────────────────────
    if step == 5:
        # FIX (smell #5): dedicated counter (error_count), not shared with step 9's
        # bank_verification_attempts. Reset to 0 on success before step 7 reuses it.
        bvn_attempts = session.get("error_count", 0) or 0
        if not _validate_bvn_format(msg):
            bvn_attempts += 1
            if bvn_attempts >= MAX_BVN_ATTEMPTS:
                _touch_timestamp(session["session_id"], status="ABANDONED", timestamp_col="abandoned_at")
                send_message(phone, "Too many invalid BVN attempts. Type *reporter* to start again.")
                return
            _save_session(session["session_id"], {"error_count": bvn_attempts})
            send_message(phone, f"Invalid BVN. Please enter exactly 11 digits. ({bvn_attempts}/{MAX_BVN_ATTEMPTS} attempts)")
            return
        _save_session(session["session_id"], {
            "bvn": msg, "bvn_verification_status": "FORMAT_VALID",
            "error_count": 0,  # reset for step 7's market-search reuse of this counter
            "step": 6,
        })
        _resend_step_prompt(phone, 6, session)
        return

    # ── Step 6: State ───────────────────────────────────────────────────────
    if step == 6:
        state = None
        try:
            idx = int(msg) - 1
            if 0 <= idx < len(NIGERIAN_STATES):
                state = NIGERIAN_STATES[idx]
        except ValueError:
            match = [s for s in NIGERIAN_STATES if s.lower() == msg_lower]
            if match:
                state = match[0]
        if not state:
            send_message(phone, f"Please reply with a number from the list.\n\n{STATE_LIST_MSG}")
            return
        _save_session(session["session_id"], {"state": state, "step": 7})
        markets = _get_markets_for_state(state)
        if len(markets) <= MARKET_LIST_THRESHOLD:
            lines = [f"🏪 *Step 6 of 9: Market*\n\nWhich market in {state}?"]
            lines += [f"{i+1}. {m['market_name']}" for i, m in enumerate(markets)]
            send_message(phone, "\n".join(lines))
        else:
            send_message(phone, f"🏪 *Step 6 of 9: Market*\n\n{state} has many markets. Type part of your market's name to search (e.g. 'Mile 12').")
        return

    # ── Step 7: Market (numbered list OR search, with disambiguation) ──────
    if step == 7:
        state = session["state"]
        markets = _get_markets_for_state(state)
        chosen = None

        if len(markets) <= MARKET_LIST_THRESHOLD:
            # Small state — flat numbered list
            try:
                idx = int(msg) - 1
                if not (0 <= idx < len(markets)):
                    raise ValueError
                chosen = markets[idx]
            except ValueError:
                lines = ["Please reply with a number from the list."]
                lines += [f"{i+1}. {m['market_name']}" for i, m in enumerate(markets)]
                send_message(phone, "\n".join(lines))
                return
        else:
            # Large state — search-driven selection
            pending_search = session.get("pending_market_search")

            if pending_search and msg.isdigit():
                # Numeric reply selects from the previously-shown candidates,
                # re-derived deterministically from the SAME search term.
                results = _search_markets(state, pending_search)
                idx = int(msg) - 1
                if not (0 <= idx < len(results)):
                    send_message(phone, f"Please reply with a number from the {len(results)} matches shown, or type a new search term.")
                    return
                chosen = results[idx]
            else:
                # Fresh search — either no pending search, OR a non-numeric reply
                # while one was pending (treat it as a brand-new query, not an
                # error). Clear any stale pending term first. (FIX: was a dead-end.)
                if pending_search:
                    _save_session(session["session_id"], {"pending_market_search": None})
                results = _search_markets(state, msg)
                if not results:
                    attempts = (session.get("error_count", 0) or 0) + 1
                    if attempts >= MAX_MARKET_SEARCH_ATTEMPTS:
                        _touch_timestamp(session["session_id"], status="ABANDONED", timestamp_col="abandoned_at")
                        send_message(phone, "Couldn't find that market after several tries. Type *reporter* to start again, or contact support.")
                        return
                    _save_session(session["session_id"], {"error_count": attempts})
                    send_message(phone, f"No market found matching '{msg}'. Try a different search term.")
                    return
                if len(results) == 1:
                    chosen = results[0]
                else:
                    lines = [f"Found {len(results)} matches. Reply with a number:"]
                    lines += [f"{i+1}. {m['market_name']}" for i, m in enumerate(results)]
                    _save_session(session["session_id"], {"pending_market_search": msg})
                    send_message(phone, "\n".join(lines))
                    return

        # Common save — reached by both the numbered-list and search paths
        _save_session(session["session_id"], {
            "assigned_market_id": chosen["market_id"],
            "assigned_market_name": chosen["market_name"],
            "pending_market_search": None,
            "error_count": 0,
            "step": 8,
        })
        _resend_step_prompt(phone, 8, session)
        return

    # ── Step 8: Bank (correct banks API usage) ─────────────────────────────
    if step == 8:
        bank = get_bank_code(msg)  # returns dict {"name":..., "code":...} or None
        if not bank:
            send_message(phone, f"Bank not recognized. Please choose from the list.\n\n{BANK_LIST_MSG}")
            return
        _save_session(session["session_id"], {
            "bank_name": bank["name"], "bank_code": str(bank["code"]),
            "bank_verification_attempts": 0,  # reset before step 9 uses it for account retries
            "step": 9,
        })
        _resend_step_prompt(phone, 9, session)
        return

    # ── Step 9: Account number (Paystack resolve) ───────────────────────────
    if step == 9:
        if not re.fullmatch(r"\d{10}", msg):
            send_message(phone, "Please enter a valid 10-digit account number.")
            return
        attempts = session.get("bank_verification_attempts", 0) or 0
        result = _resolve_bank_account(msg, session["bank_code"])
        if not result.get("valid"):
            attempts += 1
            if attempts >= MAX_BANK_ATTEMPTS:
                _save_session(session["session_id"], {"step": 8, "bank_verification_attempts": 0})
                send_message(phone, "Could not verify this account after several attempts. Let's pick your bank again.")
                _resend_step_prompt(phone, 8, session)
                return
            _save_session(session["session_id"], {"bank_verification_attempts": attempts})
            send_message(phone, f"Could not verify account: {result.get('reason')}. Try again. ({attempts}/{MAX_BANK_ATTEMPTS})")
            return
        _save_session(session["session_id"], {
            "account_number": msg,
            "bank_account_name": result["account_name"],
            "bank_verification_status": "VERIFIED",
            "step": 10,
        })
        _touch_timestamp(session["session_id"], timestamp_col="bank_verified_at")
        send_message(phone, f"✅ Account verified: *{result['account_name']}*\n\nIs this correct? Reply YES or NO.")
        return

    # ── Step 10: Bank confirm ────────────────────────────────────────────────
    if step == 10:
        if msg_lower in ("yes", "y"):
            _save_session(session["session_id"], {"step": 11})
            _resend_step_prompt(phone, 11, session)
            return
        if msg_lower in ("no", "n"):
            _save_session(session["session_id"], {"step": 8})
            _resend_step_prompt(phone, 8, session)
            return
        send_message(phone, "Please reply YES or NO.")
        return

    # ── Step 11: T&C ─────────────────────────────────────────────────────────
    if step == 11:
        if msg_lower == "accept":
            try:
                trader_id = _complete_registration(session, phone)
                send_message(
                    phone,
                    f"🎉 *Registration submitted!*\n\nYour Trader ID: {trader_id}\nStatus: Pending Approval\n\n"
                    f"You'll be notified once approved. Type *status* anytime to check."
                )
            except RoleConflictError as rce:
                _touch_timestamp(session["session_id"], status="BLOCKED")
                if rce.existing_role == "TRADER":
                    send_message(phone, "This number is already registered as a Price Reporter. Type *status* to check your registration.")
                else:
                    send_message(phone, f"This number is already registered as a {rce.existing_role}. Each phone number can only hold one role.")
            except Exception as e:
                if "DUAL_ROLE_BLOCKED" in str(e) or "50001" in str(e):
                    _touch_timestamp(session["session_id"], status="BLOCKED")
                    send_message(phone, "This number already holds another role on NaijaMarket Intel and cannot register as a Price Reporter.")
                else:
                    logging.error(f"[trader.register] completion error: {e}")
                    send_message(phone, "Something went wrong completing your registration. Please try again or contact support.")
            return
        if msg_lower == "cancel":
            _touch_timestamp(session["session_id"], status="ABANDONED", timestamp_col="abandoned_at")
            send_message(phone, "Registration cancelled.")
            return
        send_message(phone, "Reply *ACCEPT* to agree to the terms, or *CANCEL* to exit.")
        return

    _save_session(session["session_id"], {"step": 1})
    _resend_step_prompt(phone, 1, session)
