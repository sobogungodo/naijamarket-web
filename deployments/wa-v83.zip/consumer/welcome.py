"""
consumer/welcome.py - First-touch welcome flow with name + age collection
"""
import logging
import uuid
from shared.db      import get_connection
from shared.sender  import send_message
from shared.session import save_session, clear_session
from shared.lang    import set_lang
from shared.i18n    import t
from shared.optin   import record_optin

AGE_RANGES = {
    "1": "Under 25",
    "2": "25-34",
    "3": "35-44",
    "4": "45-54",
    "5": "55 and above",
}

def _get_sample_prices():
    try:
        conn = get_connection()
        cur  = conn.cursor()
        cur.execute("""
            SELECT TOP 3 item_name, price_naira, unit, trend
            FROM dbo.Latest_Prices_Summary
            WHERE state = 'Lagos'
              AND is_nbs_ref = 0
              AND is_food    = 1
              AND price_naira > 0
            ORDER BY NEWID()
        """)
        rows = cur.fetchall()
        conn.close()
        if not rows:
            return "Rice 50kg - N54,000\nBeans Brown - N98,000\nTomatoes (basket) - N35,000"
        lines = []
        for r in rows:
            lines.append(f"- {r['item_name']}: N{float(r['price_naira']):,.0f}/{r.get('unit','unit')}")
        return "\n".join(lines)
    except Exception as e:
        logging.warning(f"[welcome] sample prices error: {e}")
        return "Rice 50kg - N54,000\nBeans Brown - N98,000\nTomatoes (basket) - N35,000"

def _create_consumer(phone, lang, full_name, age_range, referrer_phone=""):
    clean      = phone.replace("+", "").strip()
    phone_plus = f"+{clean}"
    first_name = full_name.strip().split()[0] if full_name.strip() else full_name.strip()
    consumer_id = str(uuid.uuid4())

    conn = None
    try:
        conn = get_connection()
        cur  = conn.cursor()

        # Check if already exists
        cur.execute(
            "SELECT COUNT(*) as cnt FROM dbo.Consumers WHERE phone = %s OR phone_number = %s",
            (clean, phone_plus)
        )
        row = cur.fetchone()
        exists = (row.get('cnt', 0) if isinstance(row, dict) else row[0]) > 0

        if not exists:
            cur.execute(
                """INSERT INTO dbo.Consumers (
                    consumer_id, phone, phone_number,
                    first_name, full_name, age_range,
                    preferred_language, subscription_tier,
                    referral_code, referred_by,
                    account_status, created_at
                ) VALUES (%s, %s, %s, %s, %s, %s, %s, 'FREE', %s, %s, 'ACTIVE', GETUTCDATE())""",
                (consumer_id, clean, phone_plus,
                 first_name, full_name.strip(), age_range, lang,
                 str(consumer_id).replace("-","")[:8].upper(),
                 referrer_phone)
            )
            logging.info(f"[welcome] Consumers INSERT done for {phone_plus}")
        else:
            logging.info(f"[welcome] Consumers already exists for {phone_plus}")

        # Check User_Roles
        cur.execute(
            "SELECT COUNT(*) as cnt FROM dbo.User_Roles WHERE phone_number = %s OR phone_number = %s",
            (clean, phone_plus)
        )
        row = cur.fetchone()
        role_exists = (row.get('cnt', 0) if isinstance(row, dict) else row[0]) > 0

        if not role_exists:
            cur.execute(
                "INSERT INTO dbo.User_Roles (phone_number, role, created_at) VALUES (%s, 'CONSUMER', GETUTCDATE())",
                (phone_plus,)
            )
            logging.info(f"[welcome] User_Roles INSERT done for {phone_plus}")

        conn.commit()
        logging.info(f"[welcome] consumer created OK: {phone_plus} name={full_name} age={age_range}")

    except Exception as e:
        logging.error(f"[welcome] _create_consumer FAILED: {e}", exc_info=True)
        if conn:
            try:
                conn.rollback()
            except Exception:
                pass
    finally:
        if conn:
            try:
                conn.close()
            except Exception:
                pass

def start_welcome(phone):
    """Show sample prices first, then offer registration."""
    sample = _get_sample_prices()
    session = {"_flow": "WELCOME", "_step": "REGISTER_PROMPT"}
    save_session(phone, session)
    send_message(phone, t("en", "welcome_sample", sample_lines=sample, first_name=""))

def handle_welcome(phone, message, session, consumer):
    step      = session.get("_step", "LANG_PICK")
    msg       = message.strip()
    msg_lower = msg.lower()

    if msg_lower in ("0", "menu", "back", "cancel"):
        clear_session(phone)
        from consumer.menu import show_main_menu
        show_main_menu(phone)
        return

    if step == "REGISTER_PROMPT":
        if msg.lower() in ("1", "register", "yes"):
            session["_step"] = "LANG_PICK"
            save_session(phone, session)
            send_message(phone, t("en", "welcome_greeting"))
        else:
            clear_session(phone)
            from consumer.menu import show_main_menu
            show_main_menu(phone)
        return

    if step == "LANG_PICK":
        if msg == "1":
            lang = "en"
        elif msg == "2":
            lang = "pcm"
        else:
            send_message(phone, t("en", "welcome_invalid"))
            return
        set_lang(phone, lang)
        session["_lang"] = lang
        session["_step"] = "NAME_PICK"
        save_session(phone, session)
        send_message(phone, t(lang, "welcome_ask_name"))
        return

    if step == "NAME_PICK":
        lang = session.get("_lang", "en")
        name = msg.strip()
        if len(name) < 2:
            send_message(phone, t(lang, "welcome_name_invalid"))
            return
        session["_name"] = name
        session["_step"] = "AGE_PICK"
        save_session(phone, session)
        send_message(phone, t(lang, "welcome_ask_age"))
        return

    if step == "AGE_PICK":
        lang = session.get("_lang", "en")
        name = session.get("_name", "")
        if msg not in AGE_RANGES:
            send_message(phone, t(lang, "welcome_age_invalid"))
            return
        age_range = AGE_RANGES[msg]
        session["_age"] = age_range
        session["_step"] = "REF_PICK"
        save_session(phone, session)
        send_message(phone, t(lang, "invite_ref_prompt"))
        return

    if step == "REF_PICK":
        lang = session.get("_lang", "en")
        name = session.get("_name", "")
        age_range = session.get("_age", "Under 25")
        referrer_phone = ""
        if msg_lower != "skip" and len(msg.strip()) >= 6:
            # Look up referral code
            try:
                from shared.db import get_connection as _gc
                _conn=_gc(); _cur=_conn.cursor()
                _cur.execute("SELECT phone FROM dbo.Consumers WHERE referral_code=%s",(msg.strip().upper(),))
                _row=_cur.fetchone(); _conn.close()
                if _row:
                    referrer_phone=_row.get("phone","")
                    send_message(phone, t(lang, "invite_ref_ok"))
                else:
                    send_message(phone, t(lang, "invite_ref_invalid"))
                    return
            except Exception as _re:
                logging.warning(f"[welcome.REF_PICK] {_re}")
        record_optin(phone, channel="WELCOME_FLOW")
        _create_consumer(phone, lang, name, age_range, referrer_phone)
        first_name=name.split()[0]
        send_message(phone, t(lang, "welcome_complete", first_name=first_name))
        clear_session(phone)
        return

    send_message(phone, t("en", "welcome_greeting"))
    session["_step"] = "LANG_PICK"
    save_session(phone, session)
