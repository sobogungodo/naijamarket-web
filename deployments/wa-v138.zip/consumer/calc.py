import logging
from shared.db import get_connection
from shared.sender import send_message
from shared.session import save_session, clear_session
from shared.lang import get_lang
from shared.i18n import t
from consumer.menu import show_main_menu

def handle_calc(phone, message="", session=None, consumer=None, *args):
    session=session or {}; consumer=consumer or {}
    lang=get_lang(session,consumer); text=(message or "").strip(); msg=text.lower()
    step=session.get("step",0)
    if msg in ("0","menu","back"): clear_session(phone); show_main_menu(phone); return
    if step==0:
        session.update({"_flow":"CALC","step":1}); save_session(phone,session)
        send_message(phone,t(lang,"calc_title"))
    elif step==1: _find(phone,text,session,lang)
    elif step==2: _calc(phone,text,session,lang)

def _find(phone,text,session,lang):
    try:
        conn=get_connection(); cur=conn.cursor()
        cur.execute("SELECT TOP 1 item_name,AVG(price_naira) AS avg_p,unit FROM dbo.Latest_Prices_Summary WHERE item_name LIKE %s AND is_nbs_ref=0 AND is_food=1 AND price_naira>0 GROUP BY item_name,unit ORDER BY item_name",(f"%{text}%",))
        row=cur.fetchone(); conn.close()
        if not row: send_message(phone,t(lang,"not_found",q=text)); return
        session.update({"step":2,"item_name":row["item_name"],"unit_price":float(row["avg_p"]),"unit":row["unit"]}); save_session(phone,session)
        send_message(phone,t(lang,"calc_qty",item=row["item_name"],price=float(row["avg_p"]),unit=row["unit"] or "unit"))
    except Exception as e:
        logging.error(f"[calc] {e}"); send_message(phone,t(lang,"error_generic"))

def _calc(phone,text,session,lang):
    try:
        qty=float(text.replace(",","").strip()); assert qty>0
    except: send_message(phone,t(lang,"invalid_choice")); return
    item=session.get("item_name",""); up=session.get("unit_price",0); unit=session.get("unit","unit")
    total=up*qty; clear_session(phone)
    send_message(phone,t(lang,"calc_result",item=item,up=up,unit=unit,qty=qty,total=total))

def _handle_repeat_search(phone, text, session, lang):
    """After result: 1=search again, 0=menu."""
    from shared.session import clear_session, save_session
    from consumer.menu import show_main_menu
    from shared.sender import send_message
    from shared.i18n import t
    msg = text.strip().lower()
    if msg == "0" or msg in ("menu", "back"):
        clear_session(phone); show_main_menu(phone); return
    if msg == "1":
        session["step"] = 0; save_session(phone, session)
        handle_calc(phone, "", session, None)
        return
    send_message(phone, t(lang, "invalid_choice"))
