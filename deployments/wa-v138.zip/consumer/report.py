"""
consumer/report.py — Report wrong price handler [1j]

3-step flow: item → market → price → save to Price_Reports

Pre-deploy DDL (run once in Azure Portal Query Editor):

    IF NOT EXISTS (
        SELECT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = 'Price_Reports'
    )
    BEGIN
        CREATE TABLE dbo.Price_Reports (
            report_id      INT           IDENTITY(1,1) NOT NULL,
            phone_number   NVARCHAR(20)  NOT NULL,
            item_name      NVARCHAR(200) NOT NULL,
            market_name    NVARCHAR(200) NOT NULL,
            reported_price DECIMAL(18,2) NULL,
            status         NVARCHAR(20)  NOT NULL DEFAULT 'PENDING',
            created_at     DATETIME2     NOT NULL DEFAULT GETUTCDATE(),
            CONSTRAINT PK_Price_Reports PRIMARY KEY (report_id)
        );
        CREATE INDEX IX_Price_Reports_phone ON dbo.Price_Reports (phone_number);
        CREATE INDEX IX_Price_Reports_status ON dbo.Price_Reports (status, created_at);
    END
"""
import logging
from shared.db      import get_connection
from shared.sender  import send_message
from shared.session import save_session, clear_session
from shared.lang    import get_lang
from shared.i18n    import t


def start_report(phone: str, session: dict, consumer: dict):
    """Entry point — ask for item name."""
    lang = get_lang(session, consumer)
    session.update({"_flow": "REPORT", "_step": "ITEM"})
    save_session(phone, session)
    send_message(phone, t(lang, "report_start"))


def handle_report(phone: str, message: str, session: dict, consumer: dict):
    """Handle ongoing report flow."""
    lang = get_lang(session, consumer)
    step = session.get("_step", "ITEM")
    msg  = message.strip()

    if msg.lower() in ("0", "menu", "back", "cancel"):
        clear_session(phone)
        from consumer.menu import show_main_menu
        show_main_menu(phone)
        return

    if step == "ITEM":
        session.update({"_step": "MARKET", "_report_item": msg})
        save_session(phone, session)
        send_message(phone, t(lang, "report_market", item=msg))
        return

    if step == "MARKET":
        session.update({"_step": "PRICE", "_report_market": msg})
        save_session(phone, session)
        item = session.get("_report_item", "")
        send_message(phone, t(lang, "report_price", item=item, market=msg))
        return

    if step == "PRICE":
        try:
            price = float(msg.replace(",", "").replace("₦", "").strip())
        except ValueError:
            send_message(phone, t(lang, "report_invalid_price"))
            return

        item   = session.get("_report_item", "")
        market = session.get("_report_market", "")
        _save_report(phone, item, market, price)

        clear_session(phone)
        send_message(phone, t(lang, "report_saved", item=item, market=market, price=price))
        return

    # Fallback
    send_message(phone, t(lang, "report_start"))
    session.update({"_step": "ITEM"})
    save_session(phone, session)


def _save_report(phone: str, item: str, market: str, price: float):
    """Persist report to Price_Reports table."""
    clean = phone.replace("+", "").strip()
    try:
        conn = get_connection()
        cur  = conn.cursor()
        cur.execute(
            """
            INSERT INTO dbo.Price_Reports
                (phone_number, item_name, market_name, reported_price, status, created_at)
            VALUES (%s, %s, %s, %s, 'PENDING', GETUTCDATE())
            """,
            (clean, item[:200], market[:200], price)
        )
        conn.commit()
        conn.close()
        logging.info(f"[report] saved: {clean} | {item} @ {market}: ₦{price:,.0f}")
    except Exception as e:
        logging.error(f"[report] _save_report failed: {e}")
        # Non-fatal — user already sees thank-you message
