from shared.sender import send_message
from shared.db import get_consumer
from shared.lang import get_lang
from shared.i18n import t

def show_main_menu(phone: str):
    consumer = get_consumer(phone) or {}
    tier  = (consumer.get("subscription_tier") or "FREE").upper()
    lang  = get_lang({}, consumer)
    TIER_QUOTA = {
        "FREE": "5 searches/week",
        "SILVER": "10/day", "GOLD": "25/day",
        "BUSINESS": "100/day", "CORPORATE": "Unlimited",
        "ENTERPRISE": "Unlimited", "API_STARTER": "Unlimited",
        "API_BUSINESS": "Unlimited", "API_ENTERPRISE": "Unlimited"
    }
    quota = TIER_QUOTA.get(tier, tier)
    send_message(phone, t(lang, "menu_header", tier=tier, quota=quota))
