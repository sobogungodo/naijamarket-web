"""
consumer/share.py — Shareable price card [1n]

When user types 'share', retrieves their last-viewed price from session
and formats it as a copy-paste card for WhatsApp status/groups.

The last-viewed price is stored in session under '_share_card' dict
when any price result is shown (injected by prices.py, snapshot.py, etc.)
"""
from shared.sender  import send_message
from shared.session import clear_session
from shared.lang    import get_lang
from shared.i18n    import t


def handle_share(phone: str, session: dict, consumer: dict):
    """
    Show the shareable card from the last price result, or explain how to get one.
    Stateless — does not modify session.
    """
    lang = get_lang(session, consumer)
    card_data = session.get("_share_card") if session else None

    if not card_data:
        send_message(phone, t(lang, "share_none"))
        return

    try:
        msg = t(lang, "share_card",
                item=card_data.get("item", ""),
                market=card_data.get("market", ""),
                price=float(card_data.get("price", 0)),
                unit=card_data.get("unit", "unit"),
                arrow=card_data.get("arrow", "➡️"),
                change=float(card_data.get("change", 0)),
                trend=card_data.get("trend", "stable"),
                wlo=float(card_data.get("wlo", 0)),
                whi=float(card_data.get("whi", 0)),
                date=card_data.get("date", ""))
        send_message(phone, msg)
    except Exception:
        send_message(phone, t(lang, "share_none"))
