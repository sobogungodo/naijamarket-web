import logging
from shared.db import get_connection
from shared.sender import send_message
from shared.session import clear_session
from shared.lang import get_lang
from shared.i18n import t
from consumer.menu import show_main_menu

def handle_invite(phone, message="", session=None, consumer=None, *args):
    session=session or {}; consumer=consumer or {}
    lang=get_lang(session,consumer)
    clear_session(phone)
    try:
        conn=get_connection(); cur=conn.cursor()
        cur.execute("SELECT referral_code, first_name FROM dbo.Consumers WHERE phone=%s OR phone_number=%s",(phone,phone))
        row=cur.fetchone()
        if not row:
            conn.close(); show_main_menu(phone); return
        code=row.get("referral_code") or ""
        name=(row.get("first_name") or "").strip()
        # Generate code if not set
        if not code:
            import uuid
            code=str(uuid.uuid4()).replace("-","")[:8].upper()
            cur.execute("UPDATE dbo.Consumers SET referral_code=%s WHERE phone=%s OR phone_number=%s",(code,phone,phone))
            conn.commit()
        conn.close()
        send_message(phone,t(lang,"invite_code",name=name,code=code))
    except Exception as e:
        logging.error(f"[invite] {e}"); send_message(phone,t(lang,"error_generic"))
