"""
consumer/help.py — Help command and human support handoff [1i]

Stateless — always shows the help card and exits. No session needed.
Triggered by 'help' keyword in the router (intercepted before FRESH_KEYWORDS
so it doesn't clear the active session).
"""
from shared.sender  import send_message
from shared.lang    import get_lang
from shared.i18n    import t


def show_help(phone: str, session: dict = None, consumer: dict = None):
    """Show the help card. Preserves caller's session — does not clear it."""
    lang = get_lang(session or {}, consumer or {})
    send_message(phone, t(lang, "help_text"))
