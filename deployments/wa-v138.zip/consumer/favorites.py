import logging,json
from shared.db import get_connection
from shared.sender import send_message
from shared.session import save_session, clear_session
from shared.lang import get_lang
from shared.i18n import t
from consumer.menu import show_main_menu

def handle_favorites(phone, message="", session=None, consumer=None, *args):
    session=session or {}; consumer=consumer or {}
    lang=get_lang(session,consumer); text=(message or "").strip(); msg=text.lower()
    step=session.get("step",0)
    if msg in ("0","menu","back") and step==0: clear_session(phone); show_main_menu(phone); return
    if msg=="0": clear_session(phone); show_main_menu(phone); return
    if step==0: _menu(phone,session,lang)
    elif step==1: _action(phone,text,session,consumer,lang)
    elif step==2: _add(phone,text,session,consumer,lang)

def _get_favs(consumer):
    try:
        prefs=consumer.get("preferences") or "{}"
        if isinstance(prefs,str): prefs=json.loads(prefs)
        return prefs.get("favorites",[])
    except: return []

def _menu(phone,session,lang):
    session.update({"_flow":"FAVORITES","step":1}); save_session(phone,session)
    send_message(phone,t(lang,"fav_menu"))

def _action(phone,text,session,consumer,lang):
    if text=="1":
        favs=_get_favs(consumer)
        if not favs: send_message(phone,t(lang,"fav_none")); return
        lines="\n".join(f"\u2b50 {f}" for f in favs)
        send_message(phone,f"\u2b50 *{'MY FAVORITES' if lang=='en' else 'MY FAVORITES'}*\n\n{lines}\n\n*0* — Menu" + footer(lang)); return
    if text=="2":
        session.update({"step":2}); save_session(phone,session)
        send_message(phone,t(lang,"fav_add_prompt")); return
    if text=="3":
        _check_prices(phone,consumer,lang); return
    send_message(phone,t(lang,"invalid_choice"))

def _add(phone,text,session,consumer,lang):
    try:
        conn=get_connection(); cur=conn.cursor()
        cur.execute("SELECT TOP 1 item_name FROM dbo.Latest_Prices_Summary WHERE item_name LIKE %s AND is_nbs_ref=0 AND is_food=1 GROUP BY item_name",(f"%{text}%",))
        row=cur.fetchone()
        if not row: conn.close(); send_message(phone,t(lang,"not_found",q=text)); return
        item_name=row["item_name"]
        prefs={}
        try:
            raw=consumer.get("preferences") or "{}"; prefs=json.loads(raw) if isinstance(raw,str) else (raw or {})
        except: pass
        favs=prefs.get("favorites",[])
        if item_name not in favs:
            favs.append(item_name); prefs["favorites"]=favs
            cur.execute("UPDATE dbo.Consumers SET preferences=%s WHERE phone=%s OR phone_number=%s",(json.dumps(prefs),phone,phone))
            conn.commit()
        conn.close(); clear_session(phone)
        send_message(phone,t(lang,"fav_added",item=item_name))
    except Exception as e:
        logging.error(f"[favorites._add] {e}"); send_message(phone,t(lang,"error_generic"))

def _check_prices(phone,consumer,lang):
    favs=_get_favs(consumer)
    if not favs: send_message(phone,t(lang,"fav_none")); return
    try:
        conn=get_connection(); cur=conn.cursor(); lines=[]
        for item in favs[:5]:
            cur.execute("SELECT AVG(price_naira) AS avg_p,AVG(price_change_pct) AS chg FROM dbo.Latest_Prices_Summary WHERE item_name=%s AND is_nbs_ref=0 AND is_food=1 AND price_naira>0",(item,))
            r=cur.fetchone()
            if r and r.get("avg_p"):
                avg=float(r["avg_p"]); chg=float(r.get("chg") or 0)
                arrow="\U0001f4c8" if chg>0.5 else ("\U0001f4c9" if chg<-0.5 else "\u27a1\ufe0f")
                lines.append(f"{arrow} {item}: *\u20a6{avg:,.0f}*")
        conn.close(); clear_session(phone)
        title="\u2b50 *FAVORITES PRICES*" if lang=="en" else "\u2b50 *FAVORITES PRICE*"
        send_message(phone,f"{title}\n\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\n\n"+("\n".join(lines) if lines else "No price data")+f"\n\n\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\n*menu* \u2014 Menu")
    except Exception as e:
        logging.error(f"[favorites._check_prices] {e}"); send_message(phone,t(lang,"error_generic"))
