"""Language toggle flow — triggered by 'lang' keyword."""
from shared.sender  import send_message
from shared.session import save_session, clear_session
from shared.lang    import get_lang, set_lang
from shared.i18n    import t
from consumer.menu  import show_main_menu

def handle_lang(phone: str, message: str, session: dict, consumer: dict = None) -> None:
    session  = session  or {}
    consumer = consumer or {}
    text = message.strip().lower()
    step = session.get("_step", "")

    # Direct switch
    if text in ("pidgin", "pcm", "pg"):
        set_lang(phone, "pcm")
        session["lang"] = "pcm"
        save_session(phone, session)
        send_message(phone, t("pcm", "lang_set_pcm"))
        _resume_flow(phone, session)
        return

    if text in ("english", "en"):
        set_lang(phone, "en")
        session["lang"] = "en"
        save_session(phone, session)
        send_message(phone, t("en", "lang_set_en"))
        _resume_flow(phone, session)
        return

    # 'lang' keyword — show selection
    if text == "lang" and not step:
        lang = get_lang(session, consumer)
        session["_flow"] = "LANG"
        session["_step"] = "await_choice"
        save_session(phone, session)
        send_message(phone, t(lang, "lang_prompt"))
        return

    # Awaiting choice 1/2
    if step == "await_choice":
        if text == "1":
            set_lang(phone, "en")
            session["lang"] = "en"
            clear_session(phone)
            send_message(phone, t("en", "lang_set_en"))
            _resume_flow(phone, session)
        elif text == "2":
            set_lang(phone, "pcm")
            session["lang"] = "pcm"
            clear_session(phone)
            send_message(phone, t("pcm", "lang_set_pcm"))
            _resume_flow(phone, session)
        else:
            lang = get_lang(session, consumer)
            send_message(phone, t(lang, "lang_prompt"))
        return

    # Fallback
    clear_session(phone)
    show_main_menu(phone)

def _resume_flow(phone: str, session: dict):
    """After language change, resume the flow the user was in, or show menu."""
    import importlib
    current_flow = session.get("_flow", "").upper()
    if not current_flow or current_flow == "LANG":
        from consumer.menu import show_main_menu
        show_main_menu(phone)
        return

    FLOW_MAP = {
        "PRICES":    ("consumer.prices",       "handle_prices"),
        "ARBITRAGE": ("consumer.arbitrage",    "handle_arbitrage"),
        "ALERTS":    ("consumer.alerts",       "handle_alerts"),
        "COMPARE":   ("consumer.compare",      "handle_compare"),
        "TREND":     ("consumer.trend",        "handle_trend"),
        "SNAPSHOT":  ("consumer.snapshot",     "handle_snapshot"),
        "NFPI":      ("consumer.nfpi",         "handle_nfpi"),
        "BULK":      ("consumer.bulk",         "handle_bulk"),
        "FORECAST":  ("consumer.forecast",     "handle_forecast"),
        "BRIEF":     ("consumer.brief",        "handle_brief"),
        "FAVORITES": ("consumer.favorites",    "handle_favorites"),
        "FILTER":    ("consumer.filter_prices","handle_filter"),
        "EXPORT":    ("consumer.export_data",  "handle_export"),
        "CALC":      ("consumer.calc",         "handle_calc"),
        "TOKENS":    ("consumer.tokens",       "handle_tokens_flow"),
    }
    entry = FLOW_MAP.get(current_flow)
    if entry:
        # Reset to step 0 so the flow re-shows its current prompt
        session["step"] = 0
        save_session(phone, session)
        mod = importlib.import_module(entry[0])
        getattr(mod, entry[1])(phone, "", session, None)
    else:
        from consumer.menu import show_main_menu
        show_main_menu(phone)
