import logging, json
from shared.db import get_connection
from shared.sender import send_message
from shared.session import clear_session
from shared.lang import get_lang
from shared.i18n import t
from consumer.menu import show_main_menu

def _get_settings(phone):
    try:
        conn=get_connection(); cur=conn.cursor()
        cur.execute("SELECT settings_json FROM dbo.Consumers WHERE phone=%s OR phone_number=%s",(phone,phone))
        row=cur.fetchone(); conn.close()
        if row and row.get("settings_json"):
            return json.loads(row["settings_json"])
    except: pass
    return {}

def _save_settings(phone, settings):
    try:
        conn=get_connection(); cur=conn.cursor()
        cur.execute("UPDATE dbo.Consumers SET settings_json=%s WHERE phone=%s OR phone_number=%s",(json.dumps(settings),phone,phone))
        conn.commit(); conn.close()
    except Exception as e:
        logging.error(f"[digest._save] {e}")

def handle_digest(phone, message="", session=None, consumer=None, *args):
    session=session or {}; consumer=consumer or {}
    lang=get_lang(session,consumer)
    msg=(message or "").strip().lower()
    if msg=="digest on":
        settings=_get_settings(phone)
        if settings.get("digest_opted_in"):
            send_message(phone, t(lang,"digest_already_on")); return
        settings["digest_opted_in"]=True
        _save_settings(phone,settings)
        send_message(phone, t(lang,"digest_on_confirm")); return
    if msg=="digest off":
        settings=_get_settings(phone)
        if not settings.get("digest_opted_in"):
            send_message(phone, t(lang,"digest_already_off")); return
        settings["digest_opted_in"]=False
        _save_settings(phone,settings)
        send_message(phone, t(lang,"digest_off_confirm")); return
    clear_session(phone)
    _show(phone, lang)

def _show(phone, lang):
    try:
        conn=get_connection(); cur=conn.cursor()
        cur.execute("SELECT TOP 5 item_name,AVG(price_naira) AS avg_p,AVG(price_change_pct) AS avg_chg FROM dbo.Latest_Prices_Summary WHERE is_nbs_ref=0 AND is_food=1 AND price_change_pct>1 GROUP BY item_name ORDER BY avg_chg DESC")
        risers=cur.fetchall()
        cur.execute("SELECT TOP 5 item_name,AVG(price_naira) AS avg_p,AVG(price_change_pct) AS avg_chg FROM dbo.Latest_Prices_Summary WHERE is_nbs_ref=0 AND is_food=1 AND price_change_pct<-1 GROUP BY item_name ORDER BY avg_chg ASC")
        fallers=cur.fetchall()
        cur.execute("SELECT MAX(price_date) AS dt FROM dbo.Latest_Prices_Summary WHERE is_nbs_ref=0")
        dt=str((cur.fetchone() or {}).get("dt",""))[:10]; conn.close()
        up="\n".join(f"\U0001f4c8 {r['item_name']}: *\u20a6{float(r['avg_p']):,.0f}* (+{float(r['avg_chg']):.1f}%)" for r in risers) or ("No movers" if lang=="en" else "Nothing dey move up")
        dn="\n".join(f"\U0001f4c9 {r['item_name']}: *\u20a6{float(r['avg_p']):,.0f}* ({float(r['avg_chg']):.1f}%)" for r in fallers) or ("No movers" if lang=="en" else "Nothing dey move down")
        footer="\n\n*digest off* — Stop daily updates | *menu* — Menu"
        send_message(phone, t(lang,"brief_result",date=dt,risers=up,fallers=dn)+footer)
    except Exception as e:
        logging.error(f"[digest._show] {e}"); send_message(phone,t(lang,"error_generic"))
