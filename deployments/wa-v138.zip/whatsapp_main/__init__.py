"""
NaijaMarket Intel — WhatsApp Router v2.2
=========================================
Builds on v2.1 (June 10 2026 — 13 UX enhancements).

Security patches (wa-v46):
  W1: Meta X-Hub-Signature-256 verification added — forged webhooks rejected
      with HTTP 403 before any message processing.
  W4: Twilio form-encoded fallback REMOVED — platform fully migrated to
      Meta Cloud API. Legacy fallback was an unauthenticated entry point.
"""
import logging
import importlib
import hashlib
import hmac
import os
import azure.functions as func
from datetime import datetime, timezone

# Rate limit config [1o]
_RATE_LIMIT_MAX    = 30   # max messages per window
_RATE_LIMIT_WINDOW = 3600  # 60 minutes in seconds

# Session timeout for expiry message [1m]
_SESSION_TIMEOUT_MIN = 30


def _verify_meta_signature(body_bytes: bytes, sig_header: str) -> bool:
    """
    W1 FIX: Verify X-Hub-Signature-256 from Meta.
    Returns True only if signature is valid.
    Fails CLOSED — if META_APP_SECRET is not set, all webhooks are rejected.
    """
    app_secret = os.environ.get("META_APP_SECRET", "").encode("utf-8")
    if not app_secret:
        logging.error("[v2.2] META_APP_SECRET not set — rejecting webhook")
        return False
    expected = "sha256=" + hmac.new(app_secret, body_bytes, hashlib.sha256).hexdigest()
    if not sig_header:
        logging.warning("[v2.2] X-Hub-Signature-256 header missing")
        return False
    return hmac.compare_digest(expected, sig_header)


def _check_rate_limit(session: dict, phone: str) -> tuple[bool, dict]:
    """
    Returns (is_limited, updated_session).
    Stores _rate_count and _rate_reset (epoch int) in session data.
    Note: wiped on clear_session (fresh keywords) — acceptable for soft launch.
    """
    now   = int(datetime.now(timezone.utc).timestamp())
    count = session.get("_rate_count", 0)
    reset = session.get("_rate_reset", 0)

    if now >= reset:
        session["_rate_count"] = 1
        session["_rate_reset"] = now + _RATE_LIMIT_WINDOW
        return False, session

    count += 1
    session["_rate_count"] = count
    if count > _RATE_LIMIT_MAX:
        logging.warning(f"[v2.2] rate limit hit for {phone}: {count} msgs")
        return True, session

    return False, session


def _session_expired(session: dict) -> bool:
    """True if session has data but last_updated is older than TIMEOUT."""
    reset = session.get("_rate_reset", 0)
    if not reset or not session.get("_flow"):
        return False
    now     = int(datetime.now(timezone.utc).timestamp())
    age_min = (now - (reset - _RATE_LIMIT_WINDOW)) / 60
    return age_min > _SESSION_TIMEOUT_MIN


def main(req: func.HttpRequest) -> func.HttpResponse:
    import logging as _log; logging = _log  # shadow-proof alias
    try:
        # ── W1: Verify Meta signature BEFORE any processing ───────────────
        # GET requests are webhook verification challenges — skip sig check
        if req.method == "GET":
            try:
                from urllib.parse import urlparse, parse_qs
                import logging as _log
                qs        = parse_qs(urlparse(req.url).query)
                mode      = qs.get("hub.mode",         [""])[0]
                token     = qs.get("hub.verify_token", [""])[0]
                challenge = qs.get("hub.challenge",    [""])[0]
                if mode == "subscribe" and token == "naijamarket_meta_verify_2026":
                    _log.info("[v2.2] Webhook verify PASSED")
                    return func.HttpResponse(challenge, status_code=200)
                return func.HttpResponse("Forbidden", status_code=403)
            except Exception as ge:
                import logging as _log2
                _log2.error(f"[v2.2] GET crash: {ge}", exc_info=True)
                return func.HttpResponse("OK", status_code=200)
        if req.method == "POST":
            body_bytes = req.get_body()
            sig_header = req.headers.get("X-Hub-Signature-256", "")
            if not _verify_meta_signature(body_bytes, sig_header):
                logging.warning(
                    f"[v2.2] Signature REJECTED — "
                    f"sig={sig_header[:30] if sig_header else 'MISSING'}"
                )
                return func.HttpResponse("Forbidden", status_code=403)
        # ─────────────────────────────────────────────────────────────────

        # ── Parse incoming webhook (Meta Cloud API JSON only) ─────────────
        # W4: Twilio form-encoded fallback REMOVED — Meta Cloud API only.
        try:
            body_json = req.get_json()
            entry  = body_json["entry"][0]
            change = entry["changes"][0]["value"]

            # Webhook verification challenge or status callbacks
            if "messages" not in change:
                return func.HttpResponse("OK", status_code=200)

            msg_obj = change["messages"][0]
            phone   = msg_obj["from"]
            message = (msg_obj.get("text") or {}).get("body", "").strip()
        except Exception as e:
            # Invalid JSON or unexpected structure — not a valid Meta webhook
            logging.warning(f"[v2.2] Webhook parse failed: {e}")
            return func.HttpResponse("OK", status_code=200)
        # ─────────────────────────────────────────────────────────────────

        if not phone:
            return func.HttpResponse("OK", status_code=200)

        # W6.1 — log session start (fire-and-forget)
        try:
            from shared.db import log_reporter_activity
            log_reporter_activity(phone, 'WA_SESSION_START',
                                  activity_detail=None,
                                  source_system='func-naijamarket-wa')
        except Exception:
            pass

        # ── VAL-START + active registration session intercept ───────────────
        from shared.session import get_session as _gs, save_session as _svs
        _early_session = _gs(phone) or {}
        _in_val_reg = _early_session.get("_val_reg") == "1"
        if message.upper() == "VAL-START":
            # V3 FIX: block if phone already has a role
            try:
                import pymssql as _pm, os as _os
                _rc = _pm.connect(
                    server=_os.environ["SQL_SERVER"],
                    user=_os.environ.get("SQL_USERNAME") or _os.environ.get("SQL_USER"),
                    password=_os.environ["SQL_PASSWORD"],
                    database=_os.environ.get("SQL_DATABASE","naijafoodmarket-live"),
                    timeout=10, as_dict=True)
                _rcu = _rc.cursor()
                _rcu.execute(
                    "SELECT role FROM dbo.User_Roles WHERE phone_number=%s OR phone_number=%s",
                    (phone.replace('+','').strip(), f"+{phone.replace('+','').strip()}"))
                _rex = _rcu.fetchone()
                _rc.close()
                if _rex:
                    from shared.sender import send_message as _vsm2
                    _vsm2(phone,
                        f"\u274c This number is already registered as a {_rex['role']}."  
                        "\n\nType *menu* to continue.")
                    return func.HttpResponse("OK", status_code=200)
            except Exception as _rce:
                import logging as _rcl
                _rcl.error(f"[VAL-START] role check error: {_rce}")
            _in_val_reg = True
            _early_session["_val_reg"] = "1"
            _svs(phone, _early_session)

        if _in_val_reg:
            try:
                from validator.register import handle_validator_registration
                handle_validator_registration(phone, message)
            except Exception as _val_err:
                import logging as _vl
                _vl.error(f"[VAL-START] crash: {_val_err}", exc_info=True)
                from shared.sender import send_message as _vsm
                _vsm(phone, "Sorry, we hit a technical issue. Please try again in a moment.")
            return func.HttpResponse("OK", status_code=200)

        # ── GPS location message handler (for validator vote flow) ─────────
        # Meta sends location as type="location" with no text body
        if msg_obj.get("type") == "location" and not message:
            loc     = msg_obj.get("location", {})
            vlat    = loc.get("latitude")
            vlon    = loc.get("longitude")
            if vlat is not None and vlon is not None:
                from shared.session import get_session, save_session
                loc_session = get_session(phone) or {}
                vstep = loc_session.get("_vstep", "")
                if vstep == "VOTE":
                    # Validate GPS against market location
                    from validator.menu import _get_market_coords, _distance_m
                    # Get market_id from queue entry stored in session
                    vote_sub = loc_session.get("_vote_sub_id", "")
                    # Fetch market coords via submission market stored in session
                    # We stored market name but need coords — fetch from queue
                    try:
                        import pymssql, os as _os
                        _conn = pymssql.connect(
                            server   = _os.environ["SQL_SERVER"],
                            user     = _os.environ.get("SQL_USERNAME") or _os.environ.get("SQL_USER"),
                            password = _os.environ["SQL_PASSWORD"],
                            database = _os.environ.get("SQL_DATABASE", "naijafoodmarket-live"),
                            timeout  = 15, as_dict = True
                        )
                        _cur = _conn.cursor()
                        _cur.execute("""
                            SELECT m.latitude, m.longitude
                            FROM   dbo.Validation_Queue vq
                            JOIN   dbo.Markets m ON m.market_id = vq.market_id
                            WHERE  vq.submission_id = %s
                        """, (vote_sub,))
                        _mrow = _cur.fetchone()
                        _conn.close()
                        if _mrow and _mrow.get("latitude") and _mrow.get("longitude"):
                            dist = _distance_m(
                                float(vlat), float(vlon),
                                float(_mrow["latitude"]), float(_mrow["longitude"])
                            )
                            if dist <= 500:
                                loc_session["_vlat"] = vlat
                                loc_session["_vlon"] = vlon
                                save_session(phone, loc_session)
                                # V2 FIX: flag suspiciously precise GPS (< 10m = exact market centre)
                                if dist < 10:
                                    try:
                                        import pymssql as _pm2, os as _os2
                                        _gc = _pm2.connect(
                                            server=_os2.environ["SQL_SERVER"],
                                            user=_os2.environ.get("SQL_USERNAME") or _os2.environ.get("SQL_USER"),
                                            password=_os2.environ["SQL_PASSWORD"],
                                            database=_os2.environ.get("SQL_DATABASE","naijafoodmarket-live"),
                                            timeout=10, as_dict=True)
                                        _gcu = _gc.cursor()
                                        _gcu.execute("""
                                            UPDATE dbo.Validators
                                            SET gps_fraud_count = ISNULL(gps_fraud_count,0) + 1,
                                                honeypot_failures = CASE WHEN ISNULL(gps_fraud_count,0) + 1 >= 3 THEN 1 ELSE honeypot_failures END,
                                                updated_at = GETUTCDATE()
                                            WHERE phone_number=%s OR phone_number=%s
                                        """, (phone.replace('+','').strip(), f"+{phone.replace('+','').strip()}"))
                                        _gc.commit()
                                        _gcu.execute(
                                            "SELECT gps_fraud_count FROM dbo.Validators WHERE phone_number=%s OR phone_number=%s",
                                            (phone.replace('+','').strip(), f"+{phone.replace('+','').strip()}"))
                                        _grow = _gc.fetchone()
                                        _gc.close()
                                        import logging as _gl
                                        _gl.warning(f"[GPS honeypot] {phone} dist={int(dist)}m gps_fraud_count={(_grow or {}).get('gps_fraud_count','?')} ")
                                    except Exception as _ghe:
                                        import logging as _ghl
                                        _ghl.error(f"[GPS honeypot] update error: {_ghe}")
                                from shared.sender import send_message as _sm
                                _sm(phone,
                                    f"\u2705 *Location verified* ({int(dist)}m from market)\n\n"
                                    f"Reply *approve* or *reject* to cast your vote.\n"
                                    f"Type *0* to go back."
                                )
                            else:
                                from shared.sender import send_message as _sm
                                _sm(phone,
                                    f"\u274c *Too far from market* ({int(dist)}m)\n\n"
                                    f"You must be within 500m of the market to vote.\n"
                                    f"Please go to the market and try again.\n\n"
                                    f"Type *0* to cancel."
                                )
                        else:
                            # Market coords not found — allow vote (fail open)
                            loc_session["_vlat"] = vlat
                            loc_session["_vlon"] = vlon
                            save_session(phone, loc_session)
                            from shared.sender import send_message as _sm
                            _sm(phone,
                                "\u2705 *Location received.*\n\n"
                                "Reply *approve* or *reject* to cast your vote."
                            )
                    except Exception as _ge:
                        import logging
                        logging.error(f"[GPS] location check error: {_ge}")
                        # V1 FIX: fail closed — do NOT accept GPS on DB error
                        from shared.sender import send_message as _sm
                        _sm(phone,
                            "\u26a0\ufe0f *Could not verify your location.*\n\n"
                            "Please try sharing your location again.\n\n"
                            "Type *0* to go back."
                        )
            return func.HttpResponse("OK", status_code=200)

        if not message:
            return func.HttpResponse("OK", status_code=200)

        logging.info(f"[v2.2] {phone} | {message[:80]}")

        def mod(name):
            return importlib.import_module(name)

        from shared.session import get_session, clear_session, save_session
        from shared.sender  import send_message
        from shared.lang    import get_lang
        from shared.i18n    import t

        msg = message.strip().lower()

        # ── [1i] Help intercept — before FRESH_KEYWORDS to preserve session
        if msg in ("help", "?"):
            session  = get_session(phone) or {}
            consumer = _get_consumer(phone, mod)
            mod("consumer.help").show_help(phone, session, consumer)
            return func.HttpResponse("OK", status_code=200)

        # ── [1o] Rate limiting ────────────────────────────────────────────
        _pre_session = get_session(phone) or {}
        limited, _pre_session = _check_rate_limit(_pre_session, phone)
        if limited:
            lang = get_lang(_pre_session, {})
            send_message(phone, t(lang, "rate_limit"))
            save_session(phone, _pre_session)
            return func.HttpResponse("OK", status_code=200)

        # ── [1n] Share keyword ────────────────────────────────────────────
        if msg == "share":
            session  = _pre_session
            consumer = _get_consumer(phone, mod)
            mod("consumer.share").handle_share(phone, session, consumer)
            save_session(phone, session)
            return func.HttpResponse("OK", status_code=200)

        # ── [1j] Report keyword ───────────────────────────────────────────
        if msg == "report":
            session  = _pre_session
            consumer = _get_consumer(phone, mod)
            mod("consumer.report").start_report(phone, session, consumer)
            return func.HttpResponse("OK", status_code=200)

        # ── STOP / opt-out handling ───────────────────────────────────────
        if msg in ("stop", "optout", "unsubscribe", "opt-out"):
            from shared.optin import record_optout
            record_optout(phone)
            clear_session(phone)
            lang = get_lang(_pre_session, {})
            send_message(phone,
                "You have been unsubscribed from NaijaMarket Intel notifications.\n"
                "Reply *start* or *menu* to re-subscribe." if lang == "en" else
                "You don unsubscribe from NaijaMarket Intel notifications.\n"
                "Reply *start* or *menu* to re-subscribe."
            )
            return func.HttpResponse("OK", status_code=200)

        # ── Trader registration continuation dispatcher (production) ───────────
        # Catches an in-progress trader.register flow before the role lookup
        # and unregistered-welcome branch can hijack it. Two independent
        # entry points feed this: (1) the keyword path (register/trader/
        # join/reporter for a genuinely new user) sets _flow="TRADER_REGISTER"
        # on the WA session; (2) the welcome-menu option-2 handoff does not
        # set a WA session marker, so it's caught instead via the durable
        # DB-keyed check (_trader_reg_in_progress) against an IN_PROGRESS row
        # in dbo.Trader_Reg_Sessions, which both entry points create.
        _treg_sess = get_session(phone) or {}
        if (_treg_sess.get("_flow") == "TRADER_REGISTER"
                or _trader_reg_in_progress(phone)):
            if _treg_sess.get("_flow") != "TRADER_REGISTER":
                clear_session(phone)
                save_session(phone, {"_flow": "TRADER_REGISTER"})
                logging.info(f"[trader.register] {phone} continuation started")
            try:
                mod("trader.register").handle_trader_registration(phone, message)
            except Exception as _tre:
                logging.error(f"[trader.register] dispatch error: {_tre}", exc_info=True)
                send_message(phone, "Something went wrong with your registration. Please try again or type *menu*.")
                clear_session(phone)
                return func.HttpResponse("OK", status_code=200)
            # trader.register stores its state in dbo.Trader_Reg_Sessions and does
            # NOT touch the WA session — release the WA _flow marker once the DB
            # session is no longer IN_PROGRESS (COMPLETED/ABANDONED/BLOCKED),
            # otherwise a finished user stays stuck routing into trader.register.
            if not _trader_reg_in_progress(phone):
                clear_session(phone)
                logging.info(f"[trader.register] {phone} continuation released")
            return func.HttpResponse("OK", status_code=200)

        # ── Global keyword overrides (clear session) ──────────────────────
        # ── TRADER keywords ───────────────────────────────────────────────
        if msg in ("submit", "price", "submitprice"):
            trader_rec = _get_trader_record(phone)
            if trader_rec and trader_rec.get("registration_status") == "APPROVED":
                clear_session(phone)
                save_session(phone, {"_flow": "TRADER_SUBMIT", "_step": "START"})
                new_session = {"_flow": "TRADER_SUBMIT", "_step": "START"}
                mod("trader.submit").handle_submit(phone, message, new_session)
            else:
                send_message(phone,
                    "📋 *Become a NaijaMarket Trader*\n\n"
                    "Earn ₦50 per approved price submission.\n\n"
                    "Type *register* to apply or *menu* to go back."
                )
            return func.HttpResponse("OK", status_code=200)

        if msg in ("register", "trader", "join", "reporter"):
            # Check if user already has a role
            try:
                _rc = __import__('pymssql').connect(
                    server=__import__('os').environ['SQL_SERVER'],
                    user=__import__('os').environ.get('SQL_USERNAME') or __import__('os').environ.get('SQL_USER'),
                    password=__import__('os').environ['SQL_PASSWORD'],
                    database=__import__('os').environ.get('SQL_DATABASE','naijafoodmarket-live'),
                    timeout=10, as_dict=True)
                _rcu = _rc.cursor()
                _rcu.execute("SELECT role FROM dbo.User_Roles WHERE phone_number=%s OR phone_number=%s",
                    (phone.replace('+','').strip(), f"+{phone.replace('+','').strip()}"))
                _rex = _rcu.fetchone()
                _rc.close()
                _existing_role = (_rex.get('role') or '').upper() if _rex else ''
            except Exception:
                _existing_role = ''
            # Existing CONSUMER — never into trader KYC (dual-role trigger 50001
            # would block it); show the consumer menu instead of a DB error.
            if _existing_role == "CONSUMER":
                clear_session(phone)
                mod("consumer.menu").show_main_menu(phone)
                return func.HttpResponse("OK", status_code=200)
            if _existing_role == "TRADER":
                # Already a trader (any status) — fall through to the
                # role-based TRADER branch below.
                pass
            # wa-v136 routing (supersedes the 30 Jun 2026 first-contact-menu-for-all
            # design): 'join' → consumer onboarding; 'register'/'reporter'/'trader'
            # → trader (Price Reporter) registration directly (via the step-0
            # confirmation added in wa-v135).
            elif msg == "join":
                clear_session(phone)
                _wsess = get_session(phone) or {}
                if _wsess.get("_flow") == "WELCOME":
                    mod("consumer.welcome").handle_welcome(phone, message, _wsess, {})
                else:
                    mod("consumer.welcome").start_welcome(phone)
                return func.HttpResponse("OK", status_code=200)
            else:
                clear_session(phone)
                save_session(phone, {"_flow": "TRADER_REGISTER"})
                try:
                    from shared.db import log_activity as _log_act
                    _log_act(phone_number=phone, platform="WA", event_type="TRADER_KEYWORD_TO_REGISTER")
                except Exception:
                    pass
                mod("trader.register").handle_trader_registration(phone, message)
                return func.HttpResponse("OK", status_code=200)

        # ── Role-based routing — VALIDATOR takes priority ───────────────────
        try:
            _role_conn = __import__('pymssql').connect(
                server=__import__('os').environ['SQL_SERVER'],
                user=__import__('os').environ.get('SQL_USERNAME') or __import__('os').environ.get('SQL_USER'),
                password=__import__('os').environ['SQL_PASSWORD'],
                database=__import__('os').environ.get('SQL_DATABASE','naijafoodmarket-live'),
                timeout=10, as_dict=True)
            _role_cur = _role_conn.cursor()
            _clean = phone.replace('+','').strip()
            _role_cur.execute(
                "SELECT role FROM dbo.User_Roles WHERE phone_number=%s OR phone_number=%s",
                (_clean, f"+{_clean}"))
            _role_row = _role_cur.fetchone()
            _role_conn.close()
            _user_role = (_role_row.get('role') or '').upper() if _role_row else ''
        except Exception as _re:
            import logging as _rl; _rl.error(f"[v2.2] role lookup error: {_re}")
            _user_role = ''

        if _user_role == 'VALIDATOR':
            v_session = get_session(phone) or {}
            v_session['_flow'] = 'VALIDATOR_MENU'
            save_session(phone, v_session)
            mod('validator.menu').handle_validator(phone, message, v_session)
            return func.HttpResponse('OK', status_code=200)

        if _user_role == 'TRADER':
            # [audit wa-v113] log trader inbound activity (NOT a login event —
            # WA is stateless; this fires on every inbound trader message)
            try:
                from shared.db import log_activity as _log_act
                _log_act(phone_number=phone, platform="WA", event_type="WA_TRADER_ACTIVE")
            except Exception:
                pass
            t_rec = _get_trader_record(phone)
            if t_rec.get('registration_status') == 'APPROVED' and not t_rec.get('is_suspended'):
                t_session = get_session(phone) or {}
                # [audit wa-v113] log trader menu view
                try:
                    from shared.db import log_activity as _log_act2
                    _log_act2(phone_number=phone, platform="WA", event_type="MENU_VIEWED")
                except Exception:
                    pass
                # W6.1 — also log to Reporter_Activity_Log
                try:
                    from shared.db import log_reporter_activity
                    log_reporter_activity(phone, 'WA_MENU_VIEWED',
                                          source_system='func-naijamarket-wa')
                except Exception:
                    pass
                mod('trader.menu').handle_trader_menu(phone, message, t_session)
            else:
                t_session = get_session(phone) or {}
                if not t_session.get('_flow'):
                    t_session['_flow'] = 'TRADER_KYC'
                save_session(phone, t_session)
                mod('trader.kyc').handle_kyc(phone, message, t_session, t_rec)
            return func.HttpResponse('OK', status_code=200)

        # ── Consumer context ──────────────────────────────────────────────
        consumer = _get_consumer(phone, mod)

        # ── Unregistered user → welcome flow ─────────────────────────────
        if not consumer.get('consumer_id') and _user_role == '':
            from shared.unregistered import is_blocked, get_step
            # Check block first
            _blocked, _block_msg = is_blocked(phone)
            if _blocked:
                send_message(phone, _block_msg)
                return func.HttpResponse("OK", status_code=200)
            # Route based on step in Unregistered_Exit_Log (never Consumer_Query_Sessions)
            _unreg_step, _unreg_data = get_step(phone)
            if _unreg_step in ("LANG_PICK", "REF_PICK_EARLY", "NAME_PICK", "AGE_PICK", "GENDER_PICK", "STATE_PICK", "TC_ACCEPT"):
                # Mid-registration — build minimal session dict for handle_welcome
                _fake_session = {"_flow": "WELCOME", "_step": _unreg_step, **_unreg_data}
                mod("consumer.welcome").handle_welcome(phone, message, _fake_session, {})
            elif _unreg_step == "FIRST_CONTACT":
                # FIX (wa-v127): this step was never routed — first-contact
                # 1/2/3 replies were silently swallowed and re-shown sample
                # prices regardless of user choice, since the dawn of the
                # FIRST_CONTACT feature. Pre-existing bug, not a v126
                # regression. This is what makes welcome option 2 (and
                # options 1/3) actually process the user's reply.
                _fake_session = {"_flow": "WELCOME", "_step": "FIRST_CONTACT"}
                mod("consumer.welcome").handle_welcome(phone, message, _fake_session, {})
            elif _unreg_step == "REGISTER_PROMPT":
                _fake_session = {"_flow": "WELCOME", "_step": "REGISTER_PROMPT"}
                mod("consumer.welcome").handle_welcome(phone, message, _fake_session, {})
            else:
                mod("consumer.welcome").start_welcome(phone)
            return func.HttpResponse("OK", status_code=200)
        # ─────────────────────────────────────────────────────────────────

        from shared.query_limit import check_query_limit

        # ── [1m] Session expiry detection ─────────────────────────────────
        session = get_session(phone) or {}
        if _session_expired(session):
            lang = get_lang(session, consumer)
            clear_session(phone)
            session = {}
            send_message(phone, t(lang, "session_expired"))

        # ── Expiry warning injection ──────────────────────────────────────
        if consumer:
            lang = get_lang(session, consumer)
            expiry_warn = _check_expiry_warning(consumer, lang, t)
            if expiry_warn:
                send_message(phone, expiry_warn)

        # ── Active flow continuation ──────────────────────────────────────
        current_flow = session.get("_flow")
        # Safety net: a CONSUMER should never be stuck in trader KYC — unstick them
        if current_flow == "TRADER_KYC" and _user_role == "CONSUMER":
            clear_session(phone)
            session = {}
            consumer = _get_consumer(phone, mod)
            current_flow = None
        if current_flow:
            FLOW_MAP = {
                "PRICES":         ("consumer.prices",       "handle_prices",       phone, message, session, consumer),
                "ARBITRAGE":      ("consumer.arbitrage",    "handle_arbitrage",    phone, message, session, consumer),
                "ALERTS":         ("consumer.alerts",       "handle_alerts",       phone, message, session, consumer),
                "COMPARE":        ("consumer.compare",      "handle_compare",      phone, message, session, consumer),
                "TREND":          ("consumer.trend",        "handle_trend",        phone, message, session, consumer),
                "SNAPSHOT":       ("consumer.snapshot",     "handle_snapshot",     phone, message, session, consumer),
                "NFPI":           ("consumer.nfpi",         "handle_nfpi",         phone, message, session, consumer),
                "BULK":           ("consumer.bulk",         "handle_bulk",         phone, message, session, consumer),
                "FORECAST":       ("consumer.forecast",     "handle_forecast",     phone, message, session, consumer),
                "BRIEF":          ("consumer.brief",        "handle_brief",        phone, message, session, consumer),
                "FAVORITES":      ("consumer.favorites",    "handle_favorites",    phone, message, session, consumer),
                "FILTER":         ("consumer.filter_prices","handle_filter",       phone, message, session, consumer),
                "EXPORT":         ("consumer.export_data",  "handle_export",       phone, message, session, consumer),
                "CALC":           ("consumer.calc",         "handle_calc",         phone, message, session, consumer),
                "BASKET":         ("consumer.basket",       "handle_basket",       phone, message, session, consumer),
                "INVITE":         ("consumer.invite",       "handle_invite",       phone, message, session, consumer),
                "HISTORY":        ("consumer.history",      "handle_history",      phone, message, session, consumer),
                "TOKENS":         ("consumer.tokens",       "handle_tokens_flow",  phone, message, session, consumer),
                "TOKEN_WALLET":   ("consumer.token_wallet", "handle_token_wallet", phone, message, session, consumer),
                "STATUS":         ("consumer.status",       "handle_status",       phone, message, session, consumer),
                "DOWNGRADE":      ("consumer.downgrade",    "handle_downgrade",    phone, message, session, consumer),
                "LANG":           ("consumer.lang_flow",    "handle_lang",         phone, message, session, consumer),
                "REPORT":         ("consumer.report",       "handle_report",       phone, message, session, consumer),
                "NBS_COMPARE":    ("shared.nbs_compare",    "handle_nbs_compare",  phone, message, session, consumer),
                # Trader flows
                "TRADER_KYC":     ("trader.kyc",            "handle_kyc",          phone, message, session),
                "TRADER_SUBMIT":  ("trader.submit",         "handle_submit",       phone, message, session),
                # Validator flows
                "VALIDATOR_MENU": ("validator.menu",        "handle_validator",    phone, message, session),
            }
            entry_cfg = FLOW_MAP.get(current_flow)
            if entry_cfg:
                module_name = entry_cfg[0]
                func_name   = entry_cfg[1]
                args        = entry_cfg[2:]
                result = getattr(mod(module_name), func_name)(*args)
                if result:
                    send_message(phone, result)
                session["_rate_count"] = _pre_session.get("_rate_count", 1)
                session["_rate_reset"] = _pre_session.get("_rate_reset", 0)
                return func.HttpResponse("OK", status_code=200)

        # ── Menu/start keywords — unregistered users get welcome ─────────
        if msg in ("menu", "start", "hi", "hello"):
            if not consumer.get("consumer_id"):
                mod("consumer.welcome").start_welcome(phone)
                return func.HttpResponse("OK", status_code=200)
            mod("consumer.menu").show_main_menu(phone)
            return func.HttpResponse("OK", status_code=200)

        # ── Digest opt-in intercept ───────────────────────────────────────
        if msg in ("digest on", "digest off", "digest"):
            mod("consumer.digest").handle_digest(phone, message, session, consumer)
            return func.HttpResponse("OK", status_code=200)

        # ── wa-v101: WAITLIST keyword ─────────────────────────────────────
        if msg == "waitlist":
            try:
                from shared.waitlist import is_on_waitlist, get_position, get_my_code
                if is_on_waitlist(phone):
                    _pos  = get_position(phone)
                    _info = get_my_code(phone)
                    _code = _info.get('code', '')
                    _refs = _info.get('referral_count', 0)
                    _bonus = _info.get('bonus_searches', 0)
                    send_message(phone,
                        f"✅ *You're on the waitlist!*\n\n"
                        f"📍 Position: *#{_pos}*\n"
                        f"🔗 Your referral code: *{_code}*\n"
                        f"👥 Friends referred: *{_refs}*\n"
                        f"🎁 Bonus searches earned: *{_bonus}*\n\n"
                        f"We'll notify you here on WhatsApp when your slot opens.")
                else:
                    # Not on waitlist yet — start full registration
                    if not consumer.get('consumer_id'):
                        mod('consumer.welcome').start_welcome(phone)
                    else:
                        from shared.waitlist import join_waitlist
                        _wl = join_waitlist(phone, source='whatsapp_bot')
                        _pos  = _wl.get('position', -1)
                        _code = _wl.get('code', '')
                        send_message(phone,
                            f"🎉 *You're on the waitlist!*\n\n"
                            f"📍 Position: *#{_pos}*\n"
                            f"🔗 Your referral code: *{_code}*\n\n"
                            f"Share your code with friends — each person who joins "
                            f"earns you *1 bonus search* at launch.")
            except Exception as _wle:
                import logging as _wll
                _wll.error(f"[v2.2] waitlist keyword error: {_wle}")
                send_message(phone, "Sorry, something went wrong. Please try again.")
            return func.HttpResponse("OK", status_code=200)

        # ── wa-v101: REFER keyword ─────────────────────────────────────────
        if msg == "refer":
            try:
                from shared.waitlist import is_on_waitlist, get_my_code, get_position
                if is_on_waitlist(phone):
                    _info  = get_my_code(phone)
                    _code  = _info.get('code', '')
                    _refs  = _info.get('referral_count', 0)
                    _bonus = _info.get('bonus_searches', 0)
                    _pos   = get_position(phone)
                    send_message(phone,
                        f"🔗 *Your Referral Code: {_code}*\n\n"
                        f"Share this code with friends. When they join the waitlist "
                        f"using your code, you *both move up* and you earn "
                        f"*1 bonus search* at launch.\n\n"
                        f"📍 Your current position: *#{_pos}*\n"
                        f"👥 Friends referred: *{_refs}*\n"
                        f"🎁 Bonus searches earned: *{_bonus}*\n\n"
                        f"_Referral codes are valid for the first 2 weeks after launch._")
                else:
                    send_message(phone,
                        "You're not on the waitlist yet.\n\n"
                        "Type *WAITLIST* to join and get your referral code.")
            except Exception as _rfe:
                import logging as _rfl
                _rfl.error(f"[v2.2] refer keyword error: {_rfe}")
                send_message(phone, "Sorry, something went wrong. Please try again.")
            return func.HttpResponse("OK", status_code=200)
        # ── end wa-v101 keywords ───────────────────────────────────────────

        KEYWORD_MAP = {
            "1": "consumer.prices",      "prices": "consumer.prices",
            "2": "consumer.arbitrage",   "arbitrage": "consumer.arbitrage",
            "3": "consumer.alerts",      "alerts": "consumer.alerts",      "myalerts": "consumer.alerts",
            "4": "consumer.compare",     "compare": "consumer.compare",
            "5": "consumer.trend",       "trend": "consumer.trend",
            "6": "consumer.snapshot",    "snapshot": "consumer.snapshot",
            "7": "consumer.nfpi",        "nfpi": "consumer.nfpi",
            "8": "consumer.bulk",        "bulk": "consumer.bulk",
            "9": "consumer.forecast",    "forecast": "consumer.forecast",
            "10": "consumer.brief",      "brief": "consumer.brief",
            "favorites": "consumer.favorites",    "fav": "consumer.favorites",
            "filter": "consumer.filter_prices",
            "export": "consumer.export_data",
            "calc": "consumer.calc",
            "basket": "consumer.basket",
            "a": "consumer.basket",
            "b": "consumer.invite",
            "c": "consumer.status",
            "d": "consumer.tokens",
            "e": "consumer.favorites",
            "f": "consumer.calc",
            "g": "consumer.export_data",
            "h": "consumer.downgrade",
            "downgrade": "consumer.downgrade",
            "invite": "consumer.invite",
            "history": "consumer.history",
            "i": "consumer.history",
            "tokens": "consumer.tokens",          "wallet": "consumer.token_wallet",
            "token wallet": "consumer.token_wallet", "buy tokens": "consumer.token_wallet",
            "upgrade": "consumer.tokens",         "subscribe": "consumer.tokens",
            "status": "consumer.status",          "mystatus": "consumer.status",
            "qp": "consumer.prices",              "quick": "consumer.prices",
            "p": "consumer.prices",
        }

        ENTRY_FUNCS = {
            "consumer.prices":        "handle_prices",
            "consumer.arbitrage":     "handle_arbitrage",
            "consumer.alerts":        "handle_alerts",
            "consumer.compare":       "handle_compare",
            "consumer.trend":         "handle_trend",
            "consumer.snapshot":      "handle_snapshot",
            "consumer.nfpi":          "handle_nfpi",
            "consumer.bulk":          "handle_bulk",
            "consumer.forecast":      "handle_forecast",
            "consumer.brief":         "handle_brief",
            "consumer.favorites":     "handle_favorites",
            "consumer.filter_prices": "handle_filter",
            "consumer.export_data":   "handle_export",
            "consumer.calc":          "handle_calc",
            "consumer.basket":        "handle_basket",
            "consumer.invite":        "handle_invite",
            "consumer.history":       "handle_history",
            "consumer.tokens":        "handle_tokens_flow",
            "consumer.token_wallet":  "handle_token_wallet",
            "consumer.status":        "handle_status",
            "consumer.downgrade":     "handle_downgrade",
        }

        target_module = KEYWORD_MAP.get(msg)
        if target_module:
            PRICE_MODULES = {
                "consumer.prices", "consumer.arbitrage", "consumer.compare",
                "consumer.trend",  "consumer.snapshot",  "consumer.nfpi",
                "consumer.bulk",   "consumer.forecast",  "consumer.brief",
                "consumer.filter_prices", "consumer.export_data"
            }
            if target_module in PRICE_MODULES and consumer:
                try:
                    allowed, limit_msg = check_query_limit(phone, consumer)
                    if not allowed:
                        send_message(phone, limit_msg)
                        return func.HttpResponse("OK", status_code=200)
                except Exception as _qle:
                    logging.error(f"[router] check_query_limit CRASH: {_qle}", exc_info=True)
            fn     = ENTRY_FUNCS.get(target_module, "handle_flow")
            result = getattr(mod(target_module), fn)(phone, message, {}, consumer)
            if result:
                send_message(phone, result)
            return func.HttpResponse("OK", status_code=200)

        # ── [1k] Free-text commodity search fallback ──────────────────────
        if len(msg) >= 3 and not msg.isdigit() and msg not in (
            "submit", "price", "submitprice", "register", "trader", "join",
            "menu", "start", "hi", "hello", "stop", "optout",
            "unsubscribe", "opt-out", "share", "report", "digest",
            "downgrade", "status", "history", "invite",
            "calc", "export", "favorites", "basket", "help", "lang"
        ):
            from shared.search import search_commodity
            hit = search_commodity(message)
            if hit:
                lang = get_lang(session, consumer)
                send_message(phone, t(lang, "search_found", item=hit["item_name"]))
                result = mod("consumer.prices").handle_prices(
                    phone, hit["item_name"], {}, consumer
                )
                if result:
                    send_message(phone, result)
                return func.HttpResponse("OK", status_code=200)
            lang = get_lang(session, consumer)
            send_message(phone, t(lang, "search_not_found", q=message[:40]))
            return func.HttpResponse("OK", status_code=200)

        # ── Default: show main menu ───────────────────────────────────────
        # ── Default: show main menu (registered) or welcome (unregistered) ──
        if not consumer.get("consumer_id"):
            mod("consumer.welcome").start_welcome(phone)
        else:
            mod("consumer.menu").show_main_menu(phone)
        return func.HttpResponse("OK", status_code=200)

    except Exception as e:
        logging.error(f"[v2.2] FATAL: {e}", exc_info=True)
        return func.HttpResponse("OK", status_code=200)


def _check_expiry_warning(consumer: dict, lang: str, t_fn) -> str:
    """Return warning string if subscription expires within 3 days, else empty."""
    try:
        end_raw = (consumer or {}).get("subscription_end_date")
        tier    = (consumer or {}).get("subscription_tier", "FREE").upper()
        if not end_raw or tier == "FREE":
            return ""
        end_dt = end_raw if hasattr(end_raw, "date") else datetime.fromisoformat(str(end_raw))
        now    = datetime.now(timezone.utc)
        if end_dt.tzinfo is None:
            end_dt = end_dt.replace(tzinfo=timezone.utc)
        days = (end_dt - now).days
        if days <= 0: return t_fn(lang, "expiry_today",      tier=tier)
        if days == 1: return t_fn(lang, "expiry_warning_1d", tier=tier)
        if days <= 3: return t_fn(lang, "expiry_warning_3d", tier=tier, days=days)
    except Exception as _e:
        logging.error(f"[expiry_check] {_e}")
    return ""


def _trader_reg_in_progress(phone):
    """True if this phone has an IN_PROGRESS Trader_Reg_Sessions row.
    Fail-safe: on any DB error, returns False so the user is RELEASED rather
    than trapped in the flow (they can re-send register/trader/join/reporter
    to restart). Trades a rare 'kicked out on transient error' for never-stuck.
    Matches both phone and +phone formats defensively in case the inbound
    number format varies between messages."""
    try:
        import pymssql, os
        _c = pymssql.connect(
            server=os.environ['SQL_SERVER'],
            user=os.environ.get('SQL_USERNAME') or os.environ.get('SQL_USER'),
            password=os.environ['SQL_PASSWORD'],
            database=os.environ.get('SQL_DATABASE', 'naijafoodmarket-live'),
            timeout=10, as_dict=True)
        _cu = _c.cursor()
        _clean = phone.lstrip('+')
        _cu.execute(
            "SELECT TOP 1 1 AS x FROM dbo.Trader_Reg_Sessions "
            "WHERE (phone_number=%s OR phone_number=%s) AND status='IN_PROGRESS'",
            (_clean, f"+{_clean}"))
        _row = _cu.fetchone()
        _c.close()
        return bool(_row)
    except Exception as _e:
        import logging
        logging.error(f"[trader.register] _trader_reg_in_progress error: {_e}")
        return False


def _get_consumer(phone: str, mod) -> dict:
    try:
        return mod("shared.db").get_consumer(phone) or {}
    except Exception:
        return {}


def _get_trader_record(phone: str) -> dict:
    try:
        import pymssql
        conn = pymssql.connect(
            server   = os.environ["SQL_SERVER"],
            user     = os.environ.get("SQL_USERNAME") or os.environ.get("SQL_USER"),
            password = os.environ["SQL_PASSWORD"],
            database = os.environ.get("SQL_DATABASE", "naijafoodmarket-live"),
            timeout  = 10, as_dict=True,
        )
        cur = conn.cursor()
        _clean = phone.lstrip("+").strip()
        cur.execute(
            "SELECT trader_id, registration_status, is_suspended "
            "FROM dbo.Traders_register WHERE phone_number = %s OR phone_number = %s",
            (_clean, f"+{_clean}")
        )
        row = cur.fetchone()
        conn.close()
        return row or {}
    except Exception:
        return {}
