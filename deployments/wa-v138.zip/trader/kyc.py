"""
trader/kyc.py — Trader registration status handler + PWA fallback redirect.

Branches on registration_status/is_suspended when a trader record is known:
  - is_suspended      -> kyc_suspended message
  - PENDING_APPROVAL  -> reg_pending message (reused from existing i18n key)
  - no record / other -> kyc_redirect (PWA fallback, corrected BVN/₦20 copy)

NOTE: as of this build, genuinely-unregistered users (brand-new numbers
typing register/trader/join/reporter) are routed to trader.register instead
of this function — see whatsapp_main/__init__.py line ~440. This handler now
primarily serves existing TRADER-role users who are not yet APPROVED
(called from whatsapp_main/__init__.py line ~500 with their trader_record).
"""
def handle_kyc(phone, message="", session=None, trader_record=None, *args):
    from shared.sender import send_message
    from shared.trader_i18n import tt
    from shared.trader_lang import get_trader_lang

    lang = "en"
    try:
        from shared.db import get_connection
        conn = get_connection()
        cur  = conn.cursor(as_dict=True)
        p = (phone or "").lstrip("+").strip()
        cur.execute(
            "SELECT preferred_language FROM dbo.Traders_register "
            "WHERE phone_number = %s OR phone_number = %s",
            (p, f"+{p}")
        )
        row = cur.fetchone()
        conn.close()
        lang = get_trader_lang(row or {})
    except Exception:
        lang = "en"

    rec = trader_record or {}
    status = rec.get("registration_status")
    suspended = rec.get("is_suspended")

    if suspended:
        send_message(phone, tt(lang, "kyc_suspended"))
        try:
            from shared.db import log_activity
            log_activity(phone_number=phone, platform="WA", event_type="KYC_SUSPENDED_NOTICE")
        except Exception:
            pass
        return

    if status == "PENDING_APPROVAL":
        send_message(phone, tt(lang, "reg_pending", status="Pending Approval"))
        try:
            from shared.db import log_activity
            log_activity(phone_number=phone, platform="WA", event_type="KYC_PENDING_NOTICE")
        except Exception:
            pass
        return

    # Fallback — no usable trader_record (genuinely unregistered edge case,
    # or an unrecognized status value).
    send_message(phone, tt(lang, "kyc_redirect"))
    try:
        from shared.db import log_activity
        log_activity(phone_number=phone, platform="WA", event_type="KYC_REDIRECT_PWA")
    except Exception:
        pass
