"""
validator/vote.py — Thin wrapper that calls usp_Validate_Submission.
All consensus logic is in the SP. This file only calls the SP and
formats the WhatsApp response message.
"""
import logging
import os


def _get_conn():
    import pymssql
    return pymssql.connect(
        server   = os.environ['SQL_SERVER'],
        user     = os.environ.get('SQL_USERNAME') or os.environ.get('SQL_USER'),
        password = os.environ['SQL_PASSWORD'],
        database = os.environ.get('SQL_DATABASE', 'naijafoodmarket-live'),
        timeout  = 30,
        as_dict  = True,
    )


def cast_vote(phone: str, validator_id: str, submission_id: str,
              vote: str, item_name: str = '', market: str = '') -> str:
    """
    Call usp_Validate_Submission and return a formatted WhatsApp message.
    Phone passed as-is — SP normalizes by stripping leading +.
    Never raises — all errors returned as user-friendly strings.
    """
    vote_icon = '\u2705' if vote == 'APPROVE' else '\u274c'

    try:
        conn = _get_conn()
        cur  = conn.cursor()
        cur.execute(
            "EXEC dbo.usp_Validate_Submission %s, %s, %s, %s",
            (submission_id, phone, validator_id, vote)
        )
        row = cur.fetchone()
        conn.commit()
        conn.close()
    except Exception as e:
        logging.error(f'[validator.vote] SP call failed: {e}')
        return (
            "\u274c *Vote failed \u2014 please try again.*\n\n"
            "Type *pending* to see your assignments\n"
            "Type *menu* to go back."
        )

    if not row:
        return (
            "\u274c *Vote could not be recorded.*\n\n"
            "This submission may have already been decided.\n\n"
            "Type *pending* for more assignments."
        )

    result = (row.get('result') or '').upper()

    if result == 'VOTE_RECORDED':
        approve_votes = row.get('approve_votes', '0')
        reject_votes  = row.get('reject_votes', '0')
        return (
            f"{vote_icon} *Vote Recorded!*\n"
            f"\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\n\n"
            f"\U0001f4e6 {item_name or 'Item'} @ {market or 'Market'}\n"
            f"Your vote: *{vote}*\n\n"
            f"Votes so far: \u2705 {approve_votes} | \u274c {reject_votes}\n"
            f"Waiting for more validators...\n\n"
            f"\U0001f4b0 You'll earn \u20a650 if your vote matches consensus.\n\n"
            f"Type *pending* for more assignments\n"
            f"Type *vbalance* to check earnings"
        )

    elif result == 'APPROVED':
        earned = vote == 'APPROVE'
        return (
            f"{vote_icon} *Vote Recorded \u2014 CONSENSUS REACHED!*\n"
            f"\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\n\n"
            f"\U0001f4e6 {item_name or 'Item'} @ {market or 'Market'}\n"
            f"Your vote: *{vote}*\n"
            f"Outcome: \u2705 *APPROVED*\n\n"
            f"{chr(0x1f4b0) + ' \u20a650 queued to your airtime!' if earned else chr(0x274c) + ' Your vote did not match consensus \u2014 no reward.'}\n\n"
            f"Type *pending* for more assignments\n"
            f"Type *vbalance* to check earnings"
        )

    elif result == 'REJECTED':
        earned = vote == 'REJECT'
        return (
            f"{vote_icon} *Vote Recorded \u2014 CONSENSUS REACHED!*\n"
            f"\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\n\n"
            f"\U0001f4e6 {item_name or 'Item'} @ {market or 'Market'}\n"
            f"Your vote: *{vote}*\n"
            f"Outcome: \u274c *REJECTED*\n\n"
            f"{chr(0x1f4b0) + ' \u20a650 queued to your airtime!' if earned else chr(0x274c) + ' Your vote did not match consensus \u2014 no reward.'}\n\n"
            f"Type *pending* for more assignments\n"
            f"Type *vbalance* to check earnings"
        )

    elif result == 'AUTO_APPROVED':
        return (
            f"\u2705 *Submission Auto-Approved*\n"
            f"\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\n\n"
            f"This trader has exceeded the auto-approval threshold.\n"
            f"No validator action required.\n\n"
            f"Type *pending* for more assignments."
        )

    else:
        logging.warning(f'[validator.vote] unexpected SP result: {result}')
        return (
            f"{vote_icon} *Vote processed.*\n\n"
            f"Type *pending* for more assignments\n"
            f"Type *vbalance* to check earnings"
        )
