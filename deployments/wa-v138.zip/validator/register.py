import logging, os, uuid, requests
from datetime import datetime, date, timezone
from shared.db import get_connection
from shared.sender import send_message
from validator.banks import BANKS, BANK_LIST_MSG, get_bank_code


class RoleConflictError(Exception):
    """Phone already holds a conflicting TRADER/VALIDATOR role (Rule 2)."""
    pass


NIGERIAN_STATES = [
    "Abia","Adamawa","Akwa Ibom","Anambra","Bauchi","Bayelsa","Benue",
    "Borno","Cross River","Delta","Ebonyi","Edo","Ekiti","Enugu","FCT",
    "Gombe","Imo","Jigawa","Kaduna","Kano","Katsina","Kebbi","Kogi",
    "Kwara","Lagos","Nasarawa","Niger","Ogun","Ondo","Osun","Oyo",
    "Plateau","Rivers","Sokoto","Taraba","Yobe","Zamfara"
]
STATE_LIST_MSG = "\n".join(f"{i+1}. {s}" for i, s in enumerate(NIGERIAN_STATES))

TC_TEXT = """*NaijaMarket Intel — Validator Terms*

By joining as a validator, you agree to:
1. Submit HONEST votes based on physical market observation
2. Be present within 500m of your assigned market when voting
3. Never collude with traders or other validators
4. Maintain at least 60% accuracy rate
5. Respond to assignments within 30 minutes

Violations result in immediate suspension and forfeiture of balance.

Reply *ACCEPT* to agree, or *CANCEL* to exit."""

MAX_INVITE_ATTEMPTS = 3
MAX_BANK_ATTEMPTS = 3


def _get_or_create_session(phone):
    """
    Returns session as dict from DB row (as_dict=True cursor — no zip).
    Creates new IN_PROGRESS row if none exists.
    """
    conn = get_connection()
    cur = conn.cursor()
    cur.execute("""
        SELECT session_id, step, status, invite_code, invite_code_valid,
               invite_code_market_id, invite_code_market_name,
               full_name, first_name, last_name, date_of_birth,
               address, state, bank_name, bank_code, account_number,
               bank_account_name, invite_code_attempts, bank_verification_attempts,
               error_count, preferred_language
        FROM dbo.Validator_Reg_Sessions
        WHERE phone_number=%s AND status='IN_PROGRESS'
        ORDER BY started_at DESC
    """, (phone,))
    row = cur.fetchone()  # dict because get_connection() uses as_dict=True
    conn.close()

    if row:
        # row is already a dict — coerce numeric fields, return directly
        row["step"]                       = int(row.get("step") or 1)
        row["invite_code_attempts"]       = int(row.get("invite_code_attempts") or 0)
        row["bank_verification_attempts"] = int(row.get("bank_verification_attempts") or 0)
        row["error_count"]                = int(row.get("error_count") or 0)
        return row

    # No existing session — create one
    session_id = f"VRS-{uuid.uuid4().hex[:12].upper()}"
    conn = get_connection()
    cur = conn.cursor()
    cur.execute("""
        INSERT INTO dbo.Validator_Reg_Sessions
          (session_id, phone_number, step, status, invite_code_attempts,
           bank_verification_attempts, error_count, started_at,
           last_activity_at, expires_at, created_at, updated_at)
        VALUES (%s,%s,1,'IN_PROGRESS',0,0,0,
                GETUTCDATE(),GETUTCDATE(),
                DATEADD(HOUR,24,GETUTCDATE()),
                GETUTCDATE(),GETUTCDATE())
    """, (session_id, phone))
    conn.commit()
    conn.close()
    return {
        "session_id": session_id, "step": 1, "status": "IN_PROGRESS",
        "invite_code_attempts": 0, "bank_verification_attempts": 0, "error_count": 0
    }


def _save_session(session_id, fields):
    if not fields:
        return
    sets = ", ".join(f"{k}=%s" for k in fields)
    sets += ", updated_at=GETUTCDATE(), last_activity_at=GETUTCDATE()"
    vals = list(fields.values()) + [session_id]
    conn = get_connection()
    cur = conn.cursor()
    cur.execute(
        f"UPDATE dbo.Validator_Reg_Sessions SET {sets} WHERE session_id=%s",
        vals
    )
    conn.commit()
    conn.close()


def _validate_invite_code(code, phone):
    conn = get_connection()
    cur = conn.cursor()
    cur.execute("""
        SELECT market_id, market_name, status, expires_at, used_by_phone
        FROM dbo.Validator_Invite_Codes
        WHERE invite_code=%s
    """, (code.upper().strip(),))
    row = cur.fetchone()
    conn.close()
    if not row:
        return {"valid": False, "reason": "not_found"}
    market_id   = row["market_id"]
    market_name = row["market_name"]
    status      = row["status"]
    expires_at  = row["expires_at"]
    used_by     = row["used_by_phone"]
    if status != 'ACTIVE':
        return {"valid": False, "reason": "used"}
    if expires_at and expires_at < datetime.utcnow():
        return {"valid": False, "reason": "expired"}
    if used_by and used_by != phone:
        return {"valid": False, "reason": "used"}
    return {"valid": True, "market_id": market_id, "market_name": market_name}


def _resolve_bank_account(account_number, bank_code):
    key = os.environ.get("PAYSTACK_SECRET_KEY", "")
    if not key:
        return {"valid": False, "reason": "no_key"}
    try:
        r = requests.get(
            "https://api.paystack.co/bank/resolve",
            params={"account_number": account_number, "bank_code": bank_code},
            headers={"Authorization": f"Bearer {key}"},
            timeout=15
        )
        data = r.json()
        if data.get("status") and data.get("data", {}).get("account_name"):
            return {"valid": True, "account_name": data["data"]["account_name"]}
        return {"valid": False, "reason": data.get("message", "unresolved")}
    except Exception as e:
        logging.error(f"[validator_reg] Paystack error: {e}")
        return {"valid": False, "reason": "timeout"}


def _complete_registration(session, phone):
    validator_id = f"VAL-{uuid.uuid4().hex[:8].upper()}"
    conn = get_connection()
    cur = conn.cursor()

    # ── Rule 2: dual-role prevention — a phone already registered as a
    #    TRADER (dbo.Traders_register) cannot also become a VALIDATOR.
    #    Phone formats differ across tables ('+' vs none) so match both. ──
    _clean = phone.replace("+", "").strip()
    cur.execute(
        "SELECT 1 FROM dbo.Traders_register "
        "WHERE phone_number=%s OR phone_number=%s",
        (_clean, f"+{_clean}"))
    if cur.fetchone():
        conn.close()
        raise RoleConflictError("TRADER")

    cur.execute("""
        INSERT INTO dbo.Validators (
            validator_id, phone_number, full_name, first_name, last_name,
            date_of_birth, address, state,
            assigned_market, market_id, assigned_at,
            bank_name, bank_code, account_number,
            bank_account_name, invite_code, registration_status,
            tc_version_accepted, tc_accepted_at,
            total_votes, correct_votes, approval_count, rejection_count,
            accuracy_rate, balance, current_balance, total_earned,
            status, tier, preferred_language,
            registered_at, created_at, updated_at
        ) VALUES (
            %s,%s,%s,%s,%s,
            %s,%s,%s,
            %s,%s,GETUTCDATE(),
            %s,%s,%s,
            %s,%s,'PENDING_APPROVAL',
            1,GETUTCDATE(),
            0,0,0,0,
            0,0.00,0.00,0,
            'ACTIVE','STANDARD',%s,
            GETUTCDATE(),GETUTCDATE(),GETUTCDATE()
        )
    """, (
        validator_id, phone,
        session.get("full_name"), session.get("first_name"), session.get("last_name"),
        session.get("date_of_birth"), session.get("address"), session.get("state"),
        session.get("invite_code_market_name"), session.get("invite_code_market_id"),
        session.get("bank_name"),
        str(session.get("bank_code", "")),      # string — Paystack codes have leading zeros
        str(session.get("account_number", "")), # string — preserves leading zeros
        session.get("bank_account_name"), session.get("invite_code"),
        session.get("preferred_language", "en")
    ))
    cur.execute("""
        INSERT INTO dbo.User_Roles (phone_number, role, assigned_at, created_at)
        VALUES (%s,'VALIDATOR',GETUTCDATE(),GETUTCDATE())
    """, (phone,))
    cur.execute("""
        UPDATE dbo.Validator_Invite_Codes
        SET status='USED', used_by_phone=%s, used_by_name=%s,
            used_at=GETUTCDATE(), updated_at=GETUTCDATE()
        WHERE invite_code=%s
    """, (phone, session.get("full_name"), session.get("invite_code")))
    cur.execute("""
        UPDATE dbo.Validator_Reg_Sessions
        SET status='COMPLETED', registration_successful=1,
            validator_id=%s, completed_at=GETUTCDATE(), updated_at=GETUTCDATE()
        WHERE session_id=%s
    """, (validator_id, session.get("session_id")))
    conn.commit()
    conn.close()
    return validator_id


def handle_validator_registration(phone, message):
    msg = message.strip()

    # ── Global exits ──────────────────────────────────────────────────────
    if msg.lower() in ("cancel", "exit", "quit", "00"):
        conn = get_connection()
        cur = conn.cursor()
        cur.execute("""
            UPDATE dbo.Validator_Reg_Sessions
            SET status='ABANDONED', abandoned_at=GETUTCDATE(), updated_at=GETUTCDATE()
            WHERE phone_number=%s AND status='IN_PROGRESS'
        """, (phone,))
        conn.commit()
        conn.close()
        send_message(phone,
            "\u274c Registration cancelled.\n\n"
            "Send *VAL-START* anytime to begin again, or type *menu* to return to the main menu.")
        return

    if msg.lower() == "menu":
        conn = get_connection()
        cur = conn.cursor()
        cur.execute("""
            UPDATE dbo.Validator_Reg_Sessions
            SET status='ABANDONED', abandoned_at=GETUTCDATE(), updated_at=GETUTCDATE()
            WHERE phone_number=%s AND status='IN_PROGRESS'
        """, (phone,))
        conn.commit()
        conn.close()
        from consumer.menu import show_main_menu
        show_main_menu(phone)
        return

    session = _get_or_create_session(phone)
    step    = session.get("step", 1)

    # ── Back navigation ───────────────────────────────────────────────────
    if msg == "0":
        if step <= 1:
            send_message(phone,
                "\u2139\ufe0f You are at the beginning of registration.\n\n"
                "Enter your *VAL-XXXXX* invite code to continue, or type *00* to exit.")
            return
        prev = step - 1
        _save_session(session["session_id"], {"step": prev})
        session["step"] = prev
        _resend_step_prompt(phone, prev, session)
        return

    session = _get_or_create_session(phone)
    step    = session.get("step", 1)

    # ── STEP 1: Invite code ───────────────────────────────────────────────
    if step == 1:
        if not msg or msg.upper() == "VAL-START":
            send_message(phone,
                "\U0001f44b *Welcome to NaijaMarket Intel Validator Registration*\n\n"
                "\U0001f4b0 You earn *\u20a650* for every submission you verify.\n\n"
                "\U0001f511 Enter your *VAL-XXXXX* invite code to begin.\n\n"
                "_Type *00* anytime to cancel and exit._")
            return
        attempts = session.get("invite_code_attempts", 0) + 1
        result   = _validate_invite_code(msg, phone)
        if not result["valid"]:
            if attempts >= MAX_INVITE_ATTEMPTS:
                _save_session(session["session_id"], {
                    "status": "BLOCKED", "invite_code_attempts": attempts
                })
                send_message(phone,
                    "\u26d4 Too many invalid attempts. Registration blocked.\n"
                    "Contact support if you have a valid invite code.")
                return
            reason_msg = {
                "not_found": "That code does not exist.",
                "used":      "That code has already been used.",
                "expired":   "That code has expired."
            }.get(result["reason"], "Invalid code.")
            _save_session(session["session_id"], {"invite_code_attempts": attempts})
            send_message(phone,
                f"\u274c {reason_msg}\n\n"
                f"Please check your code and try again. "
                f"({MAX_INVITE_ATTEMPTS - attempts} attempt(s) remaining)\n\n"
                f"_Type *00* to exit._")
            return
        _save_session(session["session_id"], {
            "step": 2,
            "invite_code":             msg.upper().strip(),
            "invite_code_valid":       1,
            "invite_code_market_id":   result["market_id"],
            "invite_code_market_name": result["market_name"],
            "invite_code_attempts":    attempts
        })
        send_message(phone,
            f"\u2705 *Code accepted!*\n"
            f"\U0001f3ea You will be assigned to *{result['market_name']}*\n\n"
            f"━━━━━━━━━━━━━━━━━━\n"
            f"*Step 1 of 7 \u2014 Full Name*\n"
            f"━━━━━━━━━━━━━━━━━━\n"
            f"\U0001f464 Enter your full name as it appears on your ID.\n"
            f"_(e.g. Amaka Okonkwo)_\n\n"
            f"_*0* = back \u2502 *00* = exit_")

    # ── STEP 2: Full name ─────────────────────────────────────────────────
    elif step == 2:
        parts = msg.strip().split()
        if len(parts) < 2:
            send_message(phone,
                "\u26a0\ufe0f Please enter your *full name* (first and last name).\n"
                "_(e.g. Amaka Okonkwo)_\n\n"
                "_*0* = back \u2502 *00* = exit_")
            return
        first = parts[0].capitalize()
        last  = " ".join(p.capitalize() for p in parts[1:])
        full  = f"{first} {last}"
        _save_session(session["session_id"], {
            "step": 3, "full_name": full,
            "first_name": first, "last_name": last
        })
        send_message(phone,
            f"\u2705 Name saved: *{full}*\n\n"
            f"━━━━━━━━━━━━━━━━━━\n"
            f"*Step 2 of 7 \u2014 Date of Birth*\n"
            f"━━━━━━━━━━━━━━━━━━\n"
            f"\U0001f382 Enter your date of birth: *DD/MM/YYYY*\n"
            f"_(e.g. 15/03/1990)_\n\n"
            f"_*0* = back \u2502 *00* = exit_")

    # ── STEP 3: Date of birth ─────────────────────────────────────────────
    elif step == 3:
        try:
            dob = datetime.strptime(msg.strip(), "%d/%m/%Y").date()
            age = (date.today() - dob).days // 365
            if age < 18:
                send_message(phone,
                    "\u26a0\ufe0f You must be at least 18 years old to register.\n\n"
                    "_*0* = back \u2502 *00* = exit_")
                return
            if age > 80:
                send_message(phone,
                    "\u26a0\ufe0f Invalid date of birth. Please check and try again.\n\n"
                    "_*0* = back \u2502 *00* = exit_")
                return
            _save_session(session["session_id"], {
                "step": 4, "date_of_birth": dob.isoformat()
            })
            send_message(phone,
                f"\u2705 DOB saved.\n\n"
                f"━━━━━━━━━━━━━━━━━━\n"
                f"*Step 3 of 7 \u2014 Home Address*\n"
                f"━━━━━━━━━━━━━━━━━━\n"
                f"\U0001f3e0 Enter your home address (street, area, city).\n"
                f"_(e.g. 12 Balogun Street, Surulere, Lagos)_\n\n"
                f"_*0* = back \u2502 *00* = exit_")
        except ValueError:
            send_message(phone,
                "\u274c Invalid format. Please use *DD/MM/YYYY*\n"
                "_(e.g. 15/03/1990)_\n\n"
                "_*0* = back \u2502 *00* = exit_")

    # ── STEP 4: Address ───────────────────────────────────────────────────
    elif step == 4:
        if len(msg.strip()) < 10:
            send_message(phone,
                "\u26a0\ufe0f Please enter your full address (at least 10 characters).\n\n"
                "_*0* = back \u2502 *00* = exit_")
            return
        _save_session(session["session_id"], {"step": 5, "address": msg.strip()})
        send_message(phone,
            f"\u2705 Address saved.\n\n"
            f"━━━━━━━━━━━━━━━━━━\n"
            f"*Step 4 of 7 \u2014 State*\n"
            f"━━━━━━━━━━━━━━━━━━\n"
            f"\U0001f4cd Select your state of residence:\n\n"
            f"{STATE_LIST_MSG}\n\n"
            f"Reply with the number.\n\n"
            f"_*0* = back \u2502 *00* = exit_")

    # ── STEP 5: State ─────────────────────────────────────────────────────
    elif step == 5:
        state = None
        if msg.strip().isdigit():
            idx = int(msg.strip()) - 1
            if 0 <= idx < len(NIGERIAN_STATES):
                state = NIGERIAN_STATES[idx]
        else:
            for s in NIGERIAN_STATES:
                if msg.strip().lower() in s.lower():
                    state = s
                    break
        if not state:
            send_message(phone,
                f"\u274c Invalid selection. Reply with a number (1-{len(NIGERIAN_STATES)}).\n\n"
                f"{STATE_LIST_MSG}\n\n"
                f"_*0* = back \u2502 *00* = exit_")
            return
        _save_session(session["session_id"], {"step": 6, "state": state})
        send_message(phone,
            f"\u2705 State: *{state}*\n\n"
            f"━━━━━━━━━━━━━━━━━━\n"
            f"*Step 5 of 7 \u2014 Bank*\n"
            f"━━━━━━━━━━━━━━━━━━\n"
            f"\U0001f3e6 Select your bank:\n\n"
            f"{BANK_LIST_MSG}\n\n"
            f"Reply with the number.\n\n"
            f"_*0* = back \u2502 *00* = exit_")

    # ── STEP 6: Bank selection ────────────────────────────────────────────
    elif step == 6:
        bank = get_bank_code(msg.strip())
        if not bank:
            send_message(phone,
                f"\u274c Invalid selection. Reply with a number (1-{len(BANKS)}).\n\n"
                f"{BANK_LIST_MSG}\n\n"
                f"_*0* = back \u2502 *00* = exit_")
            return
        _save_session(session["session_id"], {
            "step":                       7,
            "bank_name":                  bank["name"],
            "bank_code":                  str(bank["code"]),
            "bank_verification_attempts": 0
        })
        send_message(phone,
            f"\u2705 Bank: *{bank['name']}*\n\n"
            f"━━━━━━━━━━━━━━━━━━\n"
            f"*Step 6 of 7 \u2014 Account Number*\n"
            f"━━━━━━━━━━━━━━━━━━\n"
            f"\U0001f4b3 Enter your 10-digit *{bank['name']}* account number.\n\n"
            f"_*0* = back \u2502 *00* = exit_")

    # ── STEP 7: Account number + Paystack resolve ─────────────────────────
    elif step == 7:
        acc = msg.strip().replace(" ", "")
        if not acc.isdigit() or len(acc) != 10:
            send_message(phone,
                "\u274c Account number must be exactly *10 digits*. Please try again.\n\n"
                "_*0* = back \u2502 *00* = exit_")
            return
        attempts  = session.get("bank_verification_attempts", 0) + 1
        bank_code = str(session.get("bank_code", ""))
        result    = _resolve_bank_account(acc, bank_code)
        if not result["valid"]:
            if attempts >= MAX_BANK_ATTEMPTS:
                _save_session(session["session_id"], {
                    "bank_verification_attempts": 0,
                    "step": 6
                })
                send_message(phone,
                    f"\u274c Could not verify account after {MAX_BANK_ATTEMPTS} attempts.\n"
                    f"Let\'s try a different bank.\n\n"
                    f"\U0001f3e6 *Select your bank:*\n\n{BANK_LIST_MSG}\n\n"
                    f"_*0* = back \u2502 *00* = exit_")
                return
            _save_session(session["session_id"], {
                "bank_verification_attempts": attempts,
                "account_number": acc
            })
            send_message(phone,
                f"\u274c Could not verify that account number with *{session.get('bank_name')}*.\n"
                f"Please check and try again. "
                f"({MAX_BANK_ATTEMPTS - attempts} attempt(s) remaining)\n\n"
                f"_*0* = back \u2502 *00* = exit_")
            return
        _save_session(session["session_id"], {
            "step":                       8,
            "account_number":             acc,
            "bank_account_name":          result["account_name"],
            "bank_verification_attempts": attempts,
            "bank_verification_status":   "VERIFIED"
        })
        send_message(phone,
            f"\u2705 *Account verified!*\n\n"
            f"\U0001f464 Account name: *{result['account_name']}*\n"
            f"\U0001f3e6 Bank: *{session.get('bank_name')}*\n\n"
            f"Is this correct?\n"
            f"\u2022 Reply *YES* to continue\n"
            f"\u2022 Reply *NO* to re-enter\n\n"
            f"_*00* = exit_")

    # ── STEP 8: Bank confirmation ─────────────────────────────────────────
    elif step == 8:
        if msg.upper() == "YES":
            _save_session(session["session_id"], {"step": 9})
            send_message(phone,
                f"━━━━━━━━━━━━━━━━━━\n"
                f"*Step 7 of 7 \u2014 Terms & Conditions*\n"
                f"━━━━━━━━━━━━━━━━━━\n\n"
                f"{TC_TEXT}")
        elif msg.upper() == "NO":
            _save_session(session["session_id"], {
                "step": 6, "bank_verification_attempts": 0
            })
            send_message(phone,
                f"\U0001f3e6 *Select your bank:*\n\n{BANK_LIST_MSG}\n\n"
                f"_*0* = back \u2502 *00* = exit_")
        else:
            send_message(phone,
                "Reply *YES* to confirm or *NO* to re-enter your bank details.\n\n"
                "_*00* = exit_")

    # ── STEP 9: T&C acceptance ────────────────────────────────────────────
    elif step == 9:
        if msg.upper() == "ACCEPT":
            try:
                validator_id = _complete_registration(session, phone)
                first  = session.get("first_name") or (session.get("full_name") or "").split()[0]
                market = session.get("invite_code_market_name", "your market")
                send_message(phone,
                    f"\U0001f389 *Welcome to NaijaMarket Intel, {first}!*\n\n"
                    f"\U0001f194 Your validator ID: *{validator_id}*\n"
                    f"\U0001f3ea Assigned market: *{market}*\n\n"
                    f"\u23f3 Your account is under review. You will receive a message "
                    f"within 24 hours once approved.\n\n"
                    f"After approval, type *menu* to access your validator dashboard.")
            except RoleConflictError:
                _save_session(session["session_id"], {"status": "ABANDONED"})
                send_message(phone,
                    "\u26d4 *Role Conflict*\n\n"
                    "This number is already registered as a *price reporter (trader)*.\n\n"
                    "Each phone number can only have one role on NaijaMarket Intel. "
                    "If you believe this is an error, contact support.\n\n"
                    "Type *menu* to go back.")
            except Exception as e:
                # DB trigger backstop: dual-role block raised at INSERT time
                if "50001" in str(e) or "DUAL_ROLE_BLOCKED" in str(e):
                    _save_session(session["session_id"], {"status": "ABANDONED"})
                    send_message(phone,
                        "\u26d4 *Role Conflict*\n\n"
                        "This number is already registered as a *price reporter (trader)*.\n\n"
                        "Each phone number can only have one role on NaijaMarket Intel. "
                        "If you believe this is an error, contact support.\n\n"
                        "Type *menu* to go back.")
                else:
                    logging.error(f"[validator_reg] complete error: {e}", exc_info=True)
                    send_message(phone,
                        "\u26a0\ufe0f Registration saved but we hit a technical issue finalising your account. "
                        "Our team will complete your setup within 24 hours.")
        elif msg.upper() == "CANCEL":
            _save_session(session["session_id"], {"status": "ABANDONED"})
            send_message(phone,
                "\u274c Registration cancelled. Send *VAL-START* to begin again.")
        else:
            send_message(phone,
                f"{TC_TEXT}\n\n"
                f"_*00* = exit_")


def _resend_step_prompt(phone, step, session):
    """Resend the prompt for a given step when user goes back."""
    if step == 1:
        send_message(phone,
            "\U0001f519 *Back to Step 1*\n\n"
            "\U0001f511 Enter your *VAL-XXXXX* invite code.\n\n"
            "_Type *00* to exit._")
    elif step == 2:
        send_message(phone,
            "\U0001f519 *Back to Step 1 of 7 \u2014 Full Name*\n\n"
            "\U0001f464 Enter your full name as it appears on your ID.\n"
            "_(e.g. Amaka Okonkwo)_\n\n"
            "_*0* = back \u2502 *00* = exit_")
    elif step == 3:
        send_message(phone,
            "\U0001f519 *Back to Step 2 of 7 \u2014 Date of Birth*\n\n"
            "\U0001f382 Enter your date of birth: *DD/MM/YYYY*\n"
            "_(e.g. 15/03/1990)_\n\n"
            "_*0* = back \u2502 *00* = exit_")
    elif step == 4:
        send_message(phone,
            "\U0001f519 *Back to Step 3 of 7 \u2014 Home Address*\n\n"
            "\U0001f3e0 Enter your home address (street, area, city).\n"
            "_(e.g. 12 Balogun Street, Surulere, Lagos)_\n\n"
            "_*0* = back \u2502 *00* = exit_")
    elif step == 5:
        send_message(phone,
            f"\U0001f519 *Back to Step 4 of 7 \u2014 State*\n\n"
            f"\U0001f4cd Select your state of residence:\n\n"
            f"{STATE_LIST_MSG}\n\n"
            f"Reply with the number.\n\n"
            f"_*0* = back \u2502 *00* = exit_")
    elif step == 6:
        send_message(phone,
            f"\U0001f519 *Back to Step 5 of 7 \u2014 Bank*\n\n"
            f"\U0001f3e6 Select your bank:\n\n"
            f"{BANK_LIST_MSG}\n\n"
            f"Reply with the number.\n\n"
            f"_*0* = back \u2502 *00* = exit_")
    elif step == 7:
        bank_name = session.get("bank_name", "your bank")
        send_message(phone,
            f"\U0001f519 *Back to Step 6 of 7 \u2014 Account Number*\n\n"
            f"\U0001f4b3 Enter your 10-digit *{bank_name}* account number.\n\n"
            f"_*0* = back \u2502 *00* = exit_")
    elif step == 8:
        send_message(phone,
            "\U0001f519 *Back to Step 7 of 7 \u2014 Account Confirmation*\n\n"
            "Is your bank account correct?\n"
            "\u2022 Reply *YES* to continue\n"
            "\u2022 Reply *NO* to re-enter\n\n"
            "_*00* = exit_")
