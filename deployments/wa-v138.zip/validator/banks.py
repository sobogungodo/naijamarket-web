"""
validator/banks.py — Nigerian bank list with Paystack codes.
"""

BANKS = [
    {"name": "Access Bank", "code": "044"},
    {"name": "Citibank", "code": "023"},
    {"name": "Ecobank", "code": "050"},
    {"name": "Fidelity Bank", "code": "070"},
    {"name": "First Bank", "code": "011"},
    {"name": "First City Monument Bank", "code": "214"},
    {"name": "Guaranty Trust Bank", "code": "058"},
    {"name": "Heritage Bank", "code": "030"},
    {"name": "Keystone Bank", "code": "082"},
    {"name": "Kuda Bank", "code": "090267"},
    {"name": "Moniepoint", "code": "090405"},
    {"name": "OPay", "code": "100004"},
    {"name": "Palmpay", "code": "100033"},
    {"name": "Polaris Bank", "code": "076"},
    {"name": "Providus Bank", "code": "101"},
    {"name": "Stanbic IBTC", "code": "221"},
    {"name": "Standard Chartered", "code": "068"},
    {"name": "Sterling Bank", "code": "232"},
    {"name": "Taj Bank", "code": "302"},
    {"name": "Union Bank", "code": "032"},
    {"name": "United Bank for Africa", "code": "033"},
    {"name": "Unity Bank", "code": "215"},
    {"name": "VFD Microfinance Bank", "code": "566"},
    {"name": "Wema Bank", "code": "035"},
    {"name": "Zenith Bank", "code": "057"},
]

BANK_BY_CODE = {b["code"]: b["name"] for b in BANKS}
BANK_BY_NAME = {b["name"].lower(): b["code"] for b in BANKS}

BANK_LIST_MSG = "\n".join(
    f"{i+1}. {b['name']}" for i, b in enumerate(BANKS)
)


def get_bank_code(user_input: str) -> dict:
    user_input = user_input.strip()
    if user_input.isdigit():
        idx = int(user_input) - 1
        if 0 <= idx < len(BANKS):
            return BANKS[idx]
        return None
    lower = user_input.lower()
    for b in BANKS:
        if lower in b["name"].lower():
            return b
    return None
