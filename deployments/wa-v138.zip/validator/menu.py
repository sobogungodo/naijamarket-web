"""
validator/menu.py — Validator WhatsApp menu and flow dispatcher.

Handles all validator interactions:
  menu / 0       — Show validator main menu
  pending / 1    — Show pending validation assignments
  vbalance / 2   — Show earnings balance
  vhistory / 3   — Show vote history
  <number>       — Select assignment from pending list
  approve/reject — Cast vote (GPS location must be verified first)

GPS: validator must share live location within 500m of market before voting.
Location is captured by whatsapp_main router and stored in session as
_vlat / _vlon. This file checks for those keys before allowing vote.
"""
import logging
import os


def _get_conn():
    import pymssql
    return pymssql.connect(
        server   = os.environ['SQL_SERVER'],
        user     = os.environ.get('SQL_USERNAME') or os.environ.get('SQL_USER'),
        password = os.environ['SQL_PASSWORD'],
        database = os.environ.get('SQL_DATABASE', 'naijafoodmarket-live'),
        timeout  = 30,
        as_dict  = True,
    )


def _fmt(n):
    try:
        return f"\u20a6{float(n):,.0f}"
    except Exception:
        return str(n) if n else '\u20a60'


def _get_validator(phone):
    try:
        conn = _get_conn()
        cur  = conn.cursor()
        cur.execute("""
            SELECT validator_id, phone_number, registration_status
            FROM   dbo.Validators
            WHERE  phone_number = %s OR phone_number = %s
        """, (phone, phone.lstrip('+')))
        row = cur.fetchone()
        conn.close()
        return row
    except Exception as e:
        logging.error(f'[validator.menu] get_validator error: {e}')
        return None


def _get_pending(phone):
    norm = phone.lstrip('+')
    try:
        conn = _get_conn()
        cur  = conn.cursor()
        cur.execute("""
            SELECT TOP 5
                queue_id, submission_id, item, market, price, unit,
                price_range_min, price_range_max, created_at
            FROM   dbo.Validation_Queue
            WHERE  status = 'PENDING'
              AND  (validator1_phone = %s OR validator2_phone = %s OR validator3_phone = %s)
              AND  (
                  (validator1_phone = %s AND (validator1_vote IS NULL OR validator1_vote = ''))
               OR (validator2_phone = %s AND (validator2_vote IS NULL OR validator2_vote = ''))
               OR (validator3_phone = %s AND (validator3_vote IS NULL OR validator3_vote = ''))
              )
            ORDER BY created_at ASC
        """, (norm, norm, norm, norm, norm, norm))
        rows = cur.fetchall() or []
        conn.close()
        return rows
    except Exception as e:
        logging.error(f'[validator.menu] get_pending error: {e}')
        return []


def _get_balance(phone):
    norm = phone.lstrip('+')
    try:
        conn = _get_conn()
        cur  = conn.cursor()
        cur.execute("""
            SELECT
                ISNULL(SUM(CASE WHEN status='PAID'    THEN net_amount ELSE 0 END),0) AS total_paid,
                ISNULL(SUM(CASE WHEN status='PENDING' THEN net_amount ELSE 0 END),0) AS total_pending,
                COUNT(*) AS total_votes
            FROM dbo.Rewards_Ledger
            WHERE (phone_number = %s OR phone_number = %s)
              AND transaction_type = 'VALIDATION_REWARD'
        """, (phone, norm))
        row = cur.fetchone()
        conn.close()
        return row
    except Exception as e:
        logging.error(f'[validator.menu] get_balance error: {e}')
        return None


def _get_history(phone):
    norm = phone.lstrip('+')
    try:
        conn = _get_conn()
        cur  = conn.cursor()
        cur.execute("""
            SELECT TOP 10
                vv.vote, vv.submission_id, vv.item, vv.market,
                vv.consensus_result, vv.voted_at, vv.reward_earned
            FROM dbo.Validator_Votes vv
            WHERE vv.validator_phone = %s OR vv.validator_phone = %s
            ORDER BY vv.voted_at DESC
        """, (norm, phone))
        rows = cur.fetchall() or []
        conn.close()
        return rows
    except Exception as e:
        logging.error(f'[validator.menu] get_history error: {e}')
        return []


def _distance_m(lat1, lon1, lat2, lon2):
    """Haversine distance in metres between two GPS coordinates."""
    import math
    R = 6371000
    p1, p2 = math.radians(lat1), math.radians(lat2)
    dp = math.radians(lat2 - lat1)
    dl = math.radians(lon2 - lon1)
    a  = math.sin(dp/2)**2 + math.cos(p1)*math.cos(p2)*math.sin(dl/2)**2
    return R * 2 * math.atan2(math.sqrt(a), math.sqrt(1-a))


def _get_market_coords(market_id):
    """Fetch market lat/lon from Markets table."""
    try:
        conn = _get_conn()
        cur  = conn.cursor()
        cur.execute(
            "SELECT latitude, longitude FROM dbo.Markets WHERE market_id = %s",
            (market_id,)
        )
        row = cur.fetchone()
        conn.close()
        if row and row.get('latitude') and row.get('longitude'):
            return float(row['latitude']), float(row['longitude'])
    except Exception as e:
        logging.error(f'[validator.menu] get_market_coords error: {e}')
    return None, None


def _show_menu(phone):
    from shared.sender import send_message
    send_message(phone,
        "\U0001f3c6 *VALIDATOR MENU*\n"
        "\u2501" * 22 + "\n\n"
        "1\ufe0f\u20e3  *pending* \u2014 View assignments\n"
        "2\ufe0f\u20e3  *vbalance* \u2014 My earnings\n"
        "3\ufe0f\u20e3  *vhistory* \u2014 Vote history\n\n"
        "Type a keyword or number to continue."
    )


def _show_pending(phone, session):
    from shared.sender  import send_message
    from shared.session import save_session
    rows = _get_pending(phone)
    if not rows:
        send_message(phone,
            "\U0001f4cb *No pending assignments.*\n\n"
            "You'll be notified when a new submission needs validation.\n\n"
            "Type *menu* to go back."
        )
        return
    lines = ["\U0001f4cb *PENDING VALIDATIONS*\n" + "\u2501"*22 + "\n"]
    for i, r in enumerate(rows, 1):
        price_str = _fmt(r.get('price'))
        rng_min   = r.get('price_range_min')
        rng_max   = r.get('price_range_max')
        rng_str   = f" (Range: {_fmt(rng_min)}\u2013{_fmt(rng_max)})" if rng_min and rng_max else ""
        lines.append(
            f"{i}. *{r.get('item','?')}*\n"
            f"   \U0001f4cd {r.get('market','?')}\n"
            f"   \U0001f4b5 {price_str}{rng_str}\n"
        )
    lines.append("\nReply with the number to vote (e.g. *1*)\nor type *menu* to go back.")
    session['_flow']    = 'VALIDATOR_MENU'
    session['_vstep']   = 'SELECT'
    session['_pending'] = [
        {'queue_id':      r['queue_id'],
         'submission_id': r['submission_id'],
         'item':          r.get('item', '?'),
         'market':        r.get('market', '?'),
         'price':         str(r.get('price', '0'))}
        for r in rows
    ]
    save_session(phone, session)
    send_message(phone, '\n'.join(lines))


def _show_balance(phone):
    from shared.sender import send_message
    row = _get_balance(phone)
    if not row:
        send_message(phone, "\u274c Could not fetch balance. Try again.\n\nType *menu* to go back.")
        return
    send_message(phone,
        f"\U0001f4b0 *VALIDATOR EARNINGS*\n" + "\u2501"*22 + "\n\n"
        f"\u2705 Paid out:    {_fmt(row.get('total_paid', 0))}\n"
        f"\u23f3 Pending:     {_fmt(row.get('total_pending', 0))}\n"
        f"\U0001f5f3\ufe0f  Total votes:  {row.get('total_votes', 0)}\n\n"
        f"Airtime paid every 30 minutes automatically.\n\n"
        f"Type *menu* to go back."
    )


def _show_history(phone):
    from shared.sender import send_message
    rows = _get_history(phone)
    if not rows:
        send_message(phone,
            "\U0001f4cb *No vote history yet.*\n\n"
            "Type *pending* to see assignments.\nType *menu* to go back."
        )
        return
    lines = ["\U0001f4cb *VOTE HISTORY*\n" + "\u2501"*22 + "\n"]
    for r in rows:
        icon      = '\u2705' if r.get('vote') == 'APPROVE' else '\u274c'
        consensus = r.get('consensus_result') or 'PENDING'
        c_icon    = '\u2705' if consensus == 'APPROVED' else ('\u274c' if consensus == 'REJECTED' else '\u23f3')
        date      = str(r.get('voted_at') or '')[:10]
        reward    = r.get('reward_earned')
        rew_str   = f" | \U0001f4b0{_fmt(reward)}" if reward else ""
        lines.append(
            f"{icon} *{r.get('item','?')}* @ {r.get('market','?')}\n"
            f"   Your vote: {r.get('vote','?')} | Outcome: {c_icon} {consensus}{rew_str}\n"
            f"   \U0001f4c5 {date}\n"
        )
    lines.append("\nType *menu* to go back.")
    send_message(phone, '\n'.join(lines))


def handle_validator(phone, message="", session=None, *args):
    from shared.sender  import send_message
    from shared.session import save_session, clear_session
    if session is None:
        session = {}
    msg   = (message or '').strip().lower()
    vstep = session.get('_vstep', '')

    # ── Guard: must be registered and approved ────────────────────────────
    validator = _get_validator(phone)
    if not validator:
        send_message(phone,
            "\U0001f3c6 *Validator Portal*\n\n"
            "You are not registered as a NaijaMarket validator.\n\n"
            "Contact support to receive a validator invite code."
        )
        return
    if (validator.get('registration_status') or '').upper() != 'APPROVED':
        send_message(phone,
            "\u23f3 *Your validator registration is pending approval.*\n\n"
            "You'll be notified once approved.\nType *menu* to go back."
        )
        return

    validator_id = validator.get('validator_id', '')

    # ── Fresh keywords reset to menu ──────────────────────────────────────
    if msg in ('menu', '0', 'back', 'hi', 'hello', 'start'):
        clear_session(phone)
        session = {'_flow': 'VALIDATOR_MENU'}
        save_session(phone, session)
        _show_menu(phone)
        return

    if msg in ('pending', 'assignments', '1'):
        session['_flow'] = 'VALIDATOR_MENU'
        _show_pending(phone, session)
        return

    if msg in ('vbalance', 'balance', 'earnings', '2'):
        session['_flow'] = 'VALIDATOR_MENU'
        save_session(phone, session)
        _show_balance(phone)
        return

    if msg in ('vhistory', 'history', '3'):
        session['_flow'] = 'VALIDATOR_MENU'
        save_session(phone, session)
        _show_history(phone)
        return

    # ── Number selection from pending list ────────────────────────────────
    if vstep == 'SELECT' and msg.isdigit():
        pending = session.get('_pending', [])
        idx = int(msg) - 1
        if 0 <= idx < len(pending):
            item = pending[idx]
            session['_vstep']         = 'VOTE'
            session['_vote_queue_id'] = item['queue_id']
            session['_vote_sub_id']   = item['submission_id']
            session['_vote_item']     = item['item']
            session['_vote_market']   = item['market']
            session['_vote_price']    = item['price']
            save_session(phone, session)
            send_message(phone,
                f"\U0001f5f3\ufe0f *CAST YOUR VOTE*\n" + "\u2501"*22 + "\n\n"
                f"\U0001f4e6 Item:   *{item['item']}*\n"
                f"\U0001f4cd Market: *{item['market']}*\n"
                f"\U0001f4b5 Price:  *{_fmt(item['price'])}*\n\n"
                f"\U0001f4cd *Share your live location first*\n"
                f"You must be within 500m of {item['market']} to vote.\n\n"
                f"Tap the attachment icon \u2192 Location \u2192 Share Live Location\n\n"
                f"After sharing location, reply *approve* or *reject*\n"
                f"(or type *0* to go back)"
            )
        else:
            send_message(phone, f"\u274c Invalid selection. Enter 1\u2013{len(pending)}.")
        return

    # ── Vote casting ──────────────────────────────────────────────────────
    if vstep == 'VOTE':
        if msg == '0':
            session['_vstep'] = 'SELECT'
            save_session(phone, session)
            _show_pending(phone, session)
            return

        vlat = session.get('_vlat')
        vlon = session.get('_vlon')

        if msg not in ('approve', 'reject', 'a', 'r', '1', '2'):
            if vlat is None:
                send_message(phone,
                    "\U0001f4cd *Location required before voting.*\n\n"
                    "Please share your *live location* in WhatsApp:\n"
                    "Tap the attachment icon \u2192 Location \u2192 Share Live Location\n\n"
                    "You must be within 500m of the market to vote.\n\n"
                    "Type *0* to go back."
                )
            else:
                send_message(phone,
                    "Reply *approve* (or *a*) to approve\n"
                    "Reply *reject* (or *r*) to reject\n"
                    "Type *0* to go back."
                )
            return

        if vlat is None:
            send_message(phone,
                "\U0001f4cd *Share your live location first.*\n\n"
                "Tap the attachment icon \u2192 Location \u2192 Share Live Location\n\n"
                "You must be within 500m of the market to vote."
            )
            return

        vote      = 'APPROVE' if msg in ('approve', 'a', '1') else 'REJECT'
        sub_id    = session.get('_vote_sub_id', '')
        item_name = session.get('_vote_item', '')
        market    = session.get('_vote_market', '')

        from validator.vote import cast_vote
        result_msg = cast_vote(phone, validator_id, sub_id, vote, item_name, market)

        session['_vstep'] = 'SELECT'
        for k in ('_vote_queue_id','_vote_sub_id','_vote_item',
                  '_vote_market','_vote_price','_vlat','_vlon'):
            session.pop(k, None)
        save_session(phone, session)
        send_message(phone, result_msg)
        return

    # ── Default ───────────────────────────────────────────────────────────
    session['_flow'] = 'VALIDATOR_MENU'
    save_session(phone, session)
    _show_menu(phone)
