"""
shared/trader_i18n.py — EN + Naija Pidgin strings for all TRADER WhatsApp flows.

Pattern mirrors shared/i18n.py exactly: a {key: {"en":..., "pcm":...}} table
and a tt(lang, key, **kwargs) helper that .format()s the chosen string.

EN strings are byte-identical to the previously-hardcoded text in
trader/menu.py, trader/submit.py and trader/kyc.py so the English path is an
exact refactor. PCM follows the shipped consumer voice in shared/i18n.py, and
matches naijamarket-mobile lib/i18n.ts phrasing where a concept overlaps
(e.g. the "earn ₦50 when dem approve am" line).

Numeric format specs ({avail:,.0f} etc.) are kept in the templates — str.format
applies them against the numeric kwargs, same as shared/i18n.py.
"""
from shared.trader_lang import VALID_LANGS, DEFAULT_LANG

# 22-char rule used across trader messages (was '━' * 22 in f-strings)
_BAR = "━" * 22


def tt(lang, key, **kwargs):
    lang  = lang if lang in VALID_LANGS else DEFAULT_LANG
    entry = TS.get(key, {})
    text  = entry.get(lang) or entry.get(DEFAULT_LANG, f"[{key}]")
    try:
        return text.format(**kwargs) if kwargs else text
    except Exception:
        return text


TS = {

    # ── Language toggle (trader) ──────────────────────────────────────────
    # Reuse the same wording family as consumer shared/i18n.py lang_* keys.
    "lang_prompt": {
        "en":  "🌐 *LANGUAGE*\n\n*1* English\n*2* Naija Pidgin\n\nReply 1 or 2\n\n_Reply with a number_",
        "pcm": "🌐 *TONGUE*\n\n*1* English\n*2* Naija Pidgin\n\nSend 1 or 2\n\n_Type the number_",
    },
    "lang_set_en":  {"en": "✅ Language set to *English*",          "pcm": "✅ Language set to *English*"},
    "lang_set_pcm": {"en": "✅ Language changed to *Naija Pidgin*!", "pcm": "✅ E don change to *Naija Pidgin*! 🇳🇬"},
    "lang_invalid": {
        "en":  "❌ Please reply *1* for English or *2* for Naija Pidgin.",
        "pcm": "❌ Send *1* for English or *2* for Naija Pidgin.",
    },

    # ── Guards (menu.py + submit.py) ──────────────────────────────────────
    "suspended": {
        "en":  "🚫 *Account Suspended*\n\nReason: {reason}\n\nContact: support@naijamarketintel.ng",
        "pcm": "🚫 *Dem Don Suspend Your Account*\n\nReason: {reason}\n\nContact: support@naijamarketintel.ng",
    },
    "reg_pending": {
        "en":  "⏳ *Registration {status}*\n\nYour trader application is under review.\nYou will receive a WhatsApp notification once approved.\n\nType *menu* to check again.",
        "pcm": "⏳ *Registration {status}*\n\nWe still dey check your trader application.\nWe go send you WhatsApp message once dem approve am.\n\nType *menu* to check again.",
    },
    "submit_not_registered": {
        "en":  "❌ *Not registered as a trader.*\n\nType *register* to become a NaijaMarket trader and earn ₦50 per submission.",
        "pcm": "❌ *You never register as trader.*\n\nType *register* to become NaijaMarket trader and earn ₦50 for each submission.",
    },
    "submit_pending": {
        "en":  "⏳ *Your trader registration is pending approval.*\n\nYou'll receive a WhatsApp message once approved.\nType *menu* to go back.",
        "pcm": "⏳ *Dem never approve your trader registration.*\n\nWe go send you WhatsApp message once dem approve am.\nType *menu* to go back.",
    },
    "submit_suspended": {
        "en":  "🚫 *Your account has been suspended.*\n\nContact support for assistance.\nType *menu* to go back.",
        "pcm": "🚫 *Dem don suspend your account.*\n\nContact support make dem help you.\nType *menu* to go back.",
    },

    # ── Magic-link login (menu.py) ────────────────────────────────────────
    "login_gen_fail": {
        "en":  "Sorry, we couldn't generate a login link right now. Please try again.",
        "pcm": "Sorry, we no fit create login link now. Abeg try again.",
    },
    "login_sent": {
        "en":  "A login link has been sent to this WhatsApp. Tap it to sign in to your Reporter dashboard. It expires in 10 minutes.",
        "pcm": "We don send login link to this WhatsApp. Tap am to sign in to your Reporter dashboard. E go expire in 10 minutes.",
    },
    "login_send_fail": {
        "en":  "Sorry, we couldn't send the login link. Please try again shortly.",
        "pcm": "Sorry, we no fit send the login link. Abeg try again small time.",
    },

    # ── Main menu (menu.py _msg_menu) ─────────────────────────────────────
    "menu": {
        "en":  ("📦 *NaijaMarket Trader Menu*\n" + _BAR + "\n"
                "👤 {first} — {market}\n"
                "💰 Balance: ₦{avail:,.0f}\n" + _BAR + "\n\n"
                "1️⃣  Submit Price\n"
                "2️⃣  My Earnings\n"
                "3️⃣  My Submissions\n\n"
                "Reply with a number."),
        "pcm": ("📦 *NaijaMarket Trader Menu*\n" + _BAR + "\n"
                "👤 {first} — {market}\n"
                "💰 Balance: ₦{avail:,.0f}\n" + _BAR + "\n\n"
                "1️⃣  Submit Price\n"
                "2️⃣  My Money\n"
                "3️⃣  My Submissions\n\n"
                "Type the number."),
    },

    # ── Earnings (menu.py _msg_earnings) ──────────────────────────────────
    "earn_eligible": {
        "en":  "✅ Eligible for early transfer!",
        "pcm": "✅ You fit do early transfer!",
    },
    "earn_need_more": {
        "en":  "⏳ Need ₦{needed:,.0f} more for early transfer",
        "pcm": "⏳ You need ₦{needed:,.0f} more before you fit do early transfer",
    },
    "earnings": {
        "en":  ("💰 *Your Earnings*\n" + _BAR + "\n\n"
                "Available balance: ₦{avail:,.0f}\n"
                "{transfer_line}\n"
                "Total earned: ₦{total_earned:,.0f}\n"
                "Reputation: {rep}/100 ({tier})\n\n"
                "To transfer your balance, visit:\n"
                "https://trader.naijamarketintel.com/earnings\n\n"
                + _BAR + "\n"
                "Type *menu* to go back."),
        "pcm": ("💰 *Your Money*\n" + _BAR + "\n\n"
                "Money wey you fit collect: ₦{avail:,.0f}\n"
                "{transfer_line}\n"
                "Total wey you don earn: ₦{total_earned:,.0f}\n"
                "Reputation: {rep}/100 ({tier})\n\n"
                "To transfer your money, visit:\n"
                "https://trader.naijamarketintel.com/earnings\n\n"
                + _BAR + "\n"
                "Type *menu* to go back."),
    },

    # ── Submissions (menu.py _msg_submissions) ────────────────────────────
    "subs_none_recent": {
        "en":  "No submissions yet.",
        "pcm": "You never submit anything yet.",
    },
    "submissions": {
        "en":  ("📋 *Your Submissions*\n" + _BAR + "\n\n"
                "Today:\n"
                "  Total: {t_total} | ✅ {t_approved} | ⏳ {t_pending} | ❌ {t_rejected}\n"
                "  Earned today: ₦{earned_today:,.0f}\n\n"
                "All time:\n"
                "  Total: {a_total} | Approved: {a_approved}\n\n"
                "📦 Last submissions:\n"
                "{recent_block}\n\n"
                + _BAR + "\n"
                "Type *menu* to go back."),
        "pcm": ("📋 *Your Submissions*\n" + _BAR + "\n\n"
                "Today:\n"
                "  Total: {t_total} | ✅ {t_approved} | ⏳ {t_pending} | ❌ {t_rejected}\n"
                "  Money you earn today: ₦{earned_today:,.0f}\n\n"
                "All time:\n"
                "  Total: {a_total} | Approved: {a_approved}\n\n"
                "📦 Your last submissions:\n"
                "{recent_block}\n\n"
                + _BAR + "\n"
                "Type *menu* to go back."),
    },

    # ── Submit flow (submit.py) ───────────────────────────────────────────
    "no_categories": {
        "en":  "❌ No categories available. Type *menu* to go back.",
        "pcm": "❌ No category dey now. Type *menu* to go back.",
    },
    "cat_header": {
        "en":  "📦 *Submit Price — {market}*\n\nSelect a category:\n",
        "pcm": "📦 *Submit Price — {market}*\n\nChoose category:\n",
    },
    "back_to_menu_line": {
        "en":  "\n0 — Back to menu",
        "pcm": "\n0 — Back to menu",
    },
    "reply_number_line": {
        "en":  "_Reply with a number_",
        "pcm": "_Type the number_",
    },
    "pick_between": {
        "en":  "❌ Please enter a number between 1 and {n}.",
        "pcm": "❌ Type number between 1 and {n}.",
    },
    "no_items_in_cat": {
        "en":  "No items found in {cat}. Try another category.",
        "pcm": "No item dey for {cat}. Try another category.",
    },
    "item_header": {
        "en":  "🛒 *{cat}*\n\nSelect an item:\n",
        "pcm": "🛒 *{cat}*\n\nChoose item:\n",
    },
    "item_back_line": {
        "en":  "\n0 — Back\n_Reply with a number_",
        "pcm": "\n0 — Back\n_Type the number_",
    },
    "already_approved_item": {
        "en":  "✅ *{item}*\n\nWe already have your approved price for this item this period.\n\nPlease submit price for another product.\nType *0* to go back.",
        "pcm": "✅ *{item}*\n\nWe don already get your approved price for this item this period.\n\nAbeg submit price for another product.\nType *0* to go back.",
    },
    "already_have_price": {
        "en":  "✓ *We already have the price for {item}. Please submit price for another product.*{avg_str}\n\nType *0* to go back.",
        "pcm": "✓ *We don already get the price for {item}. Abeg submit price for another product.*{avg_str}\n\nType *0* to go back.",
    },
    "current_market_price": {
        "en":  "\n\n📊 *Current market price:* {avg}",
        "pcm": "\n\n📊 *Current market price:* {avg}",
    },
    "market_range": {
        "en":  "\n\n📊 *Market range:* {low} – {high}",
        "pcm": "\n\n📊 *Market range:* {low} – {high}",
    },
    "price_prompt": {
        "en":  "💵 *{item}* {unit_str}{guidance}\n\nEnter the price in Naira (numbers only):\nExample: *55000*\n\n0 — Back",
        "pcm": "💵 *{item}* {unit_str}{guidance}\n\nType the price for Naira (number only):\nExample: *55000*\n\n0 — Back",
    },
    "invalid_price": {
        "en":  "❌ Invalid price. Enter numbers only (e.g. *55000*).\nMinimum ₦10, maximum ₦100,000,000.\n\n0 — Back",
        "pcm": "❌ Price no correct. Type number only (e.g. *55000*).\nMinimum ₦10, maximum ₦100,000,000.\n\n0 — Back",
    },
    "confirm_submission": {
        "en":  "✅ *Confirm Submission*\n\n📍 Market: {market}\n📦 Item: {item} {unit_str}\n💵 Price: {price}\n\nReply *yes* to submit or *0* to cancel.",
        "pcm": "✅ *Confirm Submission*\n\n📍 Market: {market}\n📦 Item: {item} {unit_str}\n💵 Price: {price}\n\nReply *yes* to submit or *0* to cancel.",
    },
    "reply_yes_or_cancel": {
        "en":  "Reply *yes* to confirm or *0* to cancel.",
        "pcm": "Reply *yes* to confirm or *0* to cancel.",
    },
    "daily_limit": {
        "en":  "⚠️ *Daily Limit Reached*\n\nYou've submitted {count}/{limit} items today.\nYour limit resets at midnight WAT. Try again tomorrow! 🌅",
        "pcm": "⚠️ *You Don Reach Today Limit*\n\nYou don submit {count}/{limit} items today.\nYour limit go reset for midnight WAT. Try again tomorrow! 🌅",
    },
    "dup_at_submit": {
        "en":  "✓ We already have the price for {item}. Please submit price for another product.\n\nType *0* to go back or *menu* to return to main menu.",
        "pcm": "✓ We don already get the price for {item}. Abeg submit price for another product.\n\nType *0* to go back or *menu* to return to main menu.",
    },
    "submit_success": {
        "en":  ("✅ *Price Submitted!*\n\n"
                "📦 {item}\n"
                "💵 {price}\n"
                "📍 {market}\n\n"
                "💰 You'll earn ₦{reward} when approved.\n"
                "{fav_note}\n\n"
                "Submit another price? Select a category:\n"
                "_(or type *menu* to go back)_"),
        "pcm": ("✅ *Price Don Submit!*\n\n"
                "📦 {item}\n"
                "💵 {price}\n"
                "📍 {market}\n\n"
                "💰 You go earn ₦{reward} when dem approve am.\n"
                "{fav_note}\n\n"
                "You wan submit another price? Choose category:\n"
                "_(or type *menu* to go back)_"),
    },
    "fav_note": {
        "en":  "\n⭐ Added to your favourites!",
        "pcm": "\n⭐ E don enter your favourites!",
    },
    "submit_failed": {
        "en":  "❌ Submission failed. Please try again.\n\nType *submit* to try again or *menu* to go back.",
        "pcm": "❌ Submission fail. Abeg try again.\n\nType *submit* to try again or *menu* to go back.",
    },

    # ── KYC redirect (kyc.py) ─────────────────────────────────────────────
    "kyc_redirect": {
        "en":  ("📋 *Price Reporter Registration*\n\n"
                "NaijaMarket Intel is now live. Register now and start earning ₦50 per approved submission.\n\n"
                "To complete your registration, please visit:\n"
                "👉 *https://trader.naijamarketintel.com*\n\n"
                "You'll need:\n"
                "• Your full name and date of birth\n"
                "• BVN (Bank Verification Number)\n"
                "• Bank account details for payouts\n\n"
                "Already registered? Type *submit* to start submitting prices.\n"
                "Type *menu* to go back."),
        "pcm": ("📋 *Price Reporter Registration*\n\n"
                "NaijaMarket Intel don dey live now. Register now and start to dey earn ₦50 for each approved submission.\n\n"
                "To complete your registration, abeg visit:\n"
                "👉 *https://trader.naijamarketintel.com*\n\n"
                "Wetin you go need:\n"
                "• Your full name and date of birth\n"
                "• BVN (Bank Verification Number)\n"
                "• Bank account details for payout\n\n"
                "You don register before? Type *submit* to start submit prices.\n"
                "Type *menu* to go back."),
    },
    "kyc_suspended": {
        "en":  "🚫 *Account Suspended*\n\nYour Price Reporter account has been suspended.\n\nContact: support@naijamarketintel.ng",
        "pcm": "🚫 *Dem Don Suspend Your Account*\n\nDem don suspend your Price Reporter account.\n\nContact: support@naijamarketintel.ng",
    },

    # ── Router inline (whatsapp_main) — trader prompt for non-approved ─────
    "become_trader": {
        "en":  "📋 *Become a NaijaMarket Trader*\n\nEarn ₦50 per approved price submission.\n\nType *register* to apply or *menu* to go back.",
        "pcm": "📋 *Become NaijaMarket Trader*\n\nEarn ₦50 for each approved price submission.\n\nType *register* to apply or *menu* to go back.",
    },
}
