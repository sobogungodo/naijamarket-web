"""
shared/drilldown.py — Reusable Region→State→Market→Category→Item drill-down
Used by prices, snapshot, compare, filter, bulk, forecast, calc flows.
"""
import logging
from shared.db import get_connection

# 6 geopolitical zones → states
REGIONS = {
    "North Central": ["Benue","FCT","Kogi","Kwara","Nasarawa","Nassarawa","Niger","Plateau"],
    "North East":    ["Adamawa","Bauchi","Borno","Gombe","Taraba","Yobe"],
    "North West":    ["Jigawa","Kaduna","Kano","Katsina","Kebbi","Sokoto","Zamfara"],
    "South East":    ["Abia","Anambra","Ebonyi","Enugu","Imo"],
    "South South":   ["Akwa Ibom","Bayelsa","Cross River","Delta","Edo","Rivers"],
    "South West":    ["Ekiti","Lagos","Ogun","Ondo","Osun","Oyo"],
}
REGION_LIST = list(REGIONS.keys())

# State → region lookup
STATE_TO_REGION = {s: r for r, states in REGIONS.items() for s in states}


def pick_region(lang: str) -> tuple:
    """Returns (msg, region_list)."""
    lines = "\n".join(f"*{i+1}*. {r}" for i, r in enumerate(REGION_LIST))
    title = "🗺️ *SELECT REGION*" if lang == "en" else "🗺️ *PICK REGION*"
    footer = "\n\n*0* — Menu"
    return f"{title}\n────────────────\n\n{lines}{footer}", REGION_LIST


def get_states_for_region(region: str) -> list:
    """Return states in a region that have price data."""
    return REGIONS.get(region, [])


def pick_state_for_region(lang: str, region: str) -> tuple:
    """Returns (msg, state_list) filtered to states with actual DB data."""
    try:
        all_states = REGIONS.get(region, [])
        conn = get_connection(); cur = conn.cursor()
        cur.execute("""
            SELECT DISTINCT state FROM dbo.Latest_Prices_Summary
            WHERE is_nbs_ref=0 AND is_food=1 AND state IS NOT NULL
        """)
        db_states_raw = {r["state"] for r in cur.fetchall()}
        conn.close()
        # Case-insensitive match to handle spelling variants
        db_states_lower = {s.lower(): s for s in db_states_raw}
        states = [s for s in all_states if s.lower() in db_states_lower]
        if not states:
            states = all_states  # fallback: show all even if no data
    except Exception as e:
        logging.error(f"[drilldown.pick_state_for_region] {e}")
        states = REGIONS.get(region, [])

    lines = "\n".join(f"*{i+1}*. {s}" for i, s in enumerate(states))
    title = f"📍 *{region.upper()}*" if lang == "en" else f"📍 *{region.upper()}*"
    footer = "\n\n*back* — Regions | *0* — Menu"
    return f"{title}\n────────────────\n\n{lines}{footer}", states
