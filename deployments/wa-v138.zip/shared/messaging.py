"""
shared/messaging.py — 24-hour window detection and template/freetext send branching [1f]

Meta WhatsApp rules:
  - Free-text: only within 24h of the user's last inbound message
  - Outside 24h: must use a pre-approved template (otherwise delivery silently fails)

Usage (proactive sends — alerts, renewals, etc.):
    from shared.messaging import send_to_user
    send_to_user(phone, freetext_msg, template_name="price_alert",
                 template_params=[{"type":"text","text":"Rice"}])

For reactive sends (always in-window), just use shared.sender.send_message directly.
Template names require Meta approval (Group 2). Until approved, outside-window
proactive sends will be logged as skipped rather than causing an error.
"""
import os
import logging
import requests
from datetime import datetime, timezone

from shared.db import get_connection
from shared.sender import send_message

# Approved Meta template names — update as templates get approved in Group 2
APPROVED_TEMPLATES = {
    "price_alert":          "price_alert",
    "payment_confirmation": "payment_confirmation",
    "renewal_reminder":     "renewal_reminder",
    "login_otp":            "login_otp",
    # Development fallback (always approved on test numbers):
    "hello_world":          "hello_world",
}


def get_last_inbound_hours(phone: str) -> float:
    """
    Returns how many hours ago this user last messaged us.
    Uses Consumer_Query_Sessions.last_updated as proxy for last inbound.
    Returns 999.0 if no record found (treat as outside window).
    """
    try:
        conn = get_connection()
        cur  = conn.cursor()
        clean = phone.replace("+", "").strip()
        cur.execute(
            """
            SELECT TOP 1 last_updated
            FROM dbo.Consumer_Query_Sessions
            WHERE phone_number = %s
            ORDER BY last_updated DESC
            """,
            (clean,)
        )
        row = conn.cursor() and cur.fetchone()
        conn.close()
        if not row or not row.get("last_updated"):
            return 999.0
        lu = row["last_updated"]
        if hasattr(lu, "replace"):
            lu = lu.replace(tzinfo=timezone.utc) if lu.tzinfo is None else lu
        now = datetime.now(timezone.utc)
        return (now - lu).total_seconds() / 3600.0
    except Exception as e:
        logging.warning(f"[messaging] get_last_inbound_hours: {e}")
        return 999.0  # Fail safe: treat as outside window


def is_in_24h_window(phone: str) -> bool:
    """True if user sent us a message within the last 24 hours."""
    return get_last_inbound_hours(phone) <= 24.0


def send_template(phone: str, template_name: str, components: list = None,
                  language_code: str = "en") -> bool:
    """
    Send a Meta-approved template message.
    components: list of template component dicts per Meta API spec.
    Returns True on success.
    """
    token    = os.environ.get("META_ACCESS_TOKEN", "")
    phone_id = os.environ.get("META_PHONE_NUMBER_ID", "")
    if not token or not phone_id:
        logging.warning("[messaging] send_template: META vars not set")
        return False

    resolved = APPROVED_TEMPLATES.get(template_name, template_name)
    clean = phone.replace("+", "").strip()

    payload = {
        "messaging_product": "whatsapp",
        "to": clean,
        "type": "template",
        "template": {
            "name": resolved,
            "language": {"code": language_code},
        }
    }
    if components:
        payload["template"]["components"] = components

    try:
        r = requests.post(
            f"https://graph.facebook.com/v19.0/{phone_id}/messages",
            headers={
                "Authorization": f"Bearer {token}",
                "Content-Type": "application/json",
            },
            json=payload,
            timeout=10,
        )
        if r.ok:
            logging.info(f"[messaging] template '{resolved}' sent to {clean}")
            return True
        logging.warning(
            f"[messaging] template send {r.status_code} for {clean}: {r.text[:200]}"
        )
        return False
    except Exception as e:
        logging.error(f"[messaging] send_template exception: {e}")
        return False


def send_to_user(phone: str, freetext: str,
                 template_name: str = None,
                 template_params: list = None,
                 language_code: str = "en") -> bool:
    """
    Primary proactive send function. Branches on 24h window:
      - In window  → send freetext via send_message
      - Outside    → send approved template (if template_name provided)
                     else log as skipped

    Args:
        phone:           Recipient phone (with or without +)
        freetext:        Message to send if in 24h window
        template_name:   Approved template name (e.g. 'price_alert')
        template_params: List of component param dicts for template body
        language_code:   Template language code (default 'en')
    Returns:
        True if message was sent (freetext or template), False if skipped/failed
    """
    if is_in_24h_window(phone):
        send_message(phone, freetext)
        return True

    # Outside 24h window — use template
    if not template_name:
        logging.info(
            f"[messaging] outside 24h window for {phone}, "
            "no template_name provided — skipped"
        )
        return False

    if template_name not in APPROVED_TEMPLATES:
        logging.warning(
            f"[messaging] template '{template_name}' not in APPROVED_TEMPLATES — "
            "skipped (pending Meta approval)"
        )
        return False

    components = []
    if template_params:
        components = [{"type": "body", "parameters": template_params}]

    return send_template(phone, template_name, components, language_code)
