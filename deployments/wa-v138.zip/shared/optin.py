"""
shared/optin.py — WhatsApp messaging opt-in capture and log [1g]

Called at two points:
  1. Welcome flow completion (new user explicitly starts using the bot)
  2. First successful login via WhatsApp OTP

Pre-deploy DDL (run once in Azure Portal Query Editor if table doesn't exist):

    IF NOT EXISTS (
        SELECT 1 FROM INFORMATION_SCHEMA.TABLES
        WHERE TABLE_NAME = 'WhatsApp_Optins'
    )
    BEGIN
        CREATE TABLE dbo.WhatsApp_Optins (
            phone_number   NVARCHAR(20)  NOT NULL,
            opted_in       BIT           NOT NULL DEFAULT 1,
            opt_in_at      DATETIME2     NOT NULL DEFAULT GETUTCDATE(),
            opt_in_channel NVARCHAR(30)  NOT NULL DEFAULT 'WHATSAPP',
            opted_out_at   DATETIME2     NULL,
            last_updated   DATETIME2     NOT NULL DEFAULT GETUTCDATE(),
            CONSTRAINT PK_WhatsApp_Optins PRIMARY KEY (phone_number)
        );
        CREATE INDEX IX_WhatsApp_Optins_optin ON dbo.WhatsApp_Optins (opted_in, opt_in_at);
    END

Opt-in consent is implicit when a user initiates conversation with the bot
(WhatsApp Business Policy section 2.3 — user-initiated = consent). This log
satisfies NDPA / Meta Business policy documentation requirements.
"""
import logging
from shared.db import get_connection


def record_optin(phone: str, channel: str = "WHATSAPP") -> bool:
    """
    Upsert an opt-in record for this phone number.
    Safe to call multiple times — only inserts on first call; subsequent
    calls update last_updated and set opted_in=1 if they had opted out.

    Args:
        phone:   Phone number (with or without +)
        channel: Source of opt-in ('WHATSAPP', 'WELCOME_FLOW', 'OTP_LOGIN')
    Returns:
        True on success, False on error (non-fatal — log and continue)
    """
    clean = phone.replace("+", "").strip()
    try:
        conn = get_connection()
        cur  = conn.cursor()
        cur.execute(
            """
            MERGE dbo.WhatsApp_Optins AS t
            USING (SELECT %s AS phone_number) AS s ON t.phone_number = s.phone_number
            WHEN MATCHED THEN
                UPDATE SET opted_in=1, last_updated=GETUTCDATE()
            WHEN NOT MATCHED THEN
                INSERT (phone_number, opted_in, opt_in_at, opt_in_channel, last_updated)
                VALUES (%s, 1, GETUTCDATE(), %s, GETUTCDATE());
            """,
            (clean, clean, channel)
        )
        conn.commit()
        conn.close()
        logging.info(f"[optin] recorded for {clean} via {channel}")
        return True
    except Exception as e:
        logging.error(f"[optin] record_optin failed for {clean}: {e}")
        return False


def record_optout(phone: str) -> bool:
    """
    Mark this phone as opted out. Bot will not send proactive messages.
    Called when user sends 'STOP', 'optout', or 'unsubscribe'.
    """
    clean = phone.replace("+", "").strip()
    try:
        conn = get_connection()
        cur  = conn.cursor()
        cur.execute(
            """
            UPDATE dbo.WhatsApp_Optins
            SET opted_in=0, opted_out_at=GETUTCDATE(), last_updated=GETUTCDATE()
            WHERE phone_number=%s
            """,
            (clean,)
        )
        conn.commit()
        conn.close()
        logging.info(f"[optin] opt-out recorded for {clean}")
        return True
    except Exception as e:
        logging.error(f"[optin] record_optout failed for {clean}: {e}")
        return False


def is_opted_in(phone: str) -> bool:
    """
    Check whether this phone has a valid opt-in record.
    Returns True if opted_in=1 OR if no record exists (first contact = implicitly opted in).
    Returns False only if phone has explicitly opted out (opted_in=0).
    """
    clean = phone.replace("+", "").strip()
    try:
        conn = get_connection()
        cur  = conn.cursor()
        cur.execute(
            "SELECT opted_in FROM dbo.WhatsApp_Optins WHERE phone_number=%s",
            (clean,)
        )
        row = cur.fetchone()
        conn.close()
        if not row:
            return True  # No record = first contact = treat as opted in
        return bool(row.get("opted_in", 1))
    except Exception as e:
        logging.error(f"[optin] is_opted_in check failed for {clean}: {e}")
        return True  # Fail open — don't block on DB error
