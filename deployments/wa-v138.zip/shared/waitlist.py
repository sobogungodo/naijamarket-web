"""
shared/waitlist.py — WA_Waitlist table operations
New file — does not modify any existing module.
"""
import os, random, string, logging
from shared.db import get_connection

def _generate_code() -> str:
    """Generate unique NMI-XXXXX referral code."""
    chars = string.ascii_uppercase + string.digits
    suffix = ''.join(random.choices(chars, k=5))
    return f"NMI-{suffix}"

def _unique_code() -> str:
    """Generate a referral code guaranteed unique in WA_Waitlist."""
    conn = get_connection()
    try:
        cur = conn.cursor()
        for _ in range(10):
            code = _generate_code()
            cur.execute(
                "SELECT COUNT(*) FROM dbo.WA_Waitlist WHERE my_referral_code = %s",
                (code,))
            if cur.fetchone()[0] == 0:
                return code
        return _generate_code()  # fallback — collision astronomically unlikely
    finally:
        conn.close()

def is_on_waitlist(phone: str) -> bool:
    clean = phone.replace('+', '').strip()
    phone_plus = f"+{clean}"
    conn = get_connection()
    try:
        cur = conn.cursor()
        cur.execute(
            "SELECT COUNT(*) FROM dbo.WA_Waitlist WHERE phone_number=%s OR phone_number=%s",
            (clean, phone_plus))
        return cur.fetchone()[0] > 0
    except Exception as e:
        logging.error(f"[waitlist] is_on_waitlist error: {e}")
        return False
    finally:
        conn.close()

def get_position(phone: str) -> int:
    """Returns 1-based queue position. Returns -1 on error."""
    clean = phone.replace('+', '').strip()
    phone_plus = f"+{clean}"
    conn = get_connection()
    try:
        cur = conn.cursor()
        cur.execute("""
            SELECT COUNT(*) FROM dbo.WA_Waitlist
            WHERE joined_at <= (
                SELECT joined_at FROM dbo.WA_Waitlist
                WHERE phone_number=%s OR phone_number=%s
            )
        """, (clean, phone_plus))
        row = cur.fetchone()
        return int(row[0]) if row else -1
    except Exception as e:
        logging.error(f"[waitlist] get_position error: {e}")
        return -1
    finally:
        conn.close()

def get_my_code(phone: str) -> str:
    """Returns the user's referral code or empty string."""
    clean = phone.replace('+', '').strip()
    phone_plus = f"+{clean}"
    conn = get_connection()
    try:
        cur = conn.cursor()
        cur.execute(
            "SELECT my_referral_code, referral_count, bonus_searches "
            "FROM dbo.WA_Waitlist WHERE phone_number=%s OR phone_number=%s",
            (clean, phone_plus))
        row = cur.fetchone()
        if row:
            return {
                'code': row[0],
                'referral_count': row[1],
                'bonus_searches': row[2]
            }
        return {}
    except Exception as e:
        logging.error(f"[waitlist] get_my_code error: {e}")
        return {}
    finally:
        conn.close()

def join_waitlist(phone: str, email: str = None,
                  source: str = 'whatsapp_bot',
                  referral_code_used: str = None) -> dict:
    """
    Add phone to WA_Waitlist. Idempotent — safe to call multiple times.
    Returns dict with position and my_referral_code.
    """
    clean = phone.replace('+', '').strip()
    phone_plus = f"+{clean}"
    conn = get_connection()
    try:
        cur = conn.cursor()
        # Check if already on waitlist
        cur.execute(
            "SELECT id, my_referral_code, source FROM dbo.WA_Waitlist "
            "WHERE phone_number=%s OR phone_number=%s",
            (clean, phone_plus))
        existing = cur.fetchone()
        if existing:
            existing_source = existing[2]
            # Block cross-role registration
            if existing_source != source:
                return {
                    'position': -1,
                    'code': '',
                    'already_joined': True,
                    'role_conflict': True,
                    'existing_role': existing_source
                }
            position = get_position(phone)
            return {'position': position, 'code': existing[1], 'already_joined': True, 'role_conflict': False}

        # Validate referral code if provided
        referrer_phone = None
        if referral_code_used:
            cur.execute(
                "SELECT phone_number FROM dbo.WA_Waitlist "
                "WHERE my_referral_code=%s",
                (referral_code_used.upper().strip(),))
            ref_row = cur.fetchone()
            if ref_row:
                referrer_phone = ref_row[0]

        # Generate unique code for this user
        my_code = _unique_code()

        # Insert
        cur.execute("""
            INSERT INTO dbo.WA_Waitlist
                (phone_number, email, source, my_referral_code,
                 referral_code_used, joined_at)
            VALUES (%s, %s, %s, %s, %s, GETUTCDATE())
        """, (phone_plus, email, source, my_code,
              referral_code_used.upper().strip() if referral_code_used else None))

        # Credit referrer: +1 referral_count, +1 bonus_searches
        if referrer_phone:
            cur.execute("""
                UPDATE dbo.WA_Waitlist
                SET referral_count  = referral_count + 1,
                    bonus_searches  = bonus_searches + 1
                WHERE phone_number = %s
            """, (referrer_phone,))
            logging.info(f"[waitlist] referral credited to {referrer_phone}")

        conn.commit()
        position = get_position(phone)
        logging.info(f"[waitlist] {phone_plus} joined pos={position} code={my_code}")
        return {'position': position, 'code': my_code, 'already_joined': False}

    except Exception as e:
        logging.error(f"[waitlist] join_waitlist error: {e}", exc_info=True)
        try:
            conn.rollback()
        except Exception:
            pass
        return {'position': -1, 'code': '', 'already_joined': False}
    finally:
        conn.close()
