"""
shared/feedback.py — Universal feedback command for all user roles.
"feedback [text]"  → saves immediately and confirms.
"feedback" alone   → prompts; next reply is saved.
"""
import logging, uuid
from shared.db import get_connection
from shared.sender import send_message


def handle_feedback(phone: str, message: str, session: dict, role: str = "UNKNOWN") -> None:
    msg  = (message or "").strip()
    flow = (session or {}).get("_flow", "")

    # In-flow: user typed their feedback after being prompted
    if flow == "FEEDBACK":
        if msg.lower() in ("menu", "back", "cancel", "exit", "0"):
            from shared.session import clear_session
            clear_session(phone)
            send_message(phone, "No problem. Type *menu* to continue.")
            return
        _save_and_confirm(phone, msg, role)
        return

    # "feedback <text>" → save immediately
    if msg.lower().startswith("feedback ") and len(msg) > 9:
        _save_and_confirm(phone, msg[9:].strip(), role)
        return

    # "feedback" alone → prompt
    from shared.session import save_session
    save_session(phone, {"_flow": "FEEDBACK"})
    send_message(phone,
        "💬 *Share Your Feedback*\n"
        "━━━━━━━━━━━━━━━━━━━━━━\n\n"
        "What's working? What's missing?\n"
        "What can we do better?\n\n"
        "Just type your message and send it.\n"
        "_Type *menu* to cancel._"
    )


def _save_and_confirm(phone: str, text: str, role: str) -> None:
    if not text:
        return
    _write_to_db(phone, text[:2000], role)
    from shared.session import clear_session
    clear_session(phone)
    send_message(phone,
        "✅ *Thank you — feedback received!*\n\n"
        "We read every response. Your input helps us build\n"
        "a better platform for Nigerian traders and businesses.\n\n"
        "Type *menu* to continue."
    )


def _write_to_db(phone: str, text: str, role: str) -> None:
    try:
        conn = get_connection()
        cur  = conn.cursor()
        fid  = f"FB-{uuid.uuid4().hex[:12].upper()}"
        clean = phone.lstrip("+").strip()
        cur.execute("""
            INSERT INTO dbo.Feedback
                (feedback_id, phone_number, role, message, created_at)
            VALUES (%s, %s, %s, %s, GETUTCDATE())
        """, (fid, clean, role, text))
        conn.commit()
        conn.close()
    except Exception as e:
        logging.error(f"[feedback._write] {e}")
