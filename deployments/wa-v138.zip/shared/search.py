"""Commodity search stub — returns None until search index is built."""
def search_commodity(query: str):
    return None
