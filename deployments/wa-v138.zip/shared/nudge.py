_NUDGES = {
    "PRICES":    {"en": "\n\n💡 _Want to track this price? Type *alerts* to get notified._",
                  "pcm": "\n\n💡 _You wan track this price? Type *alerts*._"},
    "TREND":     {"en": "\n\n💡 _See how this compares across states? Type *compare*._",
                  "pcm": "\n\n💡 _You wan see how e dey for other states? Type *compare*._"},
    "COMPARE":   {"en": "\n\n💡 _Find the best buying route? Type *arbitrage*._",
                  "pcm": "\n\n💡 _You wan know where to buy cheapest? Type *arbitrage*._"},
    "FORECAST":  {"en": "\n\n💡 _Set an alert if this forecast materialises? Type *alerts*._",
                  "pcm": "\n\n💡 _You wan get alert if price reach target? Type *alerts*._"},
    "ARBITRAGE": {"en": "\n\n💡 _See the price history for this commodity? Type *trend*._",
                  "pcm": "\n\n💡 _You wan see price history? Type *trend*._"},
    "SNAPSHOT":  {"en": "\n\n💡 _Want to forecast prices in this region? Type *forecast*._",
                  "pcm": "\n\n💡 _You wan guess price for this region? Type *forecast*._"},
    "BRIEF":     {"en": "\n\n💡 _Set an alert for any of these movers? Type *alerts*._",
                  "pcm": "\n\n💡 _You wan set alert for any of these? Type *alerts*._"},
}

def get_nudge(lang: str, flow: str) -> str:
    entry = _NUDGES.get(flow.upper(), {})
    return entry.get("pcm" if lang == "pcm" else "en", "")
