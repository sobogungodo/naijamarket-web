import os, requests, logging

def send_message(phone: str, message: str):
    token    = os.environ.get("META_ACCESS_TOKEN","")
    phone_id = os.environ.get("META_PHONE_NUMBER_ID","")
    if not token or not phone_id:
        logging.warning(f"[sender] META vars not set"); return
    clean = phone.replace("+","").strip()
    try:
        r = requests.post(
            f"https://graph.facebook.com/v25.0/{phone_id}/messages",
            headers={"Authorization":f"Bearer {token}","Content-Type":"application/json"},
            json={"messaging_product":"whatsapp","to":clean,"type":"text","text":{"body":message[:4096]}},
            timeout=10
        )
        if not r.ok:
            logging.warning(f"[sender] {r.status_code}: {r.text[:200]}")
    except Exception as e:
        logging.error(f"[sender] {e}")


def send_template_message(phone: str, template_name: str,
                           body_params: list = None,
                           language: str = "en",
                           button_url_param: str = None) -> bool:
    """
    Send a Meta-approved WhatsApp template message.
    body_params:      list of strings for {{1}}, {{2}} body variables.
    button_url_param: optional value for a dynamic-URL button's {{1}} suffix
                      (e.g. a magic-link token). Appended as a button component.
    Template must be approved in Meta Business Manager first.
    Returns True on success.
    """
    import os, requests
    token    = os.environ.get("META_ACCESS_TOKEN", "")
    phone_id = os.environ.get("META_PHONE_NUMBER_ID", "")
    to       = phone.replace("+", "").strip()

    payload = {
        "messaging_product": "whatsapp",
        "to": to,
        "type": "template",
        "template": {
            "name": template_name,
            "language": {"code": language},
        }
    }

    components = []
    if body_params:
        components.append({
            "type": "body",
            "parameters": [{"type": "text", "text": str(p)} for p in body_params]
        })
    if button_url_param is not None:
        components.append({
            "type": "button",
            "sub_type": "url",
            "index": "0",
            "parameters": [{"type": "text", "text": str(button_url_param)}]
        })
    if components:
        payload["template"]["components"] = components

    try:
        r = requests.post(
            f"https://graph.facebook.com/v25.0/{phone_id}/messages",
            headers={"Authorization": f"Bearer {token}",
                     "Content-Type": "application/json"},
            json=payload, timeout=10
        )
        if r.status_code != 200:
            import logging
            logging.error(f"[send_template] {template_name} → {r.status_code}: {r.text[:200]}")
            return False
        return True
    except Exception as e:
        import logging
        logging.error(f"[send_template] {e}")
        return False
