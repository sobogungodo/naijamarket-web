def normalize(raw: str) -> str:
    p = raw.replace("whatsapp:","").replace("+","").replace(" ","").strip()
    return p

def to_whatsapp(phone: str) -> str:
    return phone.replace("+","").strip()
