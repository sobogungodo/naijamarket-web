"""Language helpers — get/set preferred_language for consumer."""
import logging

VALID_LANGS = {"en", "pcm"}
DEFAULT_LANG = "en"

def get_lang(session: dict, consumer: dict = None) -> str:
    session  = session  or {}
    consumer = consumer or {}
    lang = session.get("lang") or consumer.get("preferred_language") or DEFAULT_LANG
    return lang if lang in VALID_LANGS else DEFAULT_LANG

def set_lang(phone: str, lang: str) -> bool:
    if lang not in VALID_LANGS:
        return False
    try:
        from shared.db import get_connection
        conn = get_connection()
        cur  = conn.cursor()
        cur.execute("""
            UPDATE dbo.Consumers
            SET preferred_language = %s
            WHERE phone = %s OR phone_number = %s
        """, (lang, phone, phone))
        conn.commit()
        conn.close()
        return True
    except Exception as e:
        logging.error(f"[lang] set_lang: {e}")
        return False
