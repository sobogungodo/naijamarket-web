"""
shared/trader_lang.py — Language helpers for the TRADER role.

Mirrors shared/lang.py (consumer) but reads/writes
dbo.Traders_register.preferred_language (the column already exists,
NVARCHAR(255)). Values are normalised to lowercase 'en' / 'pcm';
NULL or anything unexpected falls back to DEFAULT_LANG.
"""
import logging

VALID_LANGS  = {"en", "pcm"}
DEFAULT_LANG = "en"


def norm_lang(val) -> str:
    """Normalise any stored/raw value to a valid lowercase lang code."""
    if not val:
        return DEFAULT_LANG
    v = str(val).strip().lower()
    return v if v in VALID_LANGS else DEFAULT_LANG


def get_trader_lang(trader: dict = None, session: dict = None) -> str:
    """
    Resolve the trader's language.
    Precedence: session override → Traders_register.preferred_language → default.
    Both args optional so callers can pass whichever they hold.
    """
    session = session or {}
    trader  = trader  or {}
    raw = session.get("lang") or trader.get("preferred_language")
    return norm_lang(raw)


def set_trader_lang(phone: str, lang: str) -> bool:
    """
    Persist the trader's language to Traders_register.preferred_language.
    Matches both '+digits' and 'digits' phone variants. Returns True on success.
    """
    lang = norm_lang(lang)
    try:
        from shared.db import get_connection
        conn = get_connection()
        cur  = conn.cursor()
        p = (phone or "").lstrip("+").strip()
        cur.execute("""
            UPDATE dbo.Traders_register
            SET    preferred_language = %s
            WHERE  phone_number = %s
               OR  phone_number = %s
        """, (lang, p, f"+{p}"))
        conn.commit()
        conn.close()
        return True
    except Exception as e:
        logging.error(f"[trader_lang] set_trader_lang: {e}")
        return False
