"""
shared/freshness.py — Price data freshness indicator [1l]

Appended to every price reply. Shows when data was last updated and
warns if it's not from today (prices generated 3x/day: 08:30/11:30/14:30 WAT).
"""
from datetime import datetime, date, timezone, timedelta

# WAT = UTC+1
WAT_OFFSET = timedelta(hours=1)


def _today_wat() -> date:
    return (datetime.now(timezone.utc) + WAT_OFFSET).date()


def freshness_note(price_date, lang: str = "en") -> str:
    """
    Returns a single-line freshness suffix for a price reply.

    Args:
        price_date: date or datetime or str (YYYY-MM-DD) of the price
        lang: 'en' or 'pcm'
    Returns:
        Empty string if data is from today.
        Warning string if data is stale.
    """
    try:
        if price_date is None:
            return ""
        if isinstance(price_date, str):
            price_date = date.fromisoformat(price_date[:10])
        elif hasattr(price_date, "date"):
            price_date = price_date.date()

        today = _today_wat()
        delta = (today - price_date).days

        if delta <= 0:
            return ""  # Same-day data — no note needed

        if delta == 1:
            if lang == "pcm":
                return "\n⚠️ _Prices from yesterday — e no be today price_"
            return "\n⚠️ _Prices from yesterday — may not reflect current market_"

        # 2+ days old
        formatted = price_date.strftime("%-d %b")  # e.g. "3 Jun"
        if lang == "pcm":
            return f"\n⚠️ _Prices from {formatted} — e no be today price_"
        return f"\n⚠️ _Prices from {formatted} — may not reflect today's market_"

    except Exception:
        return ""  # Never crash the caller


def seasonal_note(price: float, month_avg: float, month_low: float, month_high: float, lang: str = "en") -> str:
    """Returns a seasonal context note comparing current price to monthly average."""
    try:
        if not price or not month_avg or month_avg <= 0: return ""
        pct = ((price - month_avg) / month_avg) * 100
        if abs(pct) < 3: return ""  # within 3% — not noteworthy
        rng = f"₦{month_low:,.0f}–₦{month_high:,.0f}" if month_low and month_high else ""
        if lang == "pcm":
            if pct < -3:
                return f"\n\U0001f4c5 _This month range: {rng}. Current price dey *{abs(pct):.0f}% below* this month average — good time to buy._"
            return f"\n\U0001f4c5 _This month range: {rng}. Current price dey *{abs(pct):.0f}% above* this month average — consider waiting._"
        if pct < -3:
            return f"\n\U0001f4c5 _Monthly range: {rng}. Currently *{abs(pct):.0f}% below* monthly average — good buying window._"
        return f"\n\U0001f4c5 _Monthly range: {rng}. Currently *{abs(pct):.0f}% above* monthly average — consider waiting._"
    except Exception:
        return ""
