import json, logging
from decimal import Decimal
from shared.db import get_connection

class _SafeEncoder(json.JSONEncoder):
    """Converts Decimal → float so pymssql numeric results never break json.dumps."""
    def default(self, o):
        if isinstance(o, Decimal):
            logging.warning(f"[session._SafeEncoder] Decimal auto-converted: {o}")
            return float(o)
        return super().default(o)

def get_session(phone: str) -> dict:
    try:
        conn = get_connection(); cur = conn.cursor(as_dict=True)
        clean = phone.replace("+","").strip()
        cur.execute("""
            SELECT session_data FROM dbo.Consumer_Query_Sessions
            WHERE phone_number = %s AND session_status = 'ACTIVE'
        """, (clean,))
        row = cur.fetchone(); conn.close()
        if row and row.get("session_data"):
            return json.loads(row["session_data"])
    except Exception as e:
        logging.error(f"[session.get] {e}")
    return {}

def save_session(phone: str, data: dict):
    try:
        conn = get_connection(); cur = conn.cursor()
        clean = phone.replace("+","").strip()
        js = json.dumps(data, cls=_SafeEncoder)
        import uuid
        sid = str(uuid.uuid4())[:20]
        cur.execute("""
            MERGE dbo.Consumer_Query_Sessions AS t
            USING (SELECT %s AS phone_number) AS s ON t.phone_number = s.phone_number
            WHEN MATCHED THEN
                UPDATE SET session_data=%s, session_status='ACTIVE', last_updated=GETUTCDATE()
            WHEN NOT MATCHED THEN
                INSERT (session_id, phone_number, session_data, session_status, last_updated)
                VALUES (%s, %s, %s, 'ACTIVE', GETUTCDATE());
        """, (clean, js, sid, clean, js))
        conn.commit(); conn.close()
    except Exception as e:
        logging.error(f"[session.save] {e}")

def clear_session(phone: str):
    """Clear session but preserve rate limit keys to prevent reset abuse."""
    try:
        conn = get_connection(); cur = conn.cursor(as_dict=True)
        clean = phone.replace("+","").strip()
        # Preserve rate limit state across session clears
        cur.execute("""
            SELECT session_data FROM dbo.Consumer_Query_Sessions
            WHERE phone_number = %s AND session_status = 'ACTIVE'
        """, (clean,))
        row = cur.fetchone()
        preserved = {}
        if row and row.get("session_data"):
            try:
                old_data = json.loads(row["session_data"])
                if "_rate_count" in old_data: preserved["_rate_count"] = old_data["_rate_count"]
                if "_rate_reset"  in old_data: preserved["_rate_reset"]  = old_data["_rate_reset"]
            except Exception:
                pass
        js = json.dumps(preserved, cls=_SafeEncoder)
        cur2 = conn.cursor()
        cur2.execute(
            "UPDATE dbo.Consumer_Query_Sessions SET session_status='EXPIRED', session_data=%s WHERE phone_number=%s",
            (js, clean))
        conn.commit(); conn.close()
    except Exception as e:
        logging.error(f"[session.clear] {e}")
