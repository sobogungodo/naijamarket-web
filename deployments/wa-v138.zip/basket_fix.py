import logging
from shared.db import get_connection
from shared.sender import send_message
from shared.session import save_session, clear_session
from shared.lang import get_lang
from shared.i18n import t
from consumer.menu import show_main_menu

def handle_basket(phone, message="", session=None, consumer=None, *args):
    session=session or {}; consumer=consumer or {}
    lang=get_lang(session,consumer)
    text=(message or "").strip(); msg=text.lower()
    step=session.get("step",0)
    items=session.get("_basket_items",[])

    if msg in ("0","menu","back"):
        clear_session(phone); show_main_menu(phone); return

    if msg=="clear":
        session["_basket_items"]=[]; session["step"]=1
        save_session(phone,session)
        send_message(phone,t(lang,"basket_cleared")); return

    if msg=="done":
        if not items:
            send_message(phone,t(lang,"basket_empty")); return
        _show_summary(phone,items,lang); return

    # Prevent "basket" keyword being treated as commodity search
    if msg=="basket" and step==1:
        items=session.get("_basket_items",[])
        total=sum(i["price"] for i in items)
        send_message(phone,
            f"🛒 Basket has *{len(items)} item(s)* | Total: *₦{total:,.0f}*\n\nType next commodity, *done* to finish, or *clear* to reset." if lang=="en"
            else f"🛒 Basket get *{len(items)} item(s)* | Total: *₦{total:,.0f}*\n\nType next commodity, *done* to finish, or *clear* to reset.")
        return

    if step==0:
        session.update({"_flow":"BASKET","step":1,"_basket_items":[]}); save_session(phone,session)
        send_message(phone,t(lang,"basket_title")); return

    # step=1: accumulate items
    _add_item(phone,text,session,lang)

def _add_item(phone,query,session,lang):
    try:
        conn=get_connection(); cur=conn.cursor()
        cur.execute(
            "SELECT TOP 1 item_name,AVG(price_naira) AS avg_p,unit "
            "FROM dbo.Latest_Prices_Summary "
            "WHERE item_name LIKE %s AND is_nbs_ref=0 AND is_food=1 AND price_naira>0 "
            "GROUP BY item_name,unit ORDER BY item_name",
            (f"%{query}%",))
        row=cur.fetchone(); conn.close()
        if not row:
            send_message(phone,t(lang,"basket_not_found",q=query)); return
        item={"name":row["item_name"],"price":float(row["avg_p"] or 0),"unit":row["unit"] or "unit"}
        items=session.get("_basket_items",[])
        items.append(item)
        session["_basket_items"]=items
        save_session(phone,session)
        total=sum(i["price"] for i in items)
        if lang=="pcm":
            send_message(phone,t(lang,"basket_added",name=item["name"],price=item["price"],
                unit=item["unit"],count=len(items),total=total))
        else:
            send_message(phone,t(lang,"basket_added",name=item["name"],price=item["price"],
                unit=item["unit"],count=len(items),total=total))
    except Exception as e:
        logging.error(f"[basket._add_item] {e}"); send_message(phone,t(lang,"error_generic"))

def _show_summary(phone,items,lang):
    try:
        lines="\n".join(
            f"{i+1}. {it['name']}: *\u20a6{it['price']:,.0f}* per {it['unit']}"
            for i,it in enumerate(items))
        total=sum(it["price"] for it in items)
        send_message(phone,t(lang,"basket_summary",
            count=len(items),lines=lines,total=total))
        # Don't clear — user may want to add more
    except Exception as e:
        logging.error(f"[basket._show_summary] {e}"); send_message(phone,t(lang,"error_generic"))
