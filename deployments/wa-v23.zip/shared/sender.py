import os, requests, logging

def send_message(phone: str, message: str):
    token    = os.environ.get("META_ACCESS_TOKEN","")
    phone_id = os.environ.get("META_PHONE_NUMBER_ID","")
    if not token or not phone_id:
        logging.warning(f"[sender] META vars not set"); return
    clean = phone.replace("+","").strip()
    try:
        r = requests.post(
            f"https://graph.facebook.com/v19.0/{phone_id}/messages",
            headers={"Authorization":f"Bearer {token}","Content-Type":"application/json"},
            json={"messaging_product":"whatsapp","to":clean,"type":"text","text":{"body":message[:4096]}},
            timeout=10
        )
        if not r.ok:
            logging.warning(f"[sender] {r.status_code}: {r.text[:200]}")
    except Exception as e:
        logging.error(f"[sender] {e}")
