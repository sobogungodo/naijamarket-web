"""
shared/freshness.py — Price data freshness indicator [1l]

Appended to every price reply. Shows when data was last updated and
warns if it's not from today (prices generated 3x/day: 08:30/11:30/14:30 WAT).
"""
from datetime import datetime, date, timezone, timedelta

# WAT = UTC+1
WAT_OFFSET = timedelta(hours=1)


def _today_wat() -> date:
    return (datetime.now(timezone.utc) + WAT_OFFSET).date()


def freshness_note(price_date, lang: str = "en") -> str:
    """
    Returns a single-line freshness suffix for a price reply.

    Args:
        price_date: date or datetime or str (YYYY-MM-DD) of the price
        lang: 'en' or 'pcm'
    Returns:
        Empty string if data is from today.
        Warning string if data is stale.
    """
    try:
        if price_date is None:
            return ""
        if isinstance(price_date, str):
            price_date = date.fromisoformat(price_date[:10])
        elif hasattr(price_date, "date"):
            price_date = price_date.date()

        today = _today_wat()
        delta = (today - price_date).days

        if delta <= 0:
            return ""  # Same-day data — no note needed

        if delta == 1:
            if lang == "pcm":
                return "\n⚠️ _Prices from yesterday — e no be today price_"
            return "\n⚠️ _Prices from yesterday — may not reflect current market_"

        # 2+ days old
        formatted = price_date.strftime("%-d %b")  # e.g. "3 Jun"
        if lang == "pcm":
            return f"\n⚠️ _Prices from {formatted} — e no be today price_"
        return f"\n⚠️ _Prices from {formatted} — may not reflect today's market_"

    except Exception:
        return ""  # Never crash the caller
