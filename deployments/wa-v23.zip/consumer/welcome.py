"""
consumer/welcome.py — First-touch welcome flow [1h]

Triggered when a user messages for the first time (no Consumers record found).
Steps:
  1. Show greeting + language choice
  2. User picks language → persist + show sample price
  3. Route to main menu

Also records WhatsApp opt-in on completion.
"""
import logging
from shared.db       import get_connection
from shared.sender   import send_message
from shared.session  import save_session, clear_session
from shared.lang     import set_lang
from shared.i18n     import t
from shared.optin    import record_optin


def _get_sample_prices() -> str:
    """Fetch 3 sample prices from Lagos for the welcome screen."""
    try:
        conn = get_connection()
        cur  = conn.cursor()
        cur.execute(
            """
            SELECT TOP 3 item_name, price_naira, unit, trend
            FROM dbo.Latest_Prices_Summary
            WHERE state = 'Lagos'
              AND is_nbs_ref = 0
              AND is_food    = 1
              AND price_naira > 0
              AND category_id IN (
                  SELECT TOP 3 category_id
                  FROM dbo.Latest_Prices_Summary
                  WHERE state='Lagos' AND is_nbs_ref=0 AND is_food=1
                  GROUP BY category_id
                  ORDER BY COUNT(*) DESC
              )
            ORDER BY NEWID()
            """,
        )
        rows = cur.fetchall()
        conn.close()
        if not rows:
            return "Rice 50kg — ₦54,000\nBeans Brown — ₦98,000\nTomatoes (basket) — ₦35,000"
        lines = []
        for r in rows:
            arrow = "📈" if (r.get("trend") or "").lower() == "up" else ("📉" if (r.get("trend") or "").lower() == "down" else "➡️")
            lines.append(f"• {r['item_name']}: ₦{float(r['price_naira']):,.0f}/{r.get('unit','unit')} {arrow}")
        return "\n".join(lines)
    except Exception as e:
        logging.warning(f"[welcome] _get_sample_prices: {e}")
        return "Rice 50kg — ₦54,000\nBeans Brown — ₦98,000\nTomatoes (basket) — ₦35,000"


def start_welcome(phone: str):
    """Entry point — show greeting + language choice."""
    session = {"_flow": "WELCOME", "_step": "LANG_PICK"}
    save_session(phone, session)
    send_message(phone, t("en", "welcome_greeting"))


def handle_welcome(phone: str, message: str, session: dict, consumer: dict):
    """Handle ongoing welcome flow steps."""
    step = session.get("_step", "LANG_PICK")
    msg  = message.strip().lower()

    if msg in ("0", "menu", "back", "cancel"):
        clear_session(phone)
        from consumer.menu import show_main_menu
        show_main_menu(phone)
        return

    if step == "LANG_PICK":
        if msg == "1":
            lang = "en"
        elif msg == "2":
            lang = "pcm"
        else:
            send_message(phone, t("en", "welcome_invalid"))
            return

        # Persist language
        set_lang(phone, lang)

        # Record opt-in
        record_optin(phone, channel="WELCOME_FLOW")

        # Show sample prices + capabilities
        sample = _get_sample_prices()
        send_message(phone, t(lang, "welcome_sample", sample_lines=sample))

        # Transition to main menu flow
        clear_session(phone)
        return

    # Fallback — restart step
    send_message(phone, t("en", "welcome_greeting"))
    session["_step"] = "LANG_PICK"
    save_session(phone, session)
