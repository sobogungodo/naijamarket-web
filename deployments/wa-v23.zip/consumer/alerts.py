import logging,uuid
from shared.db import get_connection
from shared.sender import send_message
from shared.session import save_session, clear_session
from shared.lang import get_lang
from shared.i18n import t
from consumer.menu import show_main_menu

def handle_alerts(phone, message="", session=None, consumer=None, *args):
    session=session or {}; consumer=consumer or {}
    lang=get_lang(session,consumer); text=(message or "").strip(); msg=text.lower()
    step=session.get("step",0)
    if msg in ("0","menu","back") and step==0: clear_session(phone); show_main_menu(phone); return
    if msg=="0": clear_session(phone); show_main_menu(phone); return
    if step==0: _menu(phone,session,consumer,lang)
    elif step==1: _action(phone,text,session,consumer,lang)
    elif step==2: _item(phone,text,session,lang)
    elif step==3: _price(phone,text,session,lang)
    elif step==4: _type(phone,text,session,lang)
    elif step==10: _delete(phone,text,session,lang)

def _menu(phone,session,consumer,lang):
    try:
        cid=(consumer or {}).get("consumer_id","")
        conn=get_connection(); cur=conn.cursor()
        cur.execute("SELECT COUNT(*) AS cnt FROM dbo.Price_Alerts WHERE consumer_id=%s AND status=\'ACTIVE\'",(cid,))
        cnt=(cur.fetchone() or {}).get("cnt",0); conn.close()
        session.update({"_flow":"ALERTS","step":1}); save_session(phone,session)
        send_message(phone,t(lang,"alerts_menu",cnt=cnt))
    except Exception as e:
        logging.error(f"[alerts] {e}"); send_message(phone,t(lang,"error_generic"))

def _action(phone,text,session,consumer,lang):
    if text=="1":
        session.update({"step":2,"action":"set"}); save_session(phone,session)
        send_message(phone,t(lang,"alerts_set_item")); return
    if text=="2": _view(phone,consumer,lang); return
    if text=="3":
        session.update({"step":10}); save_session(phone,session)
        _view(phone,consumer,lang,for_delete=True); return
    send_message(phone,t(lang,"invalid_choice"))

def _item(phone,text,session,lang):
    try:
        conn=get_connection(); cur=conn.cursor()
        cur.execute("SELECT TOP 5 item_id,item_name FROM dbo.Latest_Prices_Summary WHERE item_name LIKE %s AND is_nbs_ref=0 AND is_food=1 GROUP BY item_id,item_name ORDER BY item_name",(f"%{text}%",))
        rows=cur.fetchall(); conn.close()
        if not rows: send_message(phone,t(lang,"not_found",q=text)+"\n\n*0* — Cancel"); return
        item=rows[0]
        session.update({"step":3,"item_id":item["item_id"],"item_name":item["item_name"]}); save_session(phone,session)
        send_message(phone,t(lang,"alerts_set_price",item=item["item_name"]))
    except Exception as e:
        logging.error(f"[alerts._item] {e}"); send_message(phone,t(lang,"error_generic"))

def _price(phone,text,session,lang):
    try:
        price=float(text.replace(",","").replace("\u20a6","").strip()); assert price>0
    except: send_message(phone,t(lang,"invalid_choice")); return
    session.update({"step":4,"target_price":price}); save_session(phone,session)
    send_message(phone,t(lang,"alerts_set_type",price=price))

def _type(phone,text,session,lang):
    if text not in ("1","2"): send_message(phone,t(lang,"invalid_choice")); return
    atype="BELOW" if text=="1" else "ABOVE"
    try:
        conn=get_connection(); cur=conn.cursor()
        aid=f"ALT{uuid.uuid4().hex[:16].upper()}"
        cid=session.get("consumer_id","")
        cur.execute("INSERT INTO dbo.Price_Alerts (alert_id,consumer_id,phone_number,item_id,item_name,target_price,alert_type,status,created_at) VALUES (%s,%s,%s,%s,%s,%s,%s,\'ACTIVE\',GETUTCDATE())",(aid,cid,phone,session.get("item_id",""),session.get("item_name",""),session.get("target_price",0),atype))
        conn.commit(); conn.close(); clear_session(phone)
        atype_lo="below" if atype=="BELOW" else "above"
        send_message(phone,t(lang,"alerts_saved",item=session.get("item_name",""),atype=atype,price=session.get("target_price",0),atype_lo=atype_lo))
    except Exception as e:
        logging.error(f"[alerts._type] {e}"); send_message(phone,t(lang,"error_generic"))

def _view(phone,consumer,lang,for_delete=False):
    try:
        cid=(consumer or {}).get("consumer_id","")
        conn=get_connection(); cur=conn.cursor()
        cur.execute("SELECT alert_id,item_name,target_price,alert_type FROM dbo.Price_Alerts WHERE consumer_id=%s AND status=\'ACTIVE\' ORDER BY created_at DESC",(cid,))
        rows=cur.fetchall(); conn.close()
        if not rows: clear_session(phone); send_message(phone,t(lang,"alerts_none")); return
        lines="\n".join(f"*{i+1}*. {r['item_name']} — {r['alert_type']} \u20a6{float(r['target_price']):,.0f}" for i,r in enumerate(rows))
        action=("\n\nSend number to delete, or *0* to cancel" if lang=="en" else "\n\nSend number to delete, or *0* to cancel") if for_delete else ""
        send_message(phone,f"\U0001f514 *{'YOUR ALERTS' if lang=='en' else 'YOUR ALERTS'}*\n\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\n\n{lines}{action}\n\n*menu* — Menu" + footer(lang))
    except Exception as e:
        logging.error(f"[alerts._view] {e}"); send_message(phone,t(lang,"error_generic"))

def _delete(phone,text,session,lang):
    try:
        cid=session.get("consumer_id","")
        conn=get_connection(); cur=conn.cursor()
        cur.execute("SELECT alert_id,item_name FROM dbo.Price_Alerts WHERE consumer_id=%s AND status=\'ACTIVE\' ORDER BY created_at DESC",(cid,))
        rows=cur.fetchall()
        idx=int(text)-1; assert 0<=idx<len(rows); alert=rows[idx]
        cur.execute("UPDATE dbo.Price_Alerts SET status=\'DELETED\' WHERE alert_id=%s",(alert["alert_id"],))
        conn.commit(); conn.close(); clear_session(phone)
        send_message(phone,t(lang,"alerts_deleted",item=alert["item_name"]))
    except: send_message(phone,t(lang,"invalid_choice")+"\n\n*0* — Cancel")
