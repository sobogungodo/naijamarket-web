import logging
TIER_ORDER=["FREE","SILVER","GOLD","BUSINESS","CORPORATE","ENTERPRISE"]
from shared.db import get_connection
from shared.sender import send_message
from shared.session import save_session, clear_session
from shared.lang import get_lang
from shared.i18n import t
from consumer.menu import show_main_menu

def handle_bulk(phone, message="", session=None, consumer=None, *args):
    session=session or {}; consumer=consumer or {}
    lang=get_lang(session,consumer); text=(message or "").strip(); msg=text.lower()
    tier=((consumer or {}).get("subscription_tier") or "FREE").upper()
    step=session.get("step",0)
    if msg in ("0","menu","back"): clear_session(phone); show_main_menu(phone); return
    if TIER_ORDER.index(tier)<TIER_ORDER.index("BUSINESS"): clear_session(phone); send_message(phone,t(lang,"bulk_locked")); return
    if step==0:
        session.update({"_flow":"BULK","step":1}); save_session(phone,session)
        send_message(phone,t(lang,"bulk_title"))
    elif step==1: _show(phone,text,lang)

def _show(phone,query,lang):
    try:
        conn=get_connection(); cur=conn.cursor()
        cur.execute("SELECT TOP 1 item_name FROM dbo.Latest_Prices_Summary WHERE item_name LIKE %s AND is_nbs_ref=0 AND is_food=1 GROUP BY item_name",(f"%{query}%",))
        row=cur.fetchone()
        if not row: conn.close(); send_message(phone,t(lang,"not_found",q=query)); return
        item_name=row["item_name"]
        cur.execute("SELECT TOP 10 market_name,state,price_naira,unit,confidence_score FROM dbo.Latest_Prices_Summary WHERE item_name=%s AND is_nbs_ref=0 AND is_food=1 AND price_naira>0 ORDER BY price_naira ASC",(item_name,))
        rows=cur.fetchall(); conn.close()
        if not rows: send_message(phone,t(lang,"error_generic")); return
        unit=rows[0]["unit"] or "unit"
        lines="\n".join(f"{i+1}. {r['market_name']} ({r['state']}): *\u20a6{float(r['price_naira']):,.0f}*"+(" \u2b50" if int(r["confidence_score"] or 0)>=80 else "") for i,r in enumerate(rows))
        nat_avg=sum(float(r["price_naira"]) for r in rows)/len(rows)
        savings=nat_avg-float(rows[0]["price_naira"])
        session.update({"step": 99})
        save_session(phone, session)
        _repeat = (
            "\n\n━━━━━━━━━━━━━━━━━━━━━━\n"
            ("*1* — Search again\n*0* — Menu" if lang == "en" else
             "*1* — Search again\n*0* — Menu")
        )
        send_message(phone,t(lang,"bulk_result",item=item_name,unit=unit,lines=lines,savings=savings) + _repeat)
    except Exception as e:
        logging.error(f"[bulk] {e}"); send_message(phone,t(lang,"error_generic"))

def _handle_repeat_search(phone, text, session, lang):
    """After result: 1=search again, 0=menu."""
    from shared.session import clear_session, save_session
    from consumer.menu import show_main_menu
    from shared.sender import send_message
    from shared.i18n import t
    msg = text.strip().lower()
    if msg == "0" or msg in ("menu", "back"):
        clear_session(phone); show_main_menu(phone); return
    if msg == "1":
        session["step"] = 0; save_session(phone, session)
        handle_bulk(phone, "", session, None)
        return
    send_message(phone, t(lang, "invalid_choice"))
