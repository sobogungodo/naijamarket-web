import logging
from shared.sender import send_message
from shared.db import get_consumer
from shared.session import clear_session
from shared.lang import get_lang
from shared.i18n import t

def handle_status(phone, *args):
    clear_session(phone)
    consumer=get_consumer(phone) or {}
    lang=get_lang({},consumer)
    tier=(consumer.get("subscription_tier") or "FREE").upper()
    end=str(consumer.get("subscription_end_date") or "")[:10] or "N/A"
    pending=consumer.get("pending_downgrade_tier")
    eff=str(consumer.get("downgrade_effective_date") or "")[:10]
    pending_line=""
    if pending:
        pending_line=f"\n\u26a0\ufe0f Pending downgrade to *{pending}* on {eff}\nType *cancel-downgrade* to cancel\n" if lang=="en" else f"\n\u26a0\ufe0f Downgrade to *{pending}* on {eff} dey pending\nType *cancel-downgrade* to cancel\n"
    send_message(phone,t(lang,"status_result",tier=tier,end=end,pending_line=pending_line))
