"""
consumer/prices.py — Price lookup
Drill-down: Region → State → Market → Category → Item
All tiers. Uses Latest_Prices_Summary.
"""
import logging
from shared.db import get_connection
from shared.sender import send_message
from shared.session import save_session, clear_session
from shared.lang import get_lang
from shared.i18n import t, footer
from shared.drilldown import REGION_LIST, REGIONS, pick_region, pick_state_for_region
from consumer.menu import show_main_menu


def handle_prices(phone, message="", session=None, consumer=None, *args):
    session  = session  or {}
    consumer = consumer or {}
    lang = get_lang(session, consumer)
    text = (message or "").strip()
    msg  = text.lower()
    step = session.get("step", 0)

    if msg in ("0", "menu", "exit"):
        clear_session(phone); show_main_menu(phone); return

    # 'back' navigates up one level
    if msg == "back":
        if step <= 1:
            clear_session(phone); show_main_menu(phone)
        elif step == 2:
            _start(phone, session, lang)          # back to region
        elif step == 3:
            _pick_state(phone, text, session, lang, go_back=True)  # back to state
        elif step == 4:
            _pick_market(phone, text, session, lang, go_back=True) # back to market
        elif step >= 5:
            _pick_category(phone, text, session, lang, go_back=True)
        return

    if step == 0: _start(phone, session, lang)
    elif step == 1: _pick_state(phone, text, session, lang)
    elif step == 2: _pick_market(phone, text, session, lang)
    elif step == 3: _pick_category(phone, text, session, lang)
    elif step == 4: _pick_item(phone, text, session, lang)
    elif step == 5: _show_price(phone, text, session, lang)
    elif step == 6: _handle_repeat(phone, text, session, lang)
    else: _start(phone, session, lang)


def _start(phone, session, lang):
    """Step 0 → 1: Show regions."""
    lines = "\n".join(f"*{i+1}*. {r}" for i, r in enumerate(REGION_LIST))
    session.update({"_flow": "PRICES", "step": 1})
    save_session(phone, session)
    send_message(phone, t(lang, "region_title", lines=lines) + footer(lang))


def _pick_state(phone, text, session, lang, go_back=False):
    """Step 1 → 2: User picked region, show states."""
    if go_back:
        # Going back to region
        _start(phone, session, lang)
        return
    try:
        idx = int(text) - 1
        assert 0 <= idx < len(REGION_LIST)
        region = REGION_LIST[idx]
    except:
        send_message(phone, t(lang, "invalid_choice")); return

    states = REGIONS.get(region, [])
    # Filter to states with actual data
    try:
        conn = get_connection(); cur = conn.cursor()
        cur.execute("SELECT DISTINCT state FROM dbo.Latest_Prices_Summary WHERE is_nbs_ref=0 AND is_food=1 AND state IS NOT NULL")
        db_states = {r["state"] for r in cur.fetchall()}; conn.close()
        states = [s for s in states if s in db_states] or states
    except Exception as e:
        logging.error(f"[prices._pick_state] {e}")

    lines = "\n".join(f"*{i+1}*. {s}" for i, s in enumerate(states))
    session.update({"step": 2, "region": region, "states": states})
    save_session(phone, session)
    send_message(phone, t(lang, "state_title", region=region, lines=lines) + footer(lang))


def _pick_market(phone, text, session, lang, go_back=False):
    """Step 2 → 3: User picked state, show markets."""
    if go_back:
        # Back to region
        _start(phone, session, lang)
        return
    states = session.get("states", [])
    try:
        idx = int(text) - 1; assert 0 <= idx < len(states); state = states[idx]
    except:
        send_message(phone, t(lang, "invalid_choice")); return
    try:
        conn = get_connection(); cur = conn.cursor()
        cur.execute("SELECT DISTINCT market_id, market_name FROM dbo.Latest_Prices_Summary WHERE state=%s AND is_nbs_ref=0 AND is_food=1 ORDER BY market_name", (state,))
        markets = [{"id": r["market_id"], "name": r["market_name"]} for r in cur.fetchall()]; conn.close()
        lines = "\n".join(f"*{i+1}*. {m['name']}" for i, m in enumerate(markets))
        session.update({"step": 3, "state": state, "markets": markets})
        save_session(phone, session)
        prompt = f"🏪 *{state}*\n────────────────\n\n{lines}\n\n*back* — States | *0* — Menu" + footer(lang)
        send_message(phone, prompt)
    except Exception as e:
        logging.error(f"[prices._pick_market] {e}"); send_message(phone, t(lang, "error_generic"))


def _pick_category(phone, text, session, lang, go_back=False):
    """Step 3 → 4: User picked market, show categories."""
    if go_back:
        # Back to state
        states = session.get("states", [])
        lines = "\n".join(f"*{i+1}*. {s}" for i, s in enumerate(states))
        region = session.get("region", "")
        session["step"] = 2; save_session(phone, session)
        send_message(phone, t(lang, "state_title", region=region, lines=lines) + footer(lang))
        return
    markets = session.get("markets", [])
    try:
        idx = int(text) - 1; assert 0 <= idx < len(markets); mkt = markets[idx]
    except:
        send_message(phone, t(lang, "invalid_choice")); return
    try:
        conn = get_connection(); cur = conn.cursor()
        cur.execute("SELECT DISTINCT category_id, category_name FROM dbo.Latest_Prices_Summary WHERE market_id=%s AND is_nbs_ref=0 AND is_food=1 ORDER BY category_name", (mkt["id"],))
        cats = [{"id": r["category_id"], "name": r["category_name"]} for r in cur.fetchall()]; conn.close()
        lines = "\n".join(f"*{i+1}*. {c['name']}" for i, c in enumerate(cats))
        session.update({"step": 4, "market_id": mkt["id"], "market_name": mkt["name"], "cats": cats})
        save_session(phone, session)
        prompt = f"📦 *{mkt['name']}*\n────────────────\n\n{lines}\n\n*back* — Markets | *0* — Menu" + footer(lang)
        send_message(phone, prompt)
    except Exception as e:
        logging.error(f"[prices._pick_category] {e}"); send_message(phone, t(lang, "error_generic"))


def _pick_item(phone, text, session, lang):
    """Step 4 → 5: User picked category, show items."""
    cats = session.get("cats", [])
    try:
        idx = int(text) - 1; assert 0 <= idx < len(cats); cat = cats[idx]
    except:
        send_message(phone, t(lang, "invalid_choice")); return
    try:
        conn = get_connection(); cur = conn.cursor()
        cur.execute("SELECT DISTINCT item_id, item_name FROM dbo.Latest_Prices_Summary WHERE market_id=%s AND category_id=%s AND is_nbs_ref=0 AND is_food=1 ORDER BY item_name", (session["market_id"], cat["id"]))
        items = [{"id": r["item_id"], "name": r["item_name"]} for r in cur.fetchall()]; conn.close()
        lines = "\n".join(f"*{i+1}*. {it['name']}" for i, it in enumerate(items))
        session.update({"step": 5, "cat_id": cat["id"], "cat_name": cat["name"], "items": items})
        save_session(phone, session)
        prompt = t(lang, "prices_pick_item", cat=cat["name"], lines=lines) + footer(lang)
        send_message(phone, prompt)
    except Exception as e:
        logging.error(f"[prices._pick_item] {e}"); send_message(phone, t(lang, "error_generic"))


def _show_price(phone, text, session, lang):
    """Step 5: Show price result."""
    items = session.get("items", [])
    try:
        idx = int(text) - 1; assert 0 <= idx < len(items); item = items[idx]
    except:
        send_message(phone, t(lang, "invalid_choice")); return
    try:
        conn = get_connection(); cur = conn.cursor()
        cur.execute("""
            SELECT TOP 1 item_name, market_name, unit, price_naira,
                   price_date, price_change_pct, trend,
                   week_low, week_high, month_low, month_high
            FROM dbo.Latest_Prices_Summary
            WHERE market_id=%s AND item_id=%s AND is_nbs_ref=0
            ORDER BY price_date DESC
        """, (session["market_id"], item["id"]))
        row = cur.fetchone(); conn.close()
        if not row: send_message(phone, t(lang, "not_found", q=item["name"])); return
        price = float(row["price_naira"] or 0)
        chg   = float(row["price_change_pct"] or 0)
        arrow = "📈" if chg > 0 else ("📉" if chg < 0 else "➡️")
        trend_word = ("dey go up" if chg > 0 else ("dey come down" if chg < 0 else "stable")) if lang == "pcm" else (row["trend"] or "stable")
        # Show price result then offer same/different market
        from shared.freshness import freshness_note
        result_msg = t(lang, "prices_result",
            item=item["name"], market=row["market_name"],
            price=price, unit=row["unit"] or "unit",
            arrow=arrow, change=abs(chg), trend=trend_word,
            wlo=float(row["week_low"] or 0), whi=float(row["week_high"] or 0),
            mlo=float(row["month_low"] or 0), mhi=float(row["month_high"] or 0),
            date=str(row["price_date"] or "")[:10])
        result_msg += freshness_note(row.get("price_date"), lang)
        repeat_prompt = (
            "\n\n━━━━━━━━━━━━━━━━━━━━━━\n"
            "*1* — Another item in this market\n"
            "*2* — Check different market\n"
            "*0* — Menu"
        ) if lang == "en" else (
            "\n\n━━━━━━━━━━━━━━━━━━━━━━\n"
            "*1* — Another item for same market\n"
            "*2* — Check different market\n"
            "*0* — Menu"
        )
        # Save repeat state so we can handle the response
        session.update({
            "step": 6,
            "last_market_id":   session.get("market_id"),
            "last_market_name": row["market_name"],
            "last_cats":        session.get("cats", []),
            "last_cat_id":      session.get("cat_id"),
            "last_cat_name":    session.get("cat_name"),
            "_share_card": {
                "item":   item["name"],
                "market": row["market_name"],
                "price":  float(price),
                "unit":   row["unit"] or "unit",
                "arrow":  arrow,
                "change": abs(chg),
                "trend":  trend_word,
                "wlo":    float(row["week_low"] or 0),
                "whi":    float(row["week_high"] or 0),
                "date":   str(row["price_date"] or "")[:10],
            },
        })
        save_session(phone, session)
        send_message(phone, result_msg + repeat_prompt)
    except Exception as e:
        logging.error(f"[prices._show_price] {e}"); send_message(phone, t(lang, "error_generic"))

def _handle_repeat(phone, text, session, lang):
    """Step 6: User chose same market or different market after price result."""
    msg = text.strip().lower()
    if msg in ("0", "menu"):
        clear_session(phone); show_main_menu(phone); return

    if msg == "1":
        # Same market — go back to category selection with same market
        cats = session.get("last_cats", [])
        market_name = session.get("last_market_name", "")
        if not cats:
            clear_session(phone); show_main_menu(phone); return
        lines = "\n".join(f"*{i+1}*. {c['name']}" for i, c in enumerate(cats))
        session.update({
            "step": 4,
            "market_id":   session.get("last_market_id"),
            "market_name": market_name,
            "cats":        cats,
        })
        save_session(phone, session)
        prompt = f"📦 *{market_name}*\n────────────────\n\n{lines}\n\n*back* — Markets | *0* — Menu" + footer(lang)
        send_message(phone, prompt)
        return

    if msg == "2":
        # Different market — restart from region
        _start(phone, session, lang)
        return

    # Invalid
    send_message(phone, t(lang, "invalid_choice"))
