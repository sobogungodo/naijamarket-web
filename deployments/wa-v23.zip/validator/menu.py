def handle_validator(phone, message="", session=None, *args):
    from shared.sender import send_message
    send_message(phone, "Validator — coming back online. Type *menu* to go back.")
