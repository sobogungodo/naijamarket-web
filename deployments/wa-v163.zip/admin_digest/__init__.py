"""
admin_digest — TimerTrigger: daily 10:00 WAT (09:00 UTC) admin WhatsApp digest [wa-v163]
Schedule is in function.json ("0 0 9 * * *"). The Functions host runs NCRONTAB in UTC
on Linux unless WEBSITE_TIME_ZONE is set — keep it unset/UTC so this stays 10:00 WAT.
"""
import logging
import azure.functions as func

from shared.admin_digest import send_digest


def main(mytimer: func.TimerRequest) -> None:
    if getattr(mytimer, "past_due", False):
        logging.warning("[admin_digest] timer is past due")
    logging.info("[admin_digest] timer fired — building daily digest")
    try:
        send_digest()
    except Exception as e:  # never let the timer crash the host
        logging.error(f"[admin_digest] unhandled error: {e}")
