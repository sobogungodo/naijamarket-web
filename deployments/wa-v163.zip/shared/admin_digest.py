"""
shared/admin_digest.py — daily admin metrics + WhatsApp digest [wa-v163]

Collects the 7 admin-dashboard metrics from naijafoodmarket-live and sends a
10:00 WAT daily digest to the admin(s) in the ADMIN_DIGEST_PHONE app setting
(comma-separated E.164 numbers). Outside the 24h window (the normal case for a
scheduled 10am send) it uses the Meta-approved 'admin_daily_digest' template;
inside the window it sends richer free-text.

Metric definitions mirror the admin dashboard's own SQL (app/api/users,
/submissions, etc.), excluding synthetic SYN-TR-%/SYN-VL-% rows. All datetime2
columns are UTC; "today" means the current WAT calendar day.
"""
import os
import logging
from datetime import datetime, timezone, timedelta

from shared.db import get_connection
from shared.messaging import is_in_24h_window
from shared.sender import send_message, send_template_message

WAT = timezone(timedelta(hours=1))
TEMPLATE_NAME = "admin_daily_digest"


def _wat_today_start_utc() -> datetime:
    """Midnight of the current WAT day, as naive UTC (to compare against UTC datetime2)."""
    now_wat = datetime.now(timezone.utc).astimezone(WAT)
    wat_midnight = now_wat.replace(hour=0, minute=0, second=0, microsecond=0)
    return wat_midnight.astimezone(timezone.utc).replace(tzinfo=None)


def collect_metrics() -> dict:
    """Query the 7 dashboard metrics. Never raises — missing values default to 0/'?'."""
    ts = _wat_today_start_utc()
    conn = get_connection()
    try:
        cur = conn.cursor(as_dict=True)

        def one(sql, params=()):
            cur.execute(sql, params)
            row = cur.fetchone() or {}
            return row

        active_traders = one(
            "SELECT COUNT(*) AS c FROM dbo.Traders_register "
            "WHERE trader_id NOT LIKE 'SYN-TR-%%' AND registration_status='APPROVED'"
        ).get("c", 0)

        submissions_today = one(
            "SELECT COUNT(*) AS c FROM dbo.Submissions "
            "WHERE trader_id NOT LIKE 'SYN-TR-%%' AND created_at >= %s", (ts,)
        ).get("c", 0)

        tp = one(
            "SELECT COUNT(*) AS c, ISNULL(SUM(TRY_CAST(net_amount AS float)),0) AS amt "
            "FROM dbo.Trader_Payout_Log WHERE UPPER(status)='PENDING'"
        )
        vp = one(
            "SELECT COUNT(*) AS c, ISNULL(SUM(TRY_CAST(net_amount AS float)),0) AS amt "
            "FROM dbo.Validator_Payout_Log WHERE UPPER(status)='PENDING'"
        )
        pending_count = (tp.get("c", 0) or 0) + (vp.get("c", 0) or 0)
        pending_amount = (tp.get("amt", 0) or 0) + (vp.get("amt", 0) or 0)

        fraud_today = one(
            "SELECT COUNT(*) AS c FROM dbo.Submissions "
            "WHERE fraud_flag=1 AND created_at >= %s", (ts,)
        ).get("c", 0)

        validator_accuracy = one(
            "SELECT ISNULL(AVG(CAST(accuracy_rate AS float)),0) AS a FROM dbo.Validators "
            "WHERE validator_id NOT LIKE 'SYN-VL-%%'"
        ).get("a", 0)

        new_traders = one(
            "SELECT COUNT(*) AS c FROM dbo.Traders_register "
            "WHERE trader_id NOT LIKE 'SYN-TR-%%' AND registered_at >= %s", (ts,)
        ).get("c", 0)
        new_validators = one(
            "SELECT COUNT(*) AS c FROM dbo.Validators "
            "WHERE validator_id NOT LIKE 'SYN-VL-%%' AND registered_at >= %s", (ts,)
        ).get("c", 0)

        return {
            "active_traders": int(active_traders or 0),
            "submissions_today": int(submissions_today or 0),
            "pending_payouts_count": int(pending_count or 0),
            "pending_payouts_amount": float(pending_amount or 0),
            "fraud_today": int(fraud_today or 0),
            "validator_accuracy": round(float(validator_accuracy or 0), 1),
            "new_users": int((new_traders or 0) + (new_validators or 0)),
            "health": "Operational",
        }
    finally:
        conn.close()


def _template_params(m: dict, date_label: str) -> list:
    """Ordered body params for the 'admin_daily_digest' template ({{1}}..{{8}})."""
    payouts = f"{m['pending_payouts_count']} (₦{m['pending_payouts_amount']:,.0f})"
    return [
        date_label,                       # {{1}}
        f"{m['active_traders']:,}",        # {{2}}
        f"{m['submissions_today']:,}",     # {{3}}
        payouts,                           # {{4}}
        str(m["fraud_today"]),             # {{5}}
        f"{m['validator_accuracy']:.1f}%", # {{6}}
        str(m["new_users"]),               # {{7}}
        m["health"],                       # {{8}}
    ]


def _freetext(m: dict, date_label: str) -> str:
    payouts = f"{m['pending_payouts_count']} (₦{m['pending_payouts_amount']:,.0f})"
    return (
        f"\U0001F4CA NaijaMarket Daily Digest — {date_label}\n\n"
        f"• Active traders: {m['active_traders']:,}\n"
        f"• Submissions today: {m['submissions_today']:,}\n"
        f"• Pending payouts: {payouts}\n"
        f"• Fraud/flagged today: {m['fraud_today']}\n"
        f"• Validator accuracy: {m['validator_accuracy']:.1f}%\n"
        f"• New users today: {m['new_users']}\n"
        f"• System health: {m['health']}"
    )


def send_digest() -> None:
    """Entry point for the timer. Sends the digest to every ADMIN_DIGEST_PHONE recipient."""
    phones = [p.strip() for p in os.environ.get("ADMIN_DIGEST_PHONE", "").split(",") if p.strip()]
    if not phones:
        logging.warning("[admin_digest] ADMIN_DIGEST_PHONE not set — nothing to send")
        return

    try:
        m = collect_metrics()
    except Exception as e:
        logging.error(f"[admin_digest] metric collection failed: {e}")
        return

    date_label = datetime.now(WAT).strftime("%a %d %b %Y")
    params = _template_params(m, date_label)
    freetext = _freetext(m, date_label)
    logging.info(f"[admin_digest] metrics: {m}")

    for phone in phones:
        try:
            if is_in_24h_window(phone):
                send_message(phone, freetext)
                logging.info(f"[admin_digest] freetext sent to {phone}")
            else:
                ok = send_template_message(phone, TEMPLATE_NAME, body_params=params, language="en")
                logging.info(
                    f"[admin_digest] template '{TEMPLATE_NAME}' to {phone}: "
                    f"{'sent' if ok else 'FAILED (approved in Meta?)'}"
                )
        except Exception as e:
            logging.error(f"[admin_digest] send to {phone} failed: {e}")
