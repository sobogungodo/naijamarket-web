"""
consumer/guest_prices.py — Price search for unregistered pre-launch trial users.
3 free searches, waitlist CTA after each, hard gate after 3rd.
"""
import logging
from shared.db import get_connection
from shared.sender import send_message
from shared.session import save_session, clear_session
from shared.drilldown import REGION_LIST, REGIONS
from shared.guest_trial import get_guest_count, increment_guest_count, is_on_waitlist, add_to_waitlist, MAX_GUEST_SEARCHES

WAITLIST_CTA = (
    "\n\n\u23f3 *NaijaMarket Intel launches December 2026.*\n"
    "Reply *WAITLIST* to reserve your spot \u2014 we'll notify you on WhatsApp the moment we go live."
)
WAITLIST_ALREADY = (
    "\u2705 You're already on our waitlist!\n\n"
    "We'll notify you on WhatsApp when we launch in December 2026.\n\n"
    "Reply *1* to search another price."
)
WAITLIST_JOINED = (
    "\U0001f389 You're on the list!\n\n"
    "We'll send you a WhatsApp message the moment NaijaMarket Intel launches in December 2026.\n\n"
    "Tell a friend: wa.me/2349131095009?text=menu"
)
HARD_GATE = (
    "\u26a0\ufe0f You've used your *3 free preview searches*.\n\n"
    "NaijaMarket Intel launches *December 2026*. Join our waitlist and we'll notify you "
    "on WhatsApp the moment we go live with full access.\n\n"
    "Reply *WAITLIST* to reserve your spot."
)

def handle_guest_prices(phone, message="", session=None):
    session = session or {}
    text = (message or "").strip()
    msg = text.lower()
    if msg == "waitlist":
        _handle_waitlist_join(phone); return
    count = get_guest_count(phone)
    if count >= MAX_GUEST_SEARCHES:
        send_message(phone, WAITLIST_ALREADY if is_on_waitlist(phone) else HARD_GATE); return
    step = session.get("step", 0)
    if msg in ("0","menu","exit"):
        clear_session(phone)
        send_message(phone, "\U0001f3e0 Type *menu* anytime.\n\nReply *WAITLIST* to join our December 2026 launch list."); return
    if msg == "back":
        if step <= 1: clear_session(phone); _show_guest_start(phone, session)
        elif step == 2: _show_guest_start(phone, session)
        elif step == 3: _guest_pick_state(phone, text, session, go_back=True)
        elif step == 4: _guest_pick_market(phone, text, session, go_back=True)
        elif step >= 5: _guest_pick_category(phone, text, session, go_back=True)
        return
    if step == 0: _show_guest_start(phone, session)
    elif step == 1: _guest_pick_state(phone, text, session)
    elif step == 2: _guest_pick_market(phone, text, session)
    elif step == 3: _guest_pick_category(phone, text, session)
    elif step == 4: _guest_pick_item(phone, text, session)
    elif step == 5: _guest_show_price(phone, text, session)
    elif step == 6: _guest_handle_repeat(phone, text, session)
    else: _show_guest_start(phone, session)

def _handle_waitlist_join(phone):
    if is_on_waitlist(phone): send_message(phone, WAITLIST_ALREADY)
    else: add_to_waitlist(phone); send_message(phone, WAITLIST_JOINED)
    clear_session(phone)

def _show_guest_start(phone, session):
    count = get_guest_count(phone)
    remaining = MAX_GUEST_SEARCHES - count
    lines = "\n".join(f"*{i+1}*. {r}" for i,r in enumerate(REGION_LIST))
    session.update({"_flow":"GUEST_PRICES","step":1})
    save_session(phone, session)
    send_message(phone,
        f"\U0001f4ca *Price Preview* ({remaining} of {MAX_GUEST_SEARCHES} free searches remaining)\n\n"
        f"Select your region:\n{lines}\n\n"
        f"_Reply *WAITLIST* anytime to join our December 2026 launch list._"
    )

def _guest_pick_state(phone, text, session, go_back=False):
    if not go_back:
        try:
            region_idx = int(text) - 1
            if region_idx < 0 or region_idx >= len(REGION_LIST): send_message(phone,"Invalid. Choose a number."); return
        except: send_message(phone,"Please reply with a number."); return
        session["region_idx"] = region_idx
    region_name = REGION_LIST[session.get("region_idx",0)]
    states = REGIONS.get(region_name,[])
    lines = "\n".join(f"*{i+1}*. {s}" for i,s in enumerate(states))
    session.update({"step":2,"region_name":region_name,"states":states})
    save_session(phone, session)
    send_message(phone, f"*{region_name}* \u2014 Select state:\n\n{lines}\n\n*0*. Back")

def _guest_pick_market(phone, text, session, go_back=False):
    if go_back: _show_guest_start(phone, session); return
    states = session.get("states",[])
    try:
        idx = int(text)-1
        if idx < 0 or idx >= len(states): send_message(phone,"Invalid selection."); return
    except: send_message(phone,"Please reply with a number."); return
    state_name = states[idx]; session["state_name"] = state_name
    try:
        conn = get_connection(); cur = conn.cursor(as_dict=True)
        cur.execute("SELECT DISTINCT market_id,market_name FROM dbo.Latest_Prices_Summary WHERE state=%s AND is_nbs_ref=0 AND is_food=1 ORDER BY market_name",(state_name,))
        markets = cur.fetchall(); conn.close()
    except Exception as e:
        logging.error(f"[guest_prices] markets: {e}"); send_message(phone,"Error loading markets."); return
    if not markets: send_message(phone,f"No markets for {state_name}. Reply *back*."); return
    lines = "\n".join(f"*{i+1}*. {m['market_name']}" for i,m in enumerate(markets))
    session.update({"step":3,"markets":[m["market_name"] for m in markets]})
    save_session(phone, session)
    send_message(phone, f"*{state_name}* markets:\n\n{lines}\n\n*0*. Back")

def _guest_pick_category(phone, text, session, go_back=False):
    if go_back: _guest_pick_state(phone,"",session,go_back=True); return
    markets = session.get("markets",[])
    try:
        idx = int(text)-1
        if idx < 0 or idx >= len(markets): send_message(phone,"Invalid selection."); return
    except: send_message(phone,"Please reply with a number."); return
    market_name = markets[idx]; session["market_name"] = market_name
    try:
        conn = get_connection(); cur = conn.cursor(as_dict=True)
        cur.execute("SELECT DISTINCT category_id,category_name FROM dbo.Latest_Prices_Summary WHERE market_name=%s AND is_nbs_ref=0 AND is_food=1 ORDER BY category_name",(market_name,))
        cats = cur.fetchall(); conn.close()
    except Exception as e:
        logging.error(f"[guest_prices] cats: {e}"); send_message(phone,"Error loading categories."); return
    lines = "\n".join(f"*{i+1}*. {c['category_name']}" for i,c in enumerate(cats))
    session.update({"step":4,"categories":[c["category_name"] for c in cats]})
    save_session(phone, session)
    send_message(phone, f"*{market_name}* \u2014 Select category:\n\n{lines}\n\n*0*. Back")

def _guest_pick_item(phone, text, session, go_back=False):
    if go_back: _guest_pick_category(phone,"",session,go_back=True); return
    cats = session.get("categories",[])
    try:
        idx = int(text)-1
        if idx < 0 or idx >= len(cats): send_message(phone,"Invalid selection."); return
    except: send_message(phone,"Please reply with a number."); return
    cat_name = cats[idx]; market_name = session.get("market_name","")
    session["category_name"] = cat_name
    try:
        conn = get_connection(); cur = conn.cursor(as_dict=True)
        cur.execute("SELECT DISTINCT item_id,item_name FROM dbo.Latest_Prices_Summary WHERE market_name=%s AND category_name=%s AND is_nbs_ref=0 AND is_food=1 ORDER BY item_name",(market_name,cat_name))
        items = cur.fetchall(); conn.close()
    except Exception as e:
        logging.error(f"[guest_prices] items: {e}"); send_message(phone,"Error loading items."); return
    lines = "\n".join(f"*{i+1}*. {it['item_name']}" for i,it in enumerate(items))
    session.update({"step":5,"items":[it["item_name"] for it in items]})
    save_session(phone, session)
    send_message(phone, f"*{cat_name}* items:\n\n{lines}\n\n*0*. Back")

def _guest_show_price(phone, text, session):
    items = session.get("items",[])
    try:
        idx = int(text)-1
        if idx < 0 or idx >= len(items): send_message(phone,"Invalid selection."); return
    except: send_message(phone,"Please reply with a number."); return
    item_name = items[idx]; market_name = session.get("market_name","")
    try:
        conn = get_connection(); cur = conn.cursor(as_dict=True)
        cur.execute("SELECT item_name,market_name,state,unit,price_naira,price_change_pct,price_date FROM dbo.Latest_Prices_Summary WHERE item_name=%s AND market_name=%s AND is_nbs_ref=0 AND is_food=1",(item_name,market_name))
        row = cur.fetchone(); conn.close()
    except Exception as e:
        logging.error(f"[guest_prices] price: {e}"); send_message(phone,"Error fetching price. Try again."); return
    if not row: send_message(phone,f"No price for {item_name} in {market_name}. Reply *back*."); return
    new_count = increment_guest_count(phone)
    remaining = MAX_GUEST_SEARCHES - new_count
    price = row.get("price_naira",0); chg = row.get("price_change_pct",0) or 0
    unit = row.get("unit",""); pdate = row.get("price_date","")
    arrow = "\u2197" if chg > 0 else ("\u2198" if chg < 0 else "\u27a1")
    result = (
        f"\U0001f4ca *{item_name}*\n"
        f"\U0001f4cd {market_name}, {row.get('state','')}\n\n"
        f"\U0001f4b0 *\u20a6{price:,.2f}* per {unit}\n"
        f"Change: {arrow} {abs(chg):.1f}%\n"
        f"Updated: {pdate}\n"
    )
    if remaining > 0:
        result += (f"\n\u2139\ufe0f *{remaining} free search{'es' if remaining!=1 else ''} remaining.*" + WAITLIST_CTA + "\n\nReply *1* to search another price.")
        session.update({"step":6}); save_session(phone,session)
    else:
        result += ("\n\n\U0001f6a8 *That was your last free preview.*" + WAITLIST_CTA)
        clear_session(phone)
    send_message(phone, result)

def _guest_handle_repeat(phone, text, session):
    msg = text.lower().strip()
    if msg == "1":
        count = get_guest_count(phone)
        if count >= MAX_GUEST_SEARCHES:
            send_message(phone, WAITLIST_ALREADY if is_on_waitlist(phone) else HARD_GATE); clear_session(phone)
        else:
            _show_guest_start(phone, session)
    elif msg == "waitlist":
        _handle_waitlist_join(phone)
    else:
        send_message(phone,"Reply *1* to search another price or *WAITLIST* to join our December 2026 launch list.")
