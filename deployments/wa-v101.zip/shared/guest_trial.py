"""
shared/guest_trial.py — Pre-launch guest trial management.
3 free price searches for unregistered users before waitlist gate.
"""
import json, logging, uuid
from shared.db import get_connection

MAX_GUEST_SEARCHES = 3

def get_guest_count(phone: str) -> int:
    try:
        clean = phone.replace("+","").strip()
        conn = get_connection(); cur = conn.cursor(as_dict=True)
        cur.execute("SELECT step_data FROM dbo.Unregistered_Exit_Log WHERE phone_number=%s",(clean,))
        row = cur.fetchone(); conn.close()
        if not row or not row.get("step_data"): return 0
        return int(json.loads(row["step_data"]).get("guest_searches",0))
    except Exception as e:
        logging.error(f"[guest_trial] get_guest_count: {e}"); return 0

def increment_guest_count(phone: str) -> int:
    try:
        clean = phone.replace("+","").strip()
        conn = get_connection(); cur = conn.cursor(as_dict=True)
        cur.execute("SELECT step_data FROM dbo.Unregistered_Exit_Log WHERE phone_number=%s",(clean,))
        row = cur.fetchone()
        if row:
            try: data = json.loads(row.get("step_data") or "{}")
            except: data = {}
            data["guest_searches"] = int(data.get("guest_searches",0)) + 1
            cur.execute("UPDATE dbo.Unregistered_Exit_Log SET step_data=%s WHERE phone_number=%s",(json.dumps(data),clean))
        else:
            data = {"guest_searches":1}
            cur.execute("INSERT INTO dbo.Unregistered_Exit_Log (phone_number,exit_count,current_step,step_data) VALUES (%s,0,%s,%s)",(clean,"GUEST_TRIAL",json.dumps(data)))
        conn.commit(); conn.close()
        return data["guest_searches"]
    except Exception as e:
        logging.error(f"[guest_trial] increment: {e}"); return 1

def is_on_waitlist(phone: str) -> bool:
    try:
        clean = phone.replace("+","").strip()
        conn = get_connection(); cur = conn.cursor(as_dict=True)
        cur.execute("SELECT waitlist_id FROM dbo.Waitlist WHERE phone_number=%s",(clean,))
        row = cur.fetchone(); conn.close()
        return row is not None
    except Exception as e:
        logging.error(f"[guest_trial] is_on_waitlist: {e}"); return False

def add_to_waitlist(phone: str) -> bool:
    try:
        clean = phone.replace("+","").strip()
        if is_on_waitlist(clean): return False
        conn = get_connection(); cur = conn.cursor()
        cur.execute("INSERT INTO dbo.Waitlist (waitlist_id,phone_number,source,created_at,wa_sent,email_sent) VALUES (%s,%s,%s,GETUTCDATE(),0,0)",(str(uuid.uuid4()),clean,"WHATSAPP_TRIAL"))
        conn.commit(); conn.close()
        return True
    except Exception as e:
        logging.error(f"[guest_trial] add_to_waitlist: {e}"); return False
