import azure.functions as func
import os, json

def main(req: func.HttpRequest) -> func.HttpResponse:
    results = {}
    try:
        import pymssql
        conn = pymssql.connect(
            server=os.environ["SQL_SERVER"],
            user=os.environ.get("SQL_USERNAME", os.environ.get("SQL_USER","")),
            password=os.environ["SQL_PASSWORD"],
            database=os.environ["SQL_DATABASE"],
            as_dict=True, timeout=10
        )
        cur = conn.cursor()
        cur.execute("SELECT 1 AS ok")
        results["db"] = "OK"
        conn.close()
    except Exception as e:
        results["db"] = f"FAIL: {str(e)}"
    try:
        from shared.sender import send_message
        phone = req.params.get("to", "358417203868")
        send_message(phone, "Flow debug test")
        results["send"] = "called"
    except Exception as e:
        results["send"] = f"FAIL: {str(e)}"
    return func.HttpResponse(json.dumps(results), mimetype="application/json")
