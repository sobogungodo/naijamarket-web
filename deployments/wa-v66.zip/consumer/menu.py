from shared.sender import send_message
from shared.db import get_consumer
from shared.lang import get_lang
from shared.i18n import t

def show_main_menu(phone: str):
    import logging
    try:
        consumer = get_consumer(phone) or {}
    except Exception as e:
        logging.error(f"[menu] get_consumer failed: {e}")
        consumer = {}
    tier  = (consumer.get("subscription_tier") or "FREE").upper()
    last4 = (consumer.get("phone_number") or consumer.get("phone") or phone)[-4:]
    lang  = get_lang({}, consumer)
    try:
        send_message(phone, t(lang, "menu_header", tier=tier, last4=last4))
        logging.info(f"[menu] sent to {phone}")
    except Exception as e:
        logging.error(f"[menu] send_message failed: {e}")
