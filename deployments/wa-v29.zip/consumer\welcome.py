"""
consumer/welcome.py — First-touch welcome flow [1h] + name/age collection

Steps:
  1. LANG_PICK   — language choice (EN / Pidgin)
  2. NAME_PICK   — "What is your name?"
  3. AGE_PICK    — age range selection (5 buckets)
  4. CREATE      — write Consumers + User_Roles, show sample prices, go to menu

Also records WhatsApp opt-in on completion.
"""
import logging
import uuid
from shared.db       import get_connection
from shared.sender   import send_message
from shared.session  import save_session, clear_session
from shared.lang     import set_lang
from shared.i18n     import t
from shared.optin    import record_optin

# Age range buckets — stored as-is in Consumers.age_range
AGE_RANGES = {
    "1": "Under 25",
    "2": "25-34",
    "3": "35-44",
    "4": "45-54",
    "5": "55 and above",
}


def _get_sample_prices() -> str:
    """Fetch 3 sample prices from Lagos for the welcome screen."""
    try:
        conn = get_connection()
        cur  = conn.cursor()
        cur.execute(
            """
            SELECT TOP 3 item_name, price_naira, unit, trend
            FROM dbo.Latest_Prices_Summary
            WHERE state = 'Lagos'
              AND is_nbs_ref = 0
              AND is_food    = 1
              AND price_naira > 0
              AND category_id IN (
                  SELECT TOP 3 category_id
                  FROM dbo.Latest_Prices_Summary
                  WHERE state='Lagos' AND is_nbs_ref=0 AND is_food=1
                  GROUP BY category_id
                  ORDER BY COUNT(*) DESC
              )
            ORDER BY NEWID()
            """,
        )
        rows = cur.fetchall()
        conn.close()
        if not rows:
            return "Rice 50kg — ₦54,000\nBeans Brown — ₦98,000\nTomatoes (basket) — ₦35,000"
        lines = []
        for r in rows:
            arrow = "📈" if (r.get("trend") or "").lower() == "up" else ("📉" if (r.get("trend") or "").lower() == "down" else "➡️")
            lines.append(f"• {r['item_name']}: ₦{float(r['price_naira']):,.0f}/{r.get('unit','unit')} {arrow}")
        return "\n".join(lines)
    except Exception as e:
        logging.warning(f"[welcome] _get_sample_prices: {e}")
        return "Rice 50kg — ₦54,000\nBeans Brown — ₦98,000\nTomatoes (basket) — ₦35,000"


def _create_consumer(phone: str, lang: str, full_name: str, age_range: str):
    """
    Insert into dbo.Consumers + dbo.User_Roles.
    Both are INSERT — consumer does not exist yet at this point.
    Idempotent: IF NOT EXISTS guards prevent duplicates on retry.
    """
    try:
        clean      = phone.replace("+", "").strip()
        phone_plus = f"+{clean}"
        first_name = full_name.strip().split()[0] if full_name.strip() else full_name.strip()
        consumer_id = str(uuid.uuid4())

        conn = get_connection()
        cur  = conn.cursor()

        # Insert Consumer record
        cur.execute(
            """
            IF NOT EXISTS (
                SELECT 1 FROM dbo.Consumers
                WHERE phone = %s OR phone_number = %s
            )
            INSERT INTO dbo.Consumers (
                consumer_id, phone, phone_number,
                first_name, full_name, age_range,
                preferred_language, subscription_tier,
                account_status, created_at
            ) VALUES (
                %s, %s, %s,
                %s, %s, %s,
                %s, 'FREE',
                'active', GETUTCDATE()
            )
            """,
            (clean, phone_plus,
             consumer_id, clean, phone_plus,
             first_name, full_name.strip(), age_range,
             lang)
        )

        # Insert User_Roles entry
        cur.execute(
            """
            IF NOT EXISTS (
                SELECT 1 FROM dbo.User_Roles
                WHERE phone_number = %s OR phone_number = %s
            )
            INSERT INTO dbo.User_Roles (phone_number, role, created_at)
            VALUES (%s, 'CONSUMER', GETUTCDATE())
            """,
            (clean, phone_plus, phone_plus)
        )

        conn.commit()
        conn.close()
        logging.info(f"[welcome] consumer created: {phone_plus} name={full_name} age={age_range} lang={lang}")

    except Exception as e:
        logging.error(f"[welcome] _create_consumer failed: {e}", exc_info=True)


def start_welcome(phone: str):
    """Entry point — show greeting + language choice."""
    session = {"_flow": "WELCOME", "_step": "LANG_PICK"}
    save_session(phone, session)
    send_message(phone, t("en", "welcome_greeting"))


def handle_welcome(phone: str, message: str, session: dict, consumer: dict):
    """Handle ongoing welcome flow steps."""
    step = session.get("_step", "LANG_PICK")
    msg  = message.strip()
    msg_lower = msg.lower()

    if msg_lower in ("0", "menu", "back", "cancel"):
        clear_session(phone)
        from consumer.menu import show_main_menu
        show_main_menu(phone)
        return

    # ── Step 1: Language pick ─────────────────────────────────────────────
    if step == "LANG_PICK":
        if msg == "1":
            lang = "en"
        elif msg == "2":
            lang = "pcm"
        else:
            send_message(phone, t("en", "welcome_invalid"))
            return

        set_lang(phone, lang)
        session["_lang"]  = lang
        session["_step"]  = "NAME_PICK"
        save_session(phone, session)
        send_message(phone, t(lang, "welcome_ask_name"))
        return

    # ── Step 2: Name pick ─────────────────────────────────────────────────
    if step == "NAME_PICK":
        lang = session.get("_lang", "en")
        name = msg.strip()

        if len(name) < 2:
            send_message(phone, t(lang, "welcome_name_invalid"))
            return

        session["_name"] = name
        session["_step"] = "AGE_PICK"
        save_session(phone, session)
        send_message(phone, t(lang, "welcome_ask_age"))
        return

    # ── Step 3: Age pick ──────────────────────────────────────────────────
    if step == "AGE_PICK":
        lang = session.get("_lang", "en")
        name = session.get("_name", "")

        if msg not in AGE_RANGES:
            send_message(phone, t(lang, "welcome_age_invalid"))
            return

        age_range = AGE_RANGES[msg]

        # Record opt-in
        record_optin(phone, channel="WELCOME_FLOW")

        # Create consumer record + role
        _create_consumer(phone, lang, name, age_range)

        # Show sample prices + capabilities
        sample = _get_sample_prices()
        first_name = name.split()[0]
        send_message(phone, t(lang, "welcome_sample",
                               sample_lines=sample,
                               first_name=first_name))

        clear_session(phone)
        return

    # Fallback — restart
    send_message(phone, t("en", "welcome_greeting"))
    session["_step"] = "LANG_PICK"
    save_session(phone, session)
