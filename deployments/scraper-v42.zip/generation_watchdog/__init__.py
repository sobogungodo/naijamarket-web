"""
generation_watchdog — HTTP trigger
===================================
Called daily via Azure Scheduler / cron job / external ping.
Checks if today's generation slots exist in Daily_Prices.
Runs any missing slots via sp_Generate_Daily_Prices, with retry hardening.

v41: each slot is retried up to MAX_ATTEMPTS with a fresh DB connection per
attempt, bounded by a wall-clock time budget (so we never exceed the 10-min
Consumption functionTimeout). After running, slots are re-checked and the
response reports status='error' if anything is still missing.

Endpoint: POST https://func-naijamarket-scraper.azurewebsites.net/api/generation_watchdog
Body: {} (empty) — runs all missing slots for today
Body: {"date": "2026-06-04"} — runs missing slots for specific date
Body: {"slot": "08:30"} — forces a specific slot regardless of existence
"""

import azure.functions as func
import logging
import json
import os
import sys
import time
from datetime import datetime, timezone, timedelta

sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))
from shared.db import get_connection

SLOTS = ['08:30', '11:30', '14:30']

# Retry / time-budget tuning
MAX_ATTEMPTS    = 2     # attempts per slot
RETRY_DELAY_SEC = 10    # gap between attempts
TIME_BUDGET_SEC = 510   # wall-clock budget (< 600s functionTimeout)
EST_SLOT_SEC    = 150   # estimated worst-case cost of one slot run


def get_missing_slots(conn, target_date: str):
    """Returns (missing_list, existing_set) for target_date."""
    cursor = conn.cursor(as_dict=True)
    cursor.execute("""
        SELECT DISTINCT time_slot
        FROM dbo.Daily_Prices
        WHERE price_date = %s AND nbs_adjusted = 0
    """, (target_date,))
    existing = {row['time_slot'] for row in cursor.fetchall()}
    cursor.close()
    missing = [s for s in SLOTS if s not in existing]
    return missing, existing


def run_slot(target_date: str, slot: str, deadline: datetime) -> dict:
    """
    Execute sp_Generate_Daily_Prices for one slot, with retries.
    Opens a FRESH connection per attempt (a failed attempt may have poisoned
    the previous connection). Honours the wall-clock deadline: never starts an
    attempt unless at least EST_SLOT_SEC remain. Returns a result dict that
    includes the attempt count.
    """
    last_error = None
    attempts   = 0

    for attempt in range(1, MAX_ATTEMPTS + 1):
        remaining = (deadline - datetime.now(timezone.utc)).total_seconds()
        if remaining < EST_SLOT_SEC:
            logging.warning(
                f"[watchdog] Slot {slot}: skipping attempt {attempt} — "
                f"only {int(remaining)}s left, need {EST_SLOT_SEC}s"
            )
            return {
                "slot": slot, "status": "error", "attempts": attempts,
                "error": f"insufficient time budget ({int(remaining)}s left)",
            }

        if attempt > 1:
            time.sleep(RETRY_DELAY_SEC)

        attempts = attempt
        logging.info(f"[watchdog] Running slot {slot} for {target_date} (attempt {attempt}/{MAX_ATTEMPTS})")
        start = datetime.now(timezone.utc)
        conn = None
        try:
            conn = get_connection()
            cursor = conn.cursor(as_dict=True)
            cursor.callproc('sp_Generate_Daily_Prices', (target_date, slot))
            conn.commit()
            cursor.close()
            duration = round((datetime.now(timezone.utc) - start).total_seconds())
            logging.info(f"[watchdog] Slot {slot} completed in {duration}s on attempt {attempt}")
            return {"slot": slot, "status": "ok", "attempts": attempts, "duration_sec": duration}
        except Exception as e:
            last_error = str(e)
            logging.error(f"[watchdog] Slot {slot} attempt {attempt} failed: {e}")
        finally:
            if conn:
                try:
                    conn.close()
                except Exception:
                    pass

    return {"slot": slot, "status": "error", "attempts": attempts, "error": last_error}


def main(req: func.HttpRequest) -> func.HttpResponse:
    start_ts = datetime.now(timezone.utc)
    deadline = start_ts + timedelta(seconds=TIME_BUDGET_SEC)
    logging.info(f"[watchdog] START {start_ts.isoformat()} (deadline {deadline.isoformat()})")

    try:
        body = req.get_json() if req.get_body() else {}
    except Exception:
        body = {}

    target_date = body.get('date') or datetime.now(timezone.utc).strftime('%Y-%m-%d')
    force_slot  = body.get('slot')

    results = {
        "target_date": target_date,
        "slots_run": [],
        "slots_skipped": [],
        "still_missing": [],
        "refresh": None,
        "errors": [],
    }

    try:
        if force_slot:
            if force_slot not in SLOTS:
                return func.HttpResponse(
                    json.dumps({"error": f"Invalid slot. Use one of: {SLOTS}"}),
                    status_code=400, mimetype="application/json"
                )
            result = run_slot(target_date, force_slot, deadline)
            results["slots_run"].append(result)
            if result["status"] == "error":
                results["errors"].append(result)
        else:
            # Determine what's missing (fresh connection, closed immediately).
            conn = get_connection()
            try:
                missing, existing = get_missing_slots(conn, target_date)
            finally:
                try: conn.close()
                except Exception: pass
            results["slots_skipped"] = list(existing)

            if not missing:
                results["message"] = f"All 3 slots already exist for {target_date} — nothing to do"
                logging.info(f"[watchdog] All slots present for {target_date}, skipping")
            else:
                logging.info(f"[watchdog] Missing slots for {target_date}: {missing}")
                for slot in missing:
                    result = run_slot(target_date, slot, deadline)
                    results["slots_run"].append(result)
                    if result["status"] == "error":
                        results["errors"].append(result)

        # Summary refresh is owned by the Elastic Job (RefreshLPS_0830/1430);
        # not run inline (usp_Refresh_LatestPrices ~8.5 min would exceed timeout).
        successful = [r for r in results["slots_run"] if r["status"] == "ok"]
        if successful:
            results["refresh"] = {"status": "skipped", "reason": "owned by Elastic Job RefreshLPS_0830/1430"}

        # Re-verify: did the slots actually land? (fresh connection)
        conn = get_connection()
        try:
            still_missing, _ = get_missing_slots(conn, target_date)
        finally:
            try: conn.close()
            except Exception: pass
        results["still_missing"] = still_missing
        if still_missing:
            logging.error(f"[watchdog] Still missing after run: {still_missing}")

    except Exception as e:
        logging.error(f"[watchdog] Fatal error: {e}")
        results["errors"].append({"fatal": str(e)})

    total_duration = round((datetime.now(timezone.utc) - start_ts).total_seconds())
    results["total_duration_sec"] = total_duration
    results["status"] = "error" if (results["errors"] or results["still_missing"]) else "ok"

    logging.info(f"[watchdog] END — {results['status']} in {total_duration}s")

    return func.HttpResponse(
        json.dumps(results, default=str),
        status_code=200 if results["status"] == "ok" else 500,
        mimetype="application/json"
    )
