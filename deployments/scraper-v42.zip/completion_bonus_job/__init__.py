import logging
import os
import pymssql
from datetime import datetime, timezone
import azure.functions as func

def get_connection():
    return pymssql.connect(
        server=os.environ["SQL_SERVER"],
        user=os.environ.get("SQL_USERNAME") or os.environ.get("SQL_USER", ""),
        password=os.environ["SQL_PASSWORD"],
        database=os.environ["SQL_DATABASE"],
        timeout=0,
        login_timeout=30
    )

# Bonus tiers — highest qualifying tier only (not cumulative)
# Ordered descending so first match = highest qualifying
BONUS_TIERS = [
    (15, 300.00, 'COMPLETION_BONUS_15'),
    (12, 200.00, 'COMPLETION_BONUS_12'),
    (10, 100.00, 'COMPLETION_BONUS_10'),
]

VALID_BASIS_VALUES = {'submitted', 'approved', 'approved_and_pending'}

def main(mytimer: func.TimerRequest) -> None:
    utc_now = datetime.now(timezone.utc)
    logging.info(f'[completion_bonus_job] Starting at {utc_now.isoformat()}')

    if mytimer.past_due:
        logging.warning('[completion_bonus_job] Timer is past due')

    conn = None
    try:
        conn = get_connection()
        cur = conn.cursor(as_dict=True)

        # Read count basis from Admin_Config
        cur.execute(
            "SELECT key_value FROM dbo.Admin_Config "
            "WHERE section = 'rewards' AND key_name = 'completion_bonus_count_basis'"
        )
        row = cur.fetchone()
        raw_basis = row['key_value'].strip().lower() if row else 'submitted'

        if raw_basis not in VALID_BASIS_VALUES:
            logging.warning(
                f'[completion_bonus_job] Unknown completion_bonus_count_basis '
                f'value "{raw_basis}" — defaulting to "submitted"'
            )
            count_basis = 'submitted'
        else:
            count_basis = raw_basis

        logging.info(f'[completion_bonus_job] count_basis={count_basis}')

        # Build status filter
        if count_basis == 'approved':
            status_filter = "validation_status = 'APPROVED'"
        elif count_basis == 'approved_and_pending':
            status_filter = "validation_status IN ('APPROVED', 'PENDING')"
        else:  # submitted (default pilot basis)
            status_filter = "validation_status IN ('APPROVED', 'PENDING')"

        # WAT = UTC+1. Target date = today in WAT.
        # submitted_at is NVARCHAR — must TRY_CAST to DATETIME2 before DATEADD
        count_query = f"""
            SELECT
                trader_phone,
                COUNT(*) AS submission_count
            FROM dbo.Submissions
            WHERE {status_filter}
              AND CAST(DATEADD(HOUR, 1,
                    TRY_CAST(submitted_at AS DATETIME2)) AS DATE)
                  = CAST(DATEADD(HOUR, 1, GETUTCDATE()) AS DATE)
              AND trader_id NOT LIKE 'SYN-%'
            GROUP BY trader_phone
            HAVING COUNT(*) >= 10
        """

        cur.execute(count_query)
        qualifying = cur.fetchall()
        logging.info(
            f'[completion_bonus_job] {len(qualifying)} reporters '
            f'with >= 10 submissions today'
        )

        bonuses_written = 0
        bonuses_skipped = 0
        errors = 0

        for reporter in qualifying:
            phone = reporter['trader_phone']
            count = reporter['submission_count']

            # Determine highest qualifying tier
            bonus_amount = 0.00
            bonus_type = None
            for threshold, amount, tx_type in BONUS_TIERS:
                if count >= threshold:
                    bonus_amount = amount
                    bonus_type = tx_type
                    break

            if not bonus_type:
                continue

            try:
                # Idempotency check: one COMPLETION_BONUS per reporter per day
                cur.execute(
                    """
                    SELECT COUNT(*) AS existing
                    FROM dbo.Rewards_Ledger
                    WHERE phone_number = %s
                      AND transaction_type LIKE 'COMPLETION_BONUS%%'
                      AND CAST(DATEADD(HOUR, 1,
                            TRY_CAST(CAST(timestamp AS NVARCHAR(50))
                                     AS DATETIME2)) AS DATE)
                          = CAST(DATEADD(HOUR, 1, GETUTCDATE()) AS DATE)
                    """,
                    (phone,)
                )
                exists = cur.fetchone()['existing']

                if exists > 0:
                    logging.info(
                        f'[completion_bonus_job] Skipping {phone} — '
                        f'bonus already written today'
                    )
                    bonuses_skipped += 1
                    continue

                # Write bonus row
                cur.execute(
                    """
                    INSERT INTO dbo.Rewards_Ledger
                        (transaction_id, timestamp, phone_number,
                         transaction_type, amount, net_amount,
                         status, user_type, description)
                    VALUES
                        (CONCAT('RL-', NEWID()), GETUTCDATE(), %s,
                         %s, %s, %s,
                         'PENDING', 'TRADER',
                         %s)
                    """,
                    (
                        phone,
                        bonus_type,
                        bonus_amount,
                        bonus_amount,
                        f'Daily completion bonus: {count} submissions ({count_basis} basis)'
                    )
                )
                conn.commit()
                bonuses_written += 1
                logging.info(
                    f'[completion_bonus_job] Wrote {bonus_type} ₦{bonus_amount} '
                    f'for {phone} ({count} submissions)'
                )

            except Exception as e:
                errors += 1
                logging.error(
                    f'[completion_bonus_job] Error writing bonus for {phone}: {e}'
                )
                try:
                    conn.rollback()
                except Exception:
                    pass

        logging.info(
            f'[completion_bonus_job] Done. '
            f'evaluated={len(qualifying)} written={bonuses_written} '
            f'skipped={bonuses_skipped} errors={errors}'
        )

    except Exception as e:
        logging.error(f'[completion_bonus_job] Fatal error: {e}')
        raise
    finally:
        if conn:
            try:
                conn.close()
            except Exception:
                pass
