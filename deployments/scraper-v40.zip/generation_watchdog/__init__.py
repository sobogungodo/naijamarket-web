"""
generation_watchdog — HTTP trigger
===================================
Called daily via Azure Scheduler / cron job / external ping.
Checks if today's generation slots exist in Daily_Prices.
Runs any missing slots via sp_Generate_Daily_Prices.
Also runs usp_Refresh_LatestPrices after any generation.

Endpoint: POST https://func-naijamarket-scraper.azurewebsites.net/api/generation_watchdog
Body: {} (empty) — runs all missing slots for today
Body: {"date": "2026-06-04"} — runs missing slots for specific date
Body: {"slot": "08:30"} — forces a specific slot regardless of existence
"""

import azure.functions as func
import logging
import json
import os
import sys
from datetime import datetime, timezone

sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))
from shared.db import get_connection

SLOTS = ['08:30', '11:30', '14:30']


def get_missing_slots(conn, target_date: str) -> list:
    """Returns list of slots not yet generated for target_date."""
    cursor = conn.cursor(as_dict=True)
    cursor.execute("""
        SELECT DISTINCT time_slot
        FROM dbo.Daily_Prices
        WHERE price_date = %s AND nbs_adjusted = 0
    """, (target_date,))
    existing = {row['time_slot'] for row in cursor.fetchall()}
    cursor.close()
    missing = [s for s in SLOTS if s not in existing]
    return missing, existing


def run_slot(conn, target_date: str, slot: str) -> dict:
    """Executes sp_Generate_Daily_Prices for one slot. Returns result."""
    logging.info(f"[watchdog] Running slot {slot} for {target_date}")
    start = datetime.now(timezone.utc)
    try:
        cursor = conn.cursor(as_dict=True)
        cursor.callproc('sp_Generate_Daily_Prices', (target_date, slot))
        conn.commit()
        cursor.close()
        duration = round((datetime.now(timezone.utc) - start).total_seconds())
        logging.info(f"[watchdog] Slot {slot} completed in {duration}s")
        return {"slot": slot, "status": "ok", "duration_sec": duration}
    except Exception as e:
        logging.error(f"[watchdog] Slot {slot} failed: {e}")
        return {"slot": slot, "status": "error", "error": str(e)}


def run_refresh(conn) -> dict:
    """Runs usp_Refresh_LatestPrices after generation."""
    logging.info("[watchdog] Running usp_Refresh_LatestPrices")
    start = datetime.now(timezone.utc)
    try:
        cursor = conn.cursor(as_dict=True)
        cursor.callproc('usp_Refresh_LatestPrices')
        conn.commit()
        cursor.close()
        duration = round((datetime.now(timezone.utc) - start).total_seconds())
        logging.info(f"[watchdog] Refresh completed in {duration}s")
        return {"status": "ok", "duration_sec": duration}
    except Exception as e:
        logging.error(f"[watchdog] Refresh failed: {e}")
        return {"status": "error", "error": str(e)}


def main(req: func.HttpRequest) -> func.HttpResponse:
    start_ts = datetime.now(timezone.utc)
    logging.info(f"[watchdog] START {start_ts.isoformat()}")

    try:
        body = req.get_json() if req.get_body() else {}
    except Exception:
        body = {}

    # Determine target date
    target_date = body.get('date') or datetime.now(timezone.utc).strftime('%Y-%m-%d')
    force_slot = body.get('slot')  # if set, run this slot regardless

    results = {
        "target_date": target_date,
        "slots_run": [],
        "slots_skipped": [],
        "refresh": None,
        "errors": [],
    }

    conn = None
    try:
        conn = get_connection()

        if force_slot:
            # Force a specific slot
            if force_slot not in SLOTS:
                return func.HttpResponse(
                    json.dumps({"error": f"Invalid slot. Use one of: {SLOTS}"}),
                    status_code=400,
                    mimetype="application/json"
                )
            result = run_slot(conn, target_date, force_slot)
            results["slots_run"].append(result)
            if result["status"] == "error":
                results["errors"].append(result)
        else:
            # Check what's missing and run only those
            missing, existing = get_missing_slots(conn, target_date)
            results["slots_skipped"] = list(existing)

            if not missing:
                results["message"] = f"All 3 slots already exist for {target_date} — nothing to do"
                logging.info(f"[watchdog] All slots present for {target_date}, skipping")
            else:
                logging.info(f"[watchdog] Missing slots for {target_date}: {missing}")
                for slot in missing:
                    result = run_slot(conn, target_date, slot)
                    results["slots_run"].append(result)
                    if result["status"] == "error":
                        results["errors"].append(result)

        # Summary refresh is owned by the Elastic Job (RefreshLPS_0830/1430);
        # not run inline (the ~8.5-min usp_Refresh_LatestPrices exceeds the
        # 10-min Consumption functionTimeout when combined with generation).
        successful = [r for r in results["slots_run"] if r["status"] == "ok"]
        if successful:
            results["refresh"] = {"status": "skipped", "reason": "owned by Elastic Job RefreshLPS_0830/1430"}

    except Exception as e:
        logging.error(f"[watchdog] Fatal error: {e}")
        results["errors"].append({"fatal": str(e)})
    finally:
        if conn:
            try:
                conn.close()
            except Exception:
                pass

    total_duration = round((datetime.now(timezone.utc) - start_ts).total_seconds())
    results["total_duration_sec"] = total_duration
    results["status"] = "error" if results["errors"] else "ok"

    logging.info(f"[watchdog] END — {results['status']} in {total_duration}s")

    return func.HttpResponse(
        json.dumps(results, default=str),
        status_code=200 if results["status"] == "ok" else 500,
        mimetype="application/json"
    )
