"""
nbs_food_scraper — NBS Selected Food Price Watch -> Verified_External_Prices

Source : https://microdata.nigerianstat.gov.ng/index.php/catalog/162
Format : monthly ZIP (PDF report + XLSX table), no login required.
Writes : source='NBS_FOOD', confidence=90
  - national average per item   (state = NULL)
  - highest-state extreme       (real state)
  - lowest-state extreme        (real state)
Coverage note: NBS does NOT publish a full 36-state x item matrix in this file;
only the national average plus the single highest/lowest state per item.

Schedule: 07:00 UTC on the 5th of each month (see function.json).
"""
import azure.functions as func
import logging, os, re, io, zipfile, datetime
import requests
import openpyxl

from shared.db import get_connection

CATALOG_URL = "https://microdata.nigerianstat.gov.ng/index.php/catalog/162"
DOWNLOAD_RE = re.compile(
    r'href="(https://microdata\.nigerianstat\.gov\.ng/index\.php/catalog/162/download/(\d+)/[^"]+\.zip)"',
    re.IGNORECASE,
)
UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) NaijaMarketScraper/1.0"
SOURCE = "NBS_FOOD"
CONFIDENCE = 90

# NBS item label (normalised) -> (item_id, item_name, unit)
# Normalisation = lower(), strip(), trailing commas/spaces removed.
ITEM_MAP = {
    "agric hen eggs": ("ITM01002", "Eggs - Agric Medium (1 pc)", "piece"),
    "agric hen eggs, (a crate of 30 pieces)": ("ITM01001", "Eggs - Agric Medium (Crate)", "crate"),
    "beans brown": ("ITM01003", "Beans - Brown (per kg)", "kg"),
    "beans white": ("ITM01004", "Beans - White Black Eye (per kg)", "kg"),
    "beef boneless": ("ITM01006", "Beef - Boneless (per kg)", "kg"),
    "bread (sliced), 450g": ("ITM01007", "Bread - Sliced 500g", "piece"),
    "bread (unsliced), 450g": ("ITM01008", "Bread - Unsliced 500g", "piece"),
    "cat fresh fish": ("ITM01010", "Catfish - Fresh Obokun (per kg)", "kg"),
    "chicken feet": ("ITM01013", "Chicken Feet (per kg)", "kg"),
    "chicken meat (frozen)": ("ITM01018", "Chicken - Frozen (per kg)", "kg"),
    "chicken wings": ("ITM01014", "Chicken Wings (per kg)", "kg"),
    "garri white": ("ITM01019", "Garri - White (per kg)", "kg"),
    "garri yellow": ("ITM01020", "Garri - Yellow (per kg)", "kg"),
    "groundnut oil, 75cl": ("ITM01021", "Groundnut Oil - 1 Litre Bottle", "75cl"),
    "irish potatoe": ("ITM01023", "Irish Potato (per kg)", "kg"),
    "local rice (broken)": ("ITM01009", "Rice - Ofada/Broken (per kg)", "kg"),
    "mackerel, frozen": ("ITM01024", "Mackerel - Frozen (per kg)", "kg"),
    "maize (corn) grains (white) sold loose": ("ITM01025", "Maize - White (per kg)", "kg"),
    "onions, fresh": ("ITM01029", "Onions - Bulb (per kg)", "kg"),
    "palm oil, 75cl": ("ITM01030", "Palm Oil - 1 Litre Bottle", "75cl"),
    "plantain (ripe)": ("ITM01031", "Plantain - Ripe (per kg)", "kg"),
    "plantain (unripe)": ("ITM01032", "Plantain - Unripe (per kg)", "kg"),
    "rice local, short-grained": ("ITM01034", "Rice - Agric/Local (per kg)", "kg"),
    "rice long-grained (imported)": ("ITM01036", "Rice - Imported Premium (per kg)", "kg"),
    "sweet potatoes": ("ITM01037", "Sweet Potato (per kg)", "kg"),
    "tilapia fresh fish (epiya)": ("ITM01038", "Tilapia - Fresh (per kg)", "kg"),
    "tin milk-evaporated, peak milk, 150g": ("ITM01017", "Evaporated Milk - Peak 170g", "tin"),
    "titus, frozen": ("ITM01039", "Titus/Mackerel - Frozen (per kg)", "kg"),
    "tomatoes, fresh": ("ITM01040", "Tomatoes - Fresh (per kg)", "kg"),
    "vegetable oil, 75cl": ("ITM01041", "Vegetable Oil - 1 Litre Bottle", "75cl"),
    "wheat flour, prepacked (2kg)": ("ITM01042", "Wheat Flour - Golden Penny 2kg", "pack"),
    "yam tuber": ("ITM01043", "Yam Tuber (per kg)", "kg"),
}

MONTHS = {
    "jan": 1, "january": 1, "feb": 2, "february": 2, "mar": 3, "march": 3,
    "apr": 4, "april": 4, "may": 5, "jun": 6, "june": 6, "jul": 7, "july": 7,
    "aug": 8, "august": 8, "sep": 9, "sept": 9, "september": 9, "oct": 10,
    "october": 10, "nov": 11, "november": 11, "dec": 12, "december": 12,
}

# Valid Nigerian states + FCT (for extreme-state validation)
STATES = {
    "abia", "adamawa", "akwa ibom", "anambra", "bauchi", "bayelsa", "benue",
    "borno", "cross river", "delta", "ebonyi", "edo", "ekiti", "enugu",
    "gombe", "imo", "jigawa", "kaduna", "kano", "katsina", "kebbi", "kogi",
    "kwara", "lagos", "nasarawa", "niger", "ogun", "ondo", "osun", "oyo",
    "plateau", "rivers", "sokoto", "taraba", "yobe", "zamfara", "fct", "abuja",
}


def _norm(label):
    if label is None:
        return ""
    s = str(label).strip().lower()
    s = re.sub(r"[,\s]+$", "", s)        # drop trailing comma/space
    s = re.sub(r"\s+", " ", s)           # collapse internal whitespace
    return s


def fetch_latest_zip_url(session):
    r = session.get(CATALOG_URL, timeout=60)
    r.raise_for_status()
    matches = DOWNLOAD_RE.findall(r.text)
    if not matches:
        raise RuntimeError("No .zip download links found on NBS catalog 162")
    # download id increases monotonically with publication date -> max = latest
    url, _id = max(matches, key=lambda m: int(m[1]))
    logging.info("[nbs_food] latest zip id=%s url=%s", _id, url)
    return url


def download_xlsx_bytes(session, zip_url):
    r = session.get(zip_url, timeout=120)
    r.raise_for_status()
    zf = zipfile.ZipFile(io.BytesIO(r.content))
    xlsx_names = [n for n in zf.namelist() if n.lower().endswith(".xlsx")]
    if not xlsx_names:
        raise RuntimeError("No .xlsx inside NBS zip: %s" % zf.namelist())
    name = xlsx_names[0]
    logging.info("[nbs_food] extracting %s", name)
    return name, zf.read(name)


def _price_date_from(name, sheet_title):
    """Infer report month -> first-of-month date from sheet title or filename."""
    for text in (sheet_title or "", name or ""):
        t = text.lower()
        ym = re.search(r"(20\d{2})", t)
        year = int(ym.group(1)) if ym else None
        for token, mon in MONTHS.items():
            if re.search(r"\b" + token + r"\b", t):
                if year is None:
                    yy = re.search(r"(\d{2})(?!.*\d)", t)
                    year = 2000 + int(yy.group(1)) if yy else datetime.date.today().year
                return datetime.date(year, mon, 1)
    # fallback: previous month
    today = datetime.date.today().replace(day=1)
    prev = today - datetime.timedelta(days=1)
    return prev.replace(day=1)


def _find_col(ws, predicate):
    for c in range(1, ws.max_column + 1):
        if predicate(ws.cell(1, c).value):
            return c
    return None


def parse_workbook(xlsx_name, xlsx_bytes):
    wb = openpyxl.load_workbook(io.BytesIO(xlsx_bytes), data_only=True)
    ws = wb.worksheets[0]  # sheet 1 = "Selected Food <Month>"
    price_date = _price_date_from(xlsx_name, ws.title)

    # locate columns by header (robust to layout shifts)
    avg_cols = [c for c in range(1, ws.max_column + 1)
                if str(ws.cell(1, c).value or "").lower().startswith("average of")]
    cur_col = avg_cols[-1] if avg_cols else 4          # current-month average = last "Average of"
    hi_col = _find_col(ws, lambda v: str(v or "").strip().lower() == "highest")
    lo_col = _find_col(ws, lambda v: str(v or "").strip().lower() == "lowest")

    rows = []
    skipped = []
    extreme_re = re.compile(r"^(.*?)\s*\(([\d.,]+)\)\s*$")

    for r in range(2, ws.max_row + 1):
        label = ws.cell(r, 1).value
        key = _norm(label)
        if not key:
            continue
        mapped = ITEM_MAP.get(key)
        if not mapped:
            skipped.append(str(label).strip())
            continue
        item_id, item_name, unit = mapped

        # national average (state = NULL)
        nat = ws.cell(r, cur_col).value
        if isinstance(nat, (int, float)) and nat > 0:
            rows.append((item_id, item_name, None, round(float(nat), 2), unit))

        # highest / lowest extremes (real states)
        for col in (hi_col, lo_col):
            if not col:
                continue
            cell = ws.cell(r, col).value
            if not cell:
                continue
            m = extreme_re.match(str(cell))
            if not m:
                continue
            state = m.group(1).strip()
            if state.lower() not in STATES:
                continue
            try:
                val = float(m.group(2).replace(",", ""))
            except ValueError:
                continue
            if val > 0:
                rows.append((item_id, item_name, state, round(val, 2), unit))

    logging.info("[nbs_food] parsed %d rows, %d items skipped (unmapped): %s",
                 len(rows), len(skipped), ", ".join(sorted(set(skipped))) or "none")
    return price_date, rows


def upsert(price_date, rows):
    if not rows:
        logging.warning("[nbs_food] no rows to write")
        return 0
    conn = get_connection()
    try:
        cur = conn.cursor()
        # Append-only idempotency (naijaapp has INSERT/SELECT, no DELETE/UPDATE):
        # insert each row only if (source, price_date, item_id, state) not already present.
        cur.executemany(
            "INSERT INTO dbo.Verified_External_Prices "
            "(source, price_date, item_id, item_name, state, price_naira, unit, confidence, created_at) "
            "SELECT %s, %s, %s, %s, %s, %s, %s, %s, SYSUTCDATETIME() "
            "WHERE NOT EXISTS (SELECT 1 FROM dbo.Verified_External_Prices "
            "  WHERE source=%s AND price_date=%s AND item_id=%s "
            "    AND ISNULL(state,'') = ISNULL(%s,''))",
            [(SOURCE, price_date, r[0], r[1], r[2], r[3], r[4], CONFIDENCE,
              SOURCE, price_date, r[0], r[2]) for r in rows],
        )
        conn.commit()
        logging.info("[nbs_food] inserted up to %d rows for %s (skipping existing)", len(rows), price_date)
        return len(rows)
    finally:
        conn.close()


def run():
    session = requests.Session()
    session.headers.update({"User-Agent": UA, "Referer": CATALOG_URL})
    zip_url = fetch_latest_zip_url(session)
    xlsx_name, xlsx_bytes = download_xlsx_bytes(session, zip_url)
    price_date, rows = parse_workbook(xlsx_name, xlsx_bytes)
    return upsert(price_date, rows)


def main(myTimer: func.TimerRequest) -> None:
    logging.info("[nbs_food_scraper] tick")
    try:
        n = run()
        logging.info("[nbs_food_scraper] done, %d rows", n)
    except Exception:
        logging.exception("[nbs_food_scraper] FAILED")
        raise
