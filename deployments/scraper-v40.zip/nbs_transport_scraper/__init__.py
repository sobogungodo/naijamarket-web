"""
nbs_transport_scraper — NBS Transport Fare Watch -> Transport_Fares_Passenger

Source : https://microdata.nigerianstat.gov.ng/index.php/catalog/161
Format : monthly ZIP (PDF report + XLSX table), no login required.
Writes : source='NBS_TRANSPORT', confidence=90
  Sheet "State Transport": 36 states + FCT(Abuja) + Grand Total(=National),
  5 passenger modes each -> up to 190 rows/month.

Modes (fixed column layout of the "State Transport" sheet):
  col B -> AIR            (Air fare, single journey)
  col C -> INTERCITY_BUS  (Bus journey intercity, state route, per person)
  col D -> CITY_BUS       (Bus journey within city, per drop)
  col E -> OKADA          (Journey by motorcycle, per drop)
  col F -> WATER          (Water transport: waterway passenger)

Schedule: 08:00 UTC on the 6th of each month (see function.json),
the day after nbs_food_scraper.
"""
import azure.functions as func
import logging, io, zipfile, datetime, re
import requests
import openpyxl

from shared.db import get_connection

CATALOG_URL = "https://microdata.nigerianstat.gov.ng/index.php/catalog/161"
# Latest known publication = id 1414 (April 2026). We discover the newest id
# dynamically from the catalog page; FALLBACK_ID is used if discovery fails.
FALLBACK_ID = 1414
DOWNLOAD_RE = re.compile(
    r'href="(https://microdata\.nigerianstat\.gov\.ng/index\.php/catalog/161/download/(\d+)/[^"]+\.(?:zip|xlsx))"',
    re.IGNORECASE,
)
UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) NaijaMarketScraper/1.0"
SHEET_NAME = "State Transport"
SOURCE = "NBS_TRANSPORT"
CONFIDENCE = 90

# 1-based column index in the "State Transport" sheet -> transport_type
COL_MODE = {
    2: "AIR",
    3: "INTERCITY_BUS",
    4: "CITY_BUS",
    5: "OKADA",
    6: "WATER",
}

MONTHS = {
    "jan": 1, "january": 1, "feb": 2, "february": 2, "mar": 3, "march": 3,
    "apr": 4, "april": 4, "may": 5, "jun": 6, "june": 6, "jul": 7, "july": 7,
    "aug": 8, "august": 8, "sep": 9, "sept": 9, "september": 9, "oct": 10,
    "october": 10, "nov": 11, "november": 11, "dec": 12, "december": 12,
}


def fetch_latest_download_url(session):
    """Discover newest catalog-161 download (max id). Fallback to FALLBACK_ID."""
    try:
        r = session.get(CATALOG_URL, timeout=60)
        r.raise_for_status()
        matches = DOWNLOAD_RE.findall(r.text)
        if matches:
            url, _id = max(matches, key=lambda m: int(m[1]))
            logging.info("[nbs_transport] latest download id=%s url=%s", _id, url)
            return url
        logging.warning("[nbs_transport] no download links parsed; using fallback id")
    except Exception:
        logging.exception("[nbs_transport] discovery failed; using fallback id")
    return "%s/download/%d" % (CATALOG_URL, FALLBACK_ID)


def download_xlsx_bytes(session, url):
    r = session.get(url, timeout=120)
    r.raise_for_status()
    # The download is a ZIP (PDF + XLSX) for recent months; older months are a
    # bare .xlsx. Handle both.
    content = r.content
    if content[:2] == b"PK" and b"[Content_Types].xml" in content[:4000]:
        # looks like a bare .xlsx (also a zip, but contains the xlsx parts)
        try:
            zipfile.ZipFile(io.BytesIO(content)).getinfo("[Content_Types].xml")
            return "download.xlsx", content
        except KeyError:
            pass
    zf = zipfile.ZipFile(io.BytesIO(content))
    xlsx_names = [n for n in zf.namelist() if n.lower().endswith(".xlsx")]
    if not xlsx_names:
        raise RuntimeError("No .xlsx inside NBS transport zip: %s" % zf.namelist())
    name = xlsx_names[0]
    logging.info("[nbs_transport] extracting %s", name)
    return name, zf.read(name)


def _price_date_from(name, sheet_title):
    """Infer report month -> first-of-month date from sheet title or filename."""
    for text in (sheet_title or "", name or ""):
        # normalise separators ('_', '-', '.') to spaces so \bword\b matches
        # tokens like 'APR_2026' (underscore is a regex word char otherwise).
        t = re.sub(r"[^a-z0-9]+", " ", text.lower())
        ym = re.search(r"(20\d{2})", t)
        year = int(ym.group(1)) if ym else None
        for token, mon in MONTHS.items():
            if re.search(r"\b" + token + r"\b", t):
                if year is None:
                    yy = re.search(r"(\d{2})(?!.*\d)", t)
                    year = 2000 + int(yy.group(1)) if yy else datetime.date.today().year
                return datetime.date(year, mon, 1)
    today = datetime.date.today().replace(day=1)
    prev = today - datetime.timedelta(days=1)
    return prev.replace(day=1)


def _clean_state(raw):
    """Normalise the state label. 'Grand Total' -> 'National'; else Title Case."""
    s = str(raw).strip()
    if s.lower() == "grand total":
        return "National"
    return s.title()


def parse_workbook(xlsx_name, xlsx_bytes):
    wb = openpyxl.load_workbook(io.BytesIO(xlsx_bytes), data_only=True)
    if SHEET_NAME in wb.sheetnames:
        ws = wb[SHEET_NAME]
    else:  # fallback: pick the sheet whose first header cell is 'State'
        ws = next((s for s in wb.worksheets
                   if str(s.cell(1, 1).value or "").strip().lower() == "state"),
                  wb.worksheets[-1])
        logging.warning("[nbs_transport] '%s' not found; using sheet '%s'", SHEET_NAME, ws.title)

    # The "State Transport" sheet title carries no month; the month lives in the
    # other sheet name ("Transport April 2026") and the filename. Scan all of them.
    title_hint = " ".join(wb.sheetnames)
    price_date = _price_date_from(xlsx_name, title_hint)

    rows = []
    seen_national = False
    for r in range(2, ws.max_row + 1):
        a = ws.cell(r, 1).value
        if a is None or not str(a).strip():
            continue
        state = _clean_state(a)
        if state == "National":
            if seen_national:        # store the Grand Total row only once
                continue
            seen_national = True
        for col, ttype in COL_MODE.items():
            val = ws.cell(r, col).value
            if isinstance(val, (int, float)) and val > 0:
                rows.append((state, ttype, round(float(val), 2)))

    logging.info("[nbs_transport] parsed %d rows for %s (national row included=%s)",
                 len(rows), price_date, seen_national)
    return price_date, rows


def upsert(price_date, rows):
    if not rows:
        logging.warning("[nbs_transport] no rows to write")
        return 0, 0
    conn = get_connection()
    try:
        cur = conn.cursor()
        # Idempotent insert (naijaapp has INSERT/SELECT, no DELETE/UPDATE):
        # insert each row only if (transport_type, state, price_date) not present.
        before = _count(cur, price_date)
        cur.executemany(
            "INSERT INTO dbo.Transport_Fares_Passenger "
            "(state, transport_type, fare_naira, price_date, source, confidence) "
            "SELECT %s, %s, %s, %s, %s, %s "
            "WHERE NOT EXISTS (SELECT 1 FROM dbo.Transport_Fares_Passenger "
            "  WHERE transport_type=%s AND state=%s AND price_date=%s)",
            [(r[0], r[1], r[2], price_date, SOURCE, CONFIDENCE,
              r[1], r[0], price_date) for r in rows],
        )
        conn.commit()
        after = _count(cur, price_date)
        inserted = after - before
        skipped = len(rows) - inserted
        logging.info("[nbs_transport] inserted %d new, skipped %d existing (of %d parsed) for %s",
                     inserted, skipped, len(rows), price_date)
        return inserted, skipped
    finally:
        conn.close()


def _count(cur, price_date):
    cur.execute(
        "SELECT COUNT(*) FROM dbo.Transport_Fares_Passenger WHERE source=%s AND price_date=%s",
        (SOURCE, price_date),
    )
    return cur.fetchone()[0]


def run():
    session = requests.Session()
    session.headers.update({"User-Agent": UA, "Referer": CATALOG_URL})
    url = fetch_latest_download_url(session)
    xlsx_name, xlsx_bytes = download_xlsx_bytes(session, url)
    price_date, rows = parse_workbook(xlsx_name, xlsx_bytes)
    inserted, skipped = upsert(price_date, rows)
    return inserted


def main(myTimer: func.TimerRequest) -> None:
    logging.info("[nbs_transport_scraper] tick")
    try:
        n = run()
        logging.info("[nbs_transport_scraper] done, %d rows inserted", n)
    except Exception:
        logging.exception("[nbs_transport_scraper] FAILED")
        raise
