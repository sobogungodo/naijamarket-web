"""
weekly_brief — Monday market brief email via Brevo campaign
Scraper timer function. Fires Monday 06:00 UTC (07:00 WAT).

Flow:
  1. Idempotency check — has this ISO week already been sent? (Brief_Send_Log)
  2. Pull biggest weekly movers + monthly trend from Latest_Prices_Summary
  3. Build branded HTML
  4. Create Brevo campaign targeting list 2, send now
  5. Log result to Brief_Send_Log

Privacy/compliance: sends via Brevo CAMPAIGN API (not transactional) so
unsubscribes + suppression are honoured automatically. List 2 = opt-in
waitlist + newsletter signups.

Env vars required (already set on func-naijamarket-scraper):
  BREVO_API_KEY, SENDER_EMAIL  (sender name hardcoded)
SQL connection uses the shared scraper db helper.
"""
import logging
import os
import datetime
import json
import urllib.request
import urllib.error

import azure.functions as func
import pymssql

BREVO_API   = "https://api.brevo.com/v3"
BREVO_LIST  = 2
SENDER_NAME = "NaijaMarket Intel"
SENDER_EMAIL = os.environ.get("SENDER_EMAIL", "noreply@naijamarketintel.ng")

# ── SQL connection (matches scraper pattern) ───────────────────────────────
def _conn():
    return pymssql.connect(
        server=os.environ["SQL_SERVER"],
        user=os.environ.get("SQL_USERNAME") or os.environ.get("SQL_USER", ""),
        password=os.environ["SQL_PASSWORD"],
        database=os.environ.get("SQL_DATABASE", "naijafoodmarket-live"),
        timeout=30,
        login_timeout=30,
    )

def _iso_week_monday(d: datetime.date) -> datetime.date:
    return d - datetime.timedelta(days=d.weekday())

# ── Brevo helpers ──────────────────────────────────────────────────────────
def _brevo_post(path: str, payload: dict) -> dict:
    key = os.environ["BREVO_API_KEY"]
    req = urllib.request.Request(
        f"{BREVO_API}{path}",
        data=json.dumps(payload).encode(),
        headers={"api-key": key, "Content-Type": "application/json", "Accept": "application/json"},
        method="POST",
    )
    with urllib.request.urlopen(req, timeout=30) as r:
        body = r.read().decode()
        return json.loads(body) if body else {}

def _brevo_post_noresp(path: str) -> int:
    key = os.environ["BREVO_API_KEY"]
    req = urllib.request.Request(
        f"{BREVO_API}{path}",
        data=b"",
        headers={"api-key": key, "Content-Type": "application/json"},
        method="POST",
    )
    with urllib.request.urlopen(req, timeout=30) as r:
        return r.status

def _list_recipient_count() -> int:
    key = os.environ["BREVO_API_KEY"]
    req = urllib.request.Request(
        f"{BREVO_API}/contacts/lists/{BREVO_LIST}",
        headers={"api-key": key, "Accept": "application/json"},
        method="GET",
    )
    try:
        with urllib.request.urlopen(req, timeout=30) as r:
            data = json.loads(r.read().decode())
            return int(data.get("totalSubscribers", 0))
    except Exception as e:
        logging.warning(f"[brief] list count failed: {e}")
        return 0

# ── Data ────────────────────────────────────────────────────────────────────
def _fetch_movers(cur):
    # Biggest weekly swings (week_high vs week_low spread), food only, non-NBS
    cur.execute("""
        SELECT TOP 6
            item_name,
            AVG(price_naira)       AS price,
            AVG(week_high)         AS wk_high,
            AVG(week_low)          AS wk_low,
            AVG(month_change_pct)  AS mo_change
        FROM dbo.Latest_Prices_Summary
        WHERE is_nbs_ref = 0 AND is_food = 1
          AND week_high IS NOT NULL AND week_low IS NOT NULL
          AND week_high <> week_low
          AND price_naira > 0
        GROUP BY item_name
        ORDER BY (AVG(week_high) - AVG(week_low)) / NULLIF(AVG(week_low),0) DESC
    """)
    cols = [c[0] for c in cur.description]
    return [dict(zip(cols, row)) for row in cur.fetchall()]

def _fetch_trend(cur):
    # Clearest monthly movers (up and down) for the "trend" section
    cur.execute("""
        SELECT TOP 5
            item_name,
            AVG(price_naira)      AS price,
            AVG(month_change_pct) AS mo_change
        FROM dbo.Latest_Prices_Summary
        WHERE is_nbs_ref = 0 AND is_food = 1
          AND month_change_pct IS NOT NULL
          AND ABS(month_change_pct) > 1
          AND price_naira > 0
        GROUP BY item_name
        ORDER BY ABS(AVG(month_change_pct)) DESC
    """)
    cols = [c[0] for c in cur.description]
    return [dict(zip(cols, row)) for row in cur.fetchall()]

def _fetch_coverage(cur):
    cur.execute("""
        SELECT COUNT(DISTINCT market_id) AS markets,
               COUNT(DISTINCT item_name)  AS items,
               MAX(price_date)            AS as_of
        FROM dbo.Latest_Prices_Summary
        WHERE is_food = 1
    """)
    row = cur.fetchone()
    return {"markets": row[0], "items": row[1], "as_of": row[2]}

# ── HTML ──────────────────────────────────────────────────────────────────
def _naira(v):
    try:
        return f"₦{float(v):,.0f}"
    except Exception:
        return "—"

def _pct(v):
    try:
        f = float(v)
        arrow = "▲" if f > 0 else ("▼" if f < 0 else "■")
        color = "#ff5252" if f > 0 else ("#00c563" if f < 0 else "#888")
        return f'<span style="color:{color}">{arrow} {abs(f):.1f}%</span>'
    except Exception:
        return "—"

def _build_html(movers, trend, cov):
    week_lbl = datetime.date.today().strftime("%d %B %Y").lstrip("0")
    as_of = cov["as_of"].strftime("%d %b %Y") if cov.get("as_of") else "this week"

    mover_rows = ""
    for m in movers:
        spread = float(m["wk_high"] or 0) - float(m["wk_low"] or 0)
        spread_pct = (spread / float(m["wk_low"])) * 100 if m["wk_low"] else 0
        mover_rows += f"""
        <tr>
          <td style="padding:12px 0;border-bottom:1px solid #1e1e1e;color:#fff;font-size:14px;">{m['item_name']}</td>
          <td style="padding:12px 0;border-bottom:1px solid #1e1e1e;color:#ccc;font-size:14px;text-align:right;">{_naira(m['price'])}</td>
          <td style="padding:12px 0;border-bottom:1px solid #1e1e1e;color:#888;font-size:13px;text-align:right;">{_naira(m['wk_low'])}–{_naira(m['wk_high'])}</td>
          <td style="padding:12px 0;border-bottom:1px solid #1e1e1e;font-size:13px;text-align:right;">{_pct(m['mo_change'])}</td>
        </tr>"""

    trend_rows = ""
    for t in trend:
        trend_rows += f"""
        <tr>
          <td style="padding:10px 0;border-bottom:1px solid #1e1e1e;color:#fff;font-size:14px;">{t['item_name']}</td>
          <td style="padding:10px 0;border-bottom:1px solid #1e1e1e;color:#ccc;font-size:14px;text-align:right;">{_naira(t['price'])}</td>
          <td style="padding:10px 0;border-bottom:1px solid #1e1e1e;font-size:14px;text-align:right;">{_pct(t['mo_change'])}</td>
        </tr>"""

    return f"""<!DOCTYPE html>
<html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1.0"></head>
<body style="margin:0;padding:0;background:#0a0a0a;font-family:Arial,sans-serif;">
<table width="100%" cellpadding="0" cellspacing="0" style="background:#0a0a0a;padding:32px 16px;">
 <tr><td align="center">
  <table width="600" cellpadding="0" cellspacing="0" style="background:#111;border:1px solid #222;border-radius:12px;overflow:hidden;max-width:600px;">
   <tr><td style="background:linear-gradient(135deg,#00a651,#006428);padding:26px 32px;">
     <h1 style="margin:0;color:#fff;font-size:20px;font-weight:700;letter-spacing:1px;">NAIJAMARKET INTEL</h1>
     <p style="margin:6px 0 0;color:rgba(255,255,255,0.85);font-size:12px;letter-spacing:1px;">WEEKLY MARKET BRIEF · {week_lbl}</p>
   </td></tr>
   <tr><td style="padding:28px 32px;">
     <p style="color:#aaa;font-size:14px;line-height:1.6;margin:0 0 8px;">
       Verified food prices across <strong style="color:#00a651;">{cov['markets']} markets</strong> · {cov['items']} commodities · as of {as_of}.
     </p>

     <h2 style="color:#fff;font-size:16px;margin:28px 0 4px;">🔥 Biggest Weekly Swings</h2>
     <p style="color:#666;font-size:12px;margin:0 0 12px;">Items with the widest price range across markets this week — where it pays to compare before you buy.</p>
     <table width="100%" cellpadding="0" cellspacing="0">
       <tr>
         <td style="color:#666;font-size:11px;text-transform:uppercase;padding-bottom:6px;">Item</td>
         <td style="color:#666;font-size:11px;text-transform:uppercase;padding-bottom:6px;text-align:right;">Avg</td>
         <td style="color:#666;font-size:11px;text-transform:uppercase;padding-bottom:6px;text-align:right;">Week Range</td>
         <td style="color:#666;font-size:11px;text-transform:uppercase;padding-bottom:6px;text-align:right;">vs Month</td>
       </tr>
       {mover_rows}
     </table>

     <h2 style="color:#fff;font-size:16px;margin:32px 0 4px;">📈 Month-on-Month Trend</h2>
     <p style="color:#666;font-size:12px;margin:0 0 12px;">Biggest movers vs last month's average.</p>
     <table width="100%" cellpadding="0" cellspacing="0">
       <tr>
         <td style="color:#666;font-size:11px;text-transform:uppercase;padding-bottom:6px;">Item</td>
         <td style="color:#666;font-size:11px;text-transform:uppercase;padding-bottom:6px;text-align:right;">Price</td>
         <td style="color:#666;font-size:11px;text-transform:uppercase;padding-bottom:6px;text-align:right;">vs Month</td>
       </tr>
       {trend_rows}
     </table>

     <table cellpadding="0" cellspacing="0" style="margin:32px 0 8px;">
       <tr><td style="background:#00a651;border-radius:6px;">
         <a href="https://www.naijamarketintel.com" style="display:inline-block;padding:13px 26px;color:#fff;font-size:14px;font-weight:700;text-decoration:none;">See All Live Prices →</a>
       </td></tr>
     </table>
     <p style="color:#777;font-size:13px;margin:16px 0 0;line-height:1.6;">
       💬 Check any price instantly on WhatsApp — reply <strong style="color:#00a651;">RICE LAGOS</strong> style queries anytime.
     </p>
   </td></tr>
   <tr><td style="padding:18px 32px;border-top:1px solid #1e1e1e;">
     <p style="color:#444;font-size:11px;margin:0;line-height:1.6;">
       You signed up at naijamarketintel.com · {{{{ unsubscribe }}}}<br>
       Giggababytes Oy · Jyrkankatu 1C 24, 15500 Lahti, Finland
     </p>
   </td></tr>
  </table>
 </td></tr>
</table>
</body></html>"""

# ── Main ────────────────────────────────────────────────────────────────────
def main(mytimer: func.TimerRequest) -> None:
    today = datetime.date.today()
    week_start = _iso_week_monday(today)
    logging.info(f"[brief] weekly brief run — week_start={week_start}")

    conn = None
    try:
        conn = _conn()
        cur = conn.cursor()

        # Idempotency — already sent this week?
        cur.execute("SELECT status FROM dbo.Brief_Send_Log WHERE week_start=%s", (week_start,))
        existing = cur.fetchone()
        if existing and existing[0] == 'SENT':
            logging.info(f"[brief] already SENT for week {week_start} — skipping")
            return

        # Claim the week (insert PENDING, or reuse FAILED row)
        if not existing:
            cur.execute(
                "INSERT INTO dbo.Brief_Send_Log (week_start, status) VALUES (%s, 'PENDING')",
                (week_start,)
            )
            conn.commit()

        movers = _fetch_movers(cur)
        trend  = _fetch_trend(cur)
        cov    = _fetch_coverage(cur)

        if not movers:
            logging.warning("[brief] no movers data — aborting, will retry next run")
            cur.execute(
                "UPDATE dbo.Brief_Send_Log SET status='FAILED', error_message=%s WHERE week_start=%s",
                ("no movers data", week_start)
            )
            conn.commit()
            return

        html = _build_html(movers, trend, cov)
        recipients = _list_recipient_count()

        # Create Brevo campaign
        week_lbl = today.strftime("%d %b %Y").lstrip("0")
        campaign = _brevo_post("/emailCampaigns", {
            "name": f"Weekly Market Brief — {week_lbl}",
            "subject": f"📊 Your NaijaMarket Weekly Brief — {week_lbl}",
            "sender": {"name": SENDER_NAME, "email": SENDER_EMAIL},
            "type": "classic",
            "htmlContent": html,
            "recipients": {"listIds": [BREVO_LIST]},
        })
        campaign_id = campaign.get("id")
        if not campaign_id:
            raise RuntimeError(f"campaign create returned no id: {campaign}")

        # Send now
        _brevo_post_noresp(f"/emailCampaigns/{campaign_id}/sendNow")

        cur.execute(
            "UPDATE dbo.Brief_Send_Log SET status='SENT', campaign_id=%s, recipients=%s, sent_at=SYSUTCDATETIME() WHERE week_start=%s",
            (campaign_id, recipients, week_start)
        )
        conn.commit()
        logging.info(f"[brief] SENT campaign {campaign_id} to ~{recipients} recipients")

    except Exception as e:
        logging.error(f"[brief] fatal: {e}", exc_info=True)
        try:
            if conn:
                c2 = conn.cursor()
                c2.execute(
                    "UPDATE dbo.Brief_Send_Log SET status='FAILED', error_message=%s WHERE week_start=%s",
                    (str(e)[:500], week_start)
                )
                conn.commit()
        except Exception:
            pass
    finally:
        if conn:
            conn.close()
