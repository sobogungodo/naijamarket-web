"""
worldbank_rtfp_scraper
======================
Monthly ingest of World Bank "Real Time Food Prices" (RTFP) market-level
estimates for Nigeria into dbo.Verified_External_Prices.

Source : World Bank Microdata catalog 4503 (NGA_2021_RTFP_v02_M)
         Open NADA data-API (data_access_type = open / public use):
         /index.php/api/tables/data/fcv/wld_2021_rtfp_v02_m
         No login / API key required.

Scope (v1 — confirmed):
  source      = 'WB_RTFP'
  confidence  = 75 (flat)
  markets     = 7 mapped physical markets only (aggregate / zone rows skipped)
  commodities = 8 mapped commodities only
  dedup key   = (source, price_date, item_id, market_id)

UNIT NORMALISATION (critical):
  RTFP commodity columns are priced PER BUNDLE, and the bundle size is NOT
  uniform. The real bundle is read PER ROW from the `components` string and
  the price is normalised to the catalog item's unit. We never hard-code a
  bundle blindly: the parsed value is the source of truth, with an expected
  value used only as a sanity check / fallback. A plausibility band then
  guards against ever writing a per-bundle price as a per-kg price.
"""

import os
import re
import logging
from datetime import datetime, date

import requests
import pymssql
import azure.functions as func

API_URL = "https://microdata.worldbank.org/index.php/api/tables/data/fcv/wld_2021_rtfp_v02_m"
SOURCE = "WB_RTFP"
CONFIDENCE = 75
PAGE_LIMIT = 5000

# WB mkt_name -> (market_id, market_name, state, expected_wb_adm1)
# Keyed on mkt_name, which is unique among the 7 within the NGA dataset.
# expected_wb_adm1 is validated to avoid mis-mapping an aggregate row that
# happens to reuse a city name.
MARKET_MAP = {
    "Aba":     ("MKT0155", "Aba Main Market",         "Abia",  "Abia"),
    "Custom":  ("MKT0200", "Custom Market Maiduguri", "Borno", "Borno"),
    "Monday":  ("MKT0199", "Maiduguri Monday Market", "Borno", "Borno"),
    "Dawanau": ("MKT0189", "Dawanau Market",          "Kano",  "Kano"),
    "Kano":    ("MKT0188", "Sabon Gari Market Kano",  "Kano",  "Kano State (1)"),
    "Lagos":   ("MKT0001", "Mile 12 Market",          "Lagos", "Lagos"),
    "Ibadan":  ("MKT0040", "Bodija Market",           "Oyo",   "Oyo"),
}

# WB column -> commodity config.
#   item_id, item_name, unit  : target Items_Catalog row
#   kind                       : 'kg'      -> normalise to price per 1 kg
#                                'crate30' -> normalise to price per 30-pc crate
#   expected_bundle            : sanity-check value parsed from `components`
#   lo, hi                     : plausibility band for the NORMALISED price (NGN)
# Prefer the FAO columns (rice_fao/gari_fao/maize_fao) — already 1 Kg.
COMMODITY_MAP = {
    "rice_fao":  dict(item_id="ITM01034", item_name="Rice - Agric/Local (per kg)",  unit="kg",    kind="kg",      expected_bundle=1.0,  lo=300,  hi=6000),
    "gari_fao":  dict(item_id="ITM01019", item_name="Garri - White (per kg)",       unit="kg",    kind="kg",      expected_bundle=1.0,  lo=100,  hi=4000),
    "maize_fao": dict(item_id="ITM01025", item_name="Maize - White (per kg)",       unit="kg",    kind="kg",      expected_bundle=1.0,  lo=100,  hi=4000),
    "beans":     dict(item_id="ITM01003", item_name="Beans - Brown (per kg)",       unit="kg",    kind="kg",      expected_bundle=2.5,  lo=200,  hi=6000),
    "onions":    dict(item_id="ITM01029", item_name="Onions - Bulb (per kg)",       unit="kg",    kind="kg",      expected_bundle=0.5,  lo=100,  hi=6000),
    "yam":       dict(item_id="ITM01043", item_name="Yam Tuber (per kg)",           unit="kg",    kind="kg",      expected_bundle=2.5,  lo=200,  hi=6000),
    "fish":      dict(item_id="ITM00086", item_name="Fresh Fish - Catfish (per kg)", unit="kg",   kind="kg",      expected_bundle=1.0,  lo=100,  hi=8000),
    "eggs":      dict(item_id="ITM01001", item_name="Eggs - Agric Medium (Crate)",  unit="crate", kind="crate30", expected_bundle=30.0, lo=1500, hi=15000),
}


def get_connection():
    return pymssql.connect(
        server=os.environ["SQL_SERVER"],
        user=os.environ["SQL_USER"],
        password=os.environ["SQL_PASSWORD"],
        database=os.environ["SQL_DATABASE"],
        timeout=0,
        login_timeout=30,
    )


def parse_bundle(components, wb_col):
    """Extract (qty, unit) for `wb_col` from the RTFP components string.
    e.g. 'beans (2.5 KG, Index Weight = 0.4), eggs (30 pcs, ...)' -> (2.5, 'KG').
    Returns (None, None) if not found.
    """
    if not components:
        return None, None
    m = re.search(rf"\b{re.escape(wb_col)}\s*\(\s*([0-9]*\.?[0-9]+)\s*([A-Za-z]+)", components)
    if not m:
        return None, None
    return float(m.group(1)), m.group(2).upper()


def to_kg(qty, unit):
    """Convert a parsed quantity to kilograms."""
    if unit in ("KG", "KGS", "KILOGRAM"):
        return qty
    if unit in ("G", "GRAM", "GRAMS"):
        return qty / 1000.0
    return None  # unexpected unit for a 'kg' commodity


def normalise_price(raw, components, wb_col, cfg):
    """Return normalised price (per kg, or per 30-pc crate) or None to skip."""
    qty, unit = parse_bundle(components, wb_col)

    if cfg["kind"] == "kg":
        bundle_kg = to_kg(qty, unit) if qty is not None else None
        if bundle_kg is None or bundle_kg <= 0:
            bundle_kg = cfg["expected_bundle"]  # fallback
            logging.warning("[wb_rtfp] %s: bundle unparsed (%s %s), using expected %.3f kg",
                            wb_col, qty, unit, bundle_kg)
        price = raw / bundle_kg

    elif cfg["kind"] == "crate30":
        # eggs are priced per N pcs; normalise to a 30-pc crate.
        pcs = qty if (qty is not None and unit == "PCS") else cfg["expected_bundle"]
        if not pcs or pcs <= 0:
            pcs = cfg["expected_bundle"]
        price = raw / pcs * 30.0

    else:
        return None

    # plausibility guard: never let a per-bundle price slip through as per-unit
    if price < cfg["lo"] or price > cfg["hi"]:
        logging.warning("[wb_rtfp] %s: normalised price %.2f out of band [%d, %d] "
                        "(raw=%s, bundle=%s %s) — skipping row",
                        wb_col, price, cfg["lo"], cfg["hi"], raw, qty, unit)
        return None

    return round(price, 2)


def fetch_year(year):
    """Page through all NGA rows for a given year via the open NADA data-API."""
    rows, offset = [], 0
    while True:
        r = requests.get(API_URL, params={"ISO3": "NGA", "year": year,
                                           "limit": PAGE_LIMIT, "offset": offset},
                         headers={"Accept": "application/json"}, timeout=120)
        r.raise_for_status()
        data = r.json().get("data", [])
        rows.extend(data)
        if len(data) < PAGE_LIMIT:
            break
        offset += PAGE_LIMIT
    return rows


def to_float(v):
    if v in (None, "", "NA", "NaN"):
        return None
    try:
        return float(v)
    except (TypeError, ValueError):
        return None


def main(myTimer: func.TimerRequest) -> None:
    logging.info("[wb_rtfp] Starting World Bank RTFP ingest")
    this_year = datetime.utcnow().year

    # Pull current + previous year so a run near the year boundary still
    # captures the latest published month.
    rows = []
    for y in (this_year - 1, this_year):
        try:
            yr = fetch_year(y)
            logging.info("[wb_rtfp] fetched %d NGA rows for %d", len(yr), y)
            rows.extend(yr)
        except Exception as e:
            logging.error("[wb_rtfp] fetch failed for %d: %s", y, e)
    if not rows:
        logging.warning("[wb_rtfp] no rows fetched; aborting")
        return

    conn = get_connection()
    cur = conn.cursor()

    # Preload existing keys for this source to dedup in-memory.
    cur.execute(
        "SELECT price_date, item_id, market_id FROM dbo.Verified_External_Prices WHERE source=%s",
        (SOURCE,),
    )
    existing = {(r[0].isoformat() if isinstance(r[0], (date, datetime)) else str(r[0]),
                 r[1], r[2]) for r in cur.fetchall()}

    inserted = skipped_dup = skipped_market = 0

    for row in rows:
        mkt = (row.get("mkt_name") or "").strip()
        mapping = MARKET_MAP.get(mkt)
        if not mapping:
            skipped_market += 1
            continue  # aggregate / unmapped market

        market_id, market_name, state, expected_adm1 = mapping
        adm1 = (row.get("adm1_name") or "").strip()
        if adm1 != expected_adm1:
            logging.warning("[wb_rtfp] adm1 mismatch for mkt '%s': got '%s' expected '%s' — skipping",
                            mkt, adm1, expected_adm1)
            continue

        price_date = (row.get("DATES") or "").strip()  # 'yyyy-mm-01'
        if not price_date:
            continue
        components = row.get("components") or ""

        for wb_col, cfg in COMMODITY_MAP.items():
            raw = to_float(row.get(wb_col))
            if raw is None or raw <= 0:
                continue

            key = (price_date, cfg["item_id"], market_id)
            if key in existing:
                skipped_dup += 1
                continue

            price = normalise_price(raw, components, wb_col, cfg)
            if price is None:
                continue

            cur.execute(
                "INSERT INTO dbo.Verified_External_Prices "
                "(source, price_date, item_id, item_name, market_id, market_name, "
                " state, price_naira, unit, confidence, used_in_gen, created_at) "
                "VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,0,GETUTCDATE())",
                (SOURCE, price_date, cfg["item_id"], cfg["item_name"], market_id,
                 market_name, state, price, cfg["unit"], CONFIDENCE),
            )
            existing.add(key)
            inserted += 1

    conn.commit()
    conn.close()
    logging.info("[wb_rtfp] Done. inserted=%d dup_skipped=%d market_skipped=%d",
                 inserted, skipped_dup, skipped_market)
