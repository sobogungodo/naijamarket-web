"""
globalpetrol_scraper — GlobalPetrolPrices.com (Nigeria) -> Fuel_Prices

Live national pump prices, updated ~weekly. Scrapes the headline NGN price
from each product page (plain HTML, no JS/API needed).

Products: PMS (petrol/gasoline), AGO (diesel).
  LPG is intentionally skipped: GPP "LPG" is autogas (per litre), which would
  conflate with the existing cooking-gas (per kg) LPG rows.

Target: dbo.Fuel_Prices, source='GlobalPetrolPrices', state=NULL (national).
Idempotent: relies on unique index UX_FuelPrices_Type_National_Date
  (fuel_type, effective_date) — duplicate inserts are caught and ignored,
  so naijaapp needs only INSERT (no SELECT/DELETE).

Schedule: Mondays 06:00 UTC (see function.json).
"""
import azure.functions as func
import logging, datetime, re
import requests

from shared.db import get_connection

UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) NaijaMarketScraper/1.0"
BASE = "https://www.globalpetrolprices.com/Nigeria/%s/"
SOURCE = "GlobalPetrolPrices"
UPDATED_BY = "scraper:globalpetrolprices"

# (fuel_type, page slug, headline-price regex)
PRODUCTS = [
    ("PMS", "gasoline_prices", r"octane-95 gasoline is\s*([0-9]+(?:\.[0-9]+)?)"),
    ("AGO", "diesel_prices",   r"\bdiesel is\s*([0-9]+(?:\.[0-9]+)?)"),
]

# sanity bounds (NGN/litre) to reject mis-parses / USD values
MIN_NGN, MAX_NGN = 100.0, 10000.0


def fetch_price(session, page, rx):
    r = session.get(BASE % page, timeout=60)
    r.raise_for_status()
    m = re.search(rx, r.text, re.I)
    if not m:
        raise RuntimeError("price pattern not found on %s" % page)
    val = round(float(m.group(1)), 2)
    if not (MIN_NGN <= val <= MAX_NGN):
        raise ValueError("price %.2f out of NGN bounds on %s" % (val, page))
    return val


def scrape():
    session = requests.Session()
    session.headers.update({"User-Agent": UA})
    rows = []
    for fuel_type, page, rx in PRODUCTS:
        try:
            price = fetch_price(session, page, rx)
            rows.append((fuel_type, price))
            logging.info("[globalpetrol] %s = %.2f NGN/litre", fuel_type, price)
        except Exception:
            logging.exception("[globalpetrol] failed to scrape %s", fuel_type)
    return rows


def upsert(eff_date, rows):
    if not rows:
        logging.warning("[globalpetrol] nothing to write")
        return 0
    conn = get_connection()
    written = 0
    try:
        cur = conn.cursor()
        for fuel_type, price in rows:
            try:
                cur.execute(
                    "INSERT INTO dbo.Fuel_Prices "
                    "(fuel_type, price_naira, state, source, effective_date, updated_at, updated_by) "
                    "VALUES (%s, %s, NULL, %s, %s, SYSUTCDATETIME(), %s)",
                    (fuel_type, price, SOURCE, eff_date, UPDATED_BY),
                )
                conn.commit()
                written += 1
            except Exception as e:
                conn.rollback()
                msg = str(e)
                if "2627" in msg or "2601" in msg or "duplicate" in msg.lower() or "unique" in msg.lower():
                    logging.info("[globalpetrol] %s already present for %s, skipping", fuel_type, eff_date)
                else:
                    raise
        logging.info("[globalpetrol] inserted %d new rows for %s", written, eff_date)
        return written
    finally:
        conn.close()


def run():
    eff_date = datetime.datetime.utcnow().date()
    return upsert(eff_date, scrape())


def main(myTimer: func.TimerRequest) -> None:
    logging.info("[globalpetrol_scraper] tick")
    try:
        n = run()
        logging.info("[globalpetrol_scraper] done, %d rows", n)
    except Exception:
        logging.exception("[globalpetrol_scraper] FAILED")
        raise
